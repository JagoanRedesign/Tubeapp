package com.novatube.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Penyimpanan lokal untuk fitur perpustakaan. Data tersimpan di perangkat. */
object LibraryStore {
    private const val PREF = "novatube_library"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun encode(v: Video) = JSONObject().apply {
        put("url", v.url); put("title", v.title); put("channel", v.channel)
        put("views", v.views); put("date", v.date); put("duration", v.duration)
        put("thumb", v.thumb ?: JSONObject.NULL)
    }

    private fun decode(o: JSONObject) = Video(
        o.optString("url"), o.optString("title"), o.optString("channel"),
        o.optLong("views", -1), o.optString("date"), o.optLong("duration"),
        o.optString("thumb").takeIf { it.isNotBlank() && it != "null" }
    )

    @Synchronized fun get(c: Context, key: String): List<Video> {
        val a = try { JSONArray(prefs(c).getString(key, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until a.length()).mapNotNull { i -> try { decode(a.getJSONObject(i)) } catch (_: Exception) { null } }
    }

    @Synchronized fun add(c: Context, key: String, v: Video, newestFirst: Boolean = true) {
        val items = get(c, key).filterNot { it.url == v.url }.toMutableList()
        if (newestFirst) items.add(0, v) else items.add(v)
        val a = JSONArray()
        items.take(300).forEach { a.put(encode(it)) }
        prefs(c).edit().putString(key, a.toString()).apply()
    }

    @Synchronized fun remove(c: Context, key: String, v: Video) {
        val a = JSONArray()
        get(c, key).filterNot { it.url == v.url }.forEach { a.put(encode(it)) }
        prefs(c).edit().putString(key, a.toString()).apply()
    }

    fun contains(c: Context, key: String, v: Video) = get(c, key).any { it.url == v.url }

    fun strings(c: Context, key: String): List<String> {
        val a = try { JSONArray(prefs(c).getString(key, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
    }
    fun addString(c: Context, key: String, value: String) {
        val values = strings(c, key).toMutableList()
        if (value.isNotBlank() && !values.contains(value)) values.add(value)
        val a = JSONArray(); values.forEach { a.put(it) }
        prefs(c).edit().putString(key, a.toString()).apply()
    }
    fun removeString(c: Context, key: String, value: String) {
        val a = JSONArray()
        strings(c, key).filterNot { it == value }.forEach { a.put(it) }
        prefs(c).edit().putString(key, a.toString()).apply()
    }
}
