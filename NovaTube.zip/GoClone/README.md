# NovaTube

Android app project (Kotlin) for GitHub Actions. Root project is `GoClone/`.

## Fitur yang tersedia
- Cari video YouTube dan kategori melalui NewPipe Extractor.
- Daftar hasil berbentuk grid dua kolom.
- Pemutar Media3/ExoPlayer, pilihan kualitas, audio-only, video terkait.
- Pemutaran latar belakang melalui MediaSessionService dan notifikasi media Android.
- Picture-in-Picture dan fullscreen.
- Riwayat tontonan tersimpan lokal.
- Video disukai dan Tonton Nanti tersimpan lokal.
- Buat playlist lokal, tambahkan video ke playlist, dan buka isi playlist.
- Ikuti/berhenti mengikuti kanal; daftar kanal disimpan lokal.
- Pengaturan popup otomatis.
- Berbagi link YouTube ke aplikasi dan membuka link YouTube dari aplikasi lain.

## Catatan penting
- Riwayat, suka, tonton nanti, playlist, dan daftar kanal disimpan di penyimpanan privat aplikasi; data hilang jika data aplikasi dihapus/uninstall.
- Daftar kanal yang diikuti adalah daftar lokal. Ini belum sinkron dengan akun YouTube dan belum membuat feed langganan resmi.
- Playlist adalah playlist lokal aplikasi, bukan playlist yang ditulis ke akun YouTube.
- Pemutaran/ekstraksi video bergantung pada perubahan layanan YouTube dan dapat sewaktu-waktu gagal atau memerlukan pembaruan NewPipe Extractor.
- Tidak ada dukungan unduh MP3/MP4 pada versi ini.
- Belum ada implementasi gestur volume/kecerahan atau autoplay antrean; kontrol tersebut tidak ditampilkan sebagai fitur aktif.
- Launcher icon saat ini vector sederhana buatan proyek, bukan aset Flaticon. Untuk memakai ikon Flaticon, unduh aset sesuai lisensi/atribusi dari Flaticon lalu ganti `app/src/main/res/drawable/ic_launcher.xml` (atau konfigurasi mipmap icon).

## Build
Workflow `.github/workflows/build.yml` membangun `assembleDebug` dan mengunggah APK sebagai artifact `APK`.
Unggah ZIP proyek ini ke repository GitHub, jalankan Actions, lalu unduh artifact APK.
