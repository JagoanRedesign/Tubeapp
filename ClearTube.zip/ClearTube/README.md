# ClearTube
Pembungkus WebView untuk situs YouTube mobile: blokir iklan, putar di latar belakang, PiP.
Build: unggah ClearTube.zip + build.yml (di .github/workflows/) ke repo, jalankan Actions > Build APK.
