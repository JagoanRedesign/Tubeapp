package com.cleartube.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var web: BgWebView
    private lateinit var main: View
    private lateinit var bar: View
    private lateinit var fullscreen: FrameLayout
    private lateinit var progress: ProgressBar

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var scriptHandler: ScriptHandler? = null
    private var fallbackJs: String? = null

    @Volatile private var adsOn = true
    private var shorts = false
    private var pipAuto = false
    private val prefs by lazy { getSharedPreferences("cleartube", MODE_PRIVATE) }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val chrome = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progress.progress = newProgress
            progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
        }

        override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customCb = callback
            fullscreen.addView(view, FrameLayout.LayoutParams(-1, -1))
            fullscreen.visibility = View.VISIBLE
            main.visibility = View.GONE
            setBars(false)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }

        override fun onHideCustomView() {
            val v = customView ?: return
            fullscreen.removeView(v)
            fullscreen.visibility = View.GONE
            main.visibility = View.VISIBLE
            customCb?.onCustomViewHidden()
            customView = null
            customCb = null
            setBars(true)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private val client = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val host = request.url.host ?: return false
            val internal = host.endsWith("youtube.com") || host == "youtu.be" ||
                host.endsWith("google.com") || host.endsWith("gstatic.com") ||
                host.endsWith("googleusercontent.com")
            if (internal) return false
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, request.url))
                true
            } catch (e: Exception) {
                false
            }
        }

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (adsOn && isAdRequest(request.url)) {
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return null
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            fallbackJs?.let { view.evaluateJavascript(it, null) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web)
        main = findViewById(R.id.main)
        bar = findViewById(R.id.bar)
        fullscreen = findViewById(R.id.fullscreen)
        progress = findViewById(R.id.progress)

        adsOn = prefs.getBoolean("ads", true)
        shorts = prefs.getBoolean("shorts", false)
        pipAuto = prefs.getBoolean("pip", false)

        setupWebView()

        findViewById<View>(R.id.btnHome).setOnClickListener { web.loadUrl(HOME) }
        findViewById<View>(R.id.btnPip).setOnClickListener { enterPip() }
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> chrome.onHideCustomView()
                    web.canGoBack() -> web.goBack()
                    else -> moveTaskToBack(true)
                }
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        web.loadUrl(startUrl(intent))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.userAgentString = s.userAgentString.replace("; wv", "").replace("Version/4.0 ", "")
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webChromeClient = chrome
        web.webViewClient = client
        installScripts()
    }

    private fun installScripts() {
        scriptHandler?.remove()
        scriptHandler = null
        fallbackJs = null
        val js = assets.open("inject.js").bufferedReader().use { it.readText() }
            .replace("__ADS__", adsOn.toString())
            .replace("__SHORTS__", shorts.toString())
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(
                web, js, setOf("https://m.youtube.com", "https://www.youtube.com")
            )
        } else {
            fallbackJs = js
        }
    }

    private fun isAdRequest(u: Uri): Boolean {
        val h = u.host ?: return false
        if (AD_HOSTS.any { h == it || h.endsWith(".$it") }) return true
        val p = u.path ?: return false
        return p.startsWith("/pagead/") || p.startsWith("/api/stats/ads") || p.startsWith("/ptracking")
    }

    private fun startUrl(i: Intent?): String {
        val d = i?.data?.toString()
        return if (d != null && d.startsWith("http")) d else HOME
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.data != null) web.loadUrl(startUrl(intent))
    }

    private fun setBars(show: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (show) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSettings() {
        val items = arrayOf("Blokir iklan", "Sembunyikan Shorts", "PiP otomatis saat keluar aplikasi")
        val checked = booleanArrayOf(adsOn, shorts, pipAuto)
        MaterialAlertDialogBuilder(this)
            .setTitle("Pengaturan")
            .setMultiChoiceItems(items, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Simpan") { _, _ ->
                adsOn = checked[0]; shorts = checked[1]; pipAuto = checked[2]
                prefs.edit().putBoolean("ads", adsOn).putBoolean("shorts", shorts).putBoolean("pip", pipAuto).apply()
                installScripts()
                web.reload()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) return
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (e: Exception) {
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipAuto) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        bar.visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        web.evaluateJavascript(if (isInPictureInPictureMode) PIP_ON else PIP_OFF, null)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        try {
            ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        stopService(Intent(this, KeepAliveService::class.java))
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val HOME = "https://m.youtube.com"
        private val AD_HOSTS = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "2mdn.net", "imasdk.googleapis.com"
        )
        private const val PIP_ON =
            "(function(){var s=document.getElementById('__pipcss');if(!s){s=document.createElement('style');" +
                "s.id='__pipcss';(document.head||document.documentElement).appendChild(s);}" +
                "s.textContent='video{position:fixed!important;top:0!important;left:0!important;width:100vw!important;" +
                "height:100vh!important;z-index:2147483647!important;object-fit:contain!important;background:#000!important}" +
                "body{overflow:hidden!important}';})();"
        private const val PIP_OFF =
            "(function(){var s=document.getElementById('__pipcss');if(s)s.remove();})();"
    }
}
