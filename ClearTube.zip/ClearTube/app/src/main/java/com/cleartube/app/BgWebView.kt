package com.cleartube.app

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.webkit.WebView

/** WebView yang tetap dianggap "terlihat" agar audio tidak berhenti saat aplikasi di latar belakang. */
class BgWebView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : WebView(ctx, attrs) {
    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.GONE) super.onWindowVisibilityChanged(View.VISIBLE)
    }
}
