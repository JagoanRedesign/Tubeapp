(function () {
  if (window.__ct) return;
  window.__ct = true;
  var CFG = { ads: __ADS__, shorts: __SHORTS__ };

  /* ---- Putar di latar belakang: halaman selalu dianggap "terlihat" ---- */
  var def = function (o, k, v) {
    try { Object.defineProperty(o, k, { configurable: true, get: function () { return v; } }); } catch (e) {}
  };
  def(document, 'hidden', false);
  def(document, 'webkitHidden', false);
  def(document, 'visibilityState', 'visible');
  def(document, 'webkitVisibilityState', 'visible');
  ['visibilitychange', 'webkitvisibilitychange', 'blur'].forEach(function (t) {
    window.addEventListener(t, function (e) { e.stopImmediatePropagation(); }, true);
    document.addEventListener(t, function (e) { e.stopImmediatePropagation(); }, true);
  });

  /* ---- Buang data iklan dari respons pemutar ---- */
  if (CFG.ads) {
    var KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakParams'];
    var clean = function (o, d) {
      if (!o || typeof o !== 'object' || d > 2) return;
      for (var i = 0; i < KEYS.length; i++) {
        var k = KEYS[i];
        if (k in o) {
          try { if (Array.isArray(o[k])) o[k] = []; else delete o[k]; } catch (e) {}
        }
      }
      if (o.playerResponse) clean(o.playerResponse, d + 1);
      if (o.response) clean(o.response, d + 1);
    };
    try {
      var _parse = JSON.parse;
      JSON.parse = function () {
        var r = _parse.apply(this, arguments);
        try { clean(r, 0); } catch (e) {}
        return r;
      };
      var _json = Response.prototype.json;
      Response.prototype.json = function () {
        return _json.apply(this, arguments).then(function (r) { try { clean(r, 0); } catch (e) {} return r; });
      };
      var _ipr;
      Object.defineProperty(window, 'ytInitialPlayerResponse', {
        configurable: true,
        get: function () { return _ipr; },
        set: function (v) { try { clean(v, 0); } catch (e) {} _ipr = v; }
      });
    } catch (e) {}

    /* Cadangan: lewati iklan yang lolos */
    var adMuted = false;
    setInterval(function () {
      var p = document.querySelector('.html5-video-player');
      var v = document.querySelector('video.html5-main-video') || document.querySelector('video');
      var showing = p && (p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting'));
      if (showing && v) {
        if (!v.muted) { v.muted = true; adMuted = true; }
        if (isFinite(v.duration) && v.duration > 0) { try { v.currentTime = v.duration; } catch (e) {} }
      } else if (adMuted && v) { v.muted = false; adMuted = false; }
      var b = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .ytp-ad-skip-button-container button');
      if (b) b.click();
      var c = document.querySelector('.ytp-ad-overlay-close-button');
      if (c) c.click();
    }, 250);
  }

  /* ---- CSS: sembunyikan elemen iklan (& Shorts jika diaktifkan) ---- */
  var css = '';
  if (CFG.ads) {
    css += '.ytp-ad-module,.ytp-ad-overlay-container,.ytp-ad-image-overlay,.video-ads,.ad-container,#player-ads,#masthead-ad,' +
      'ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer,' +
      'ad-slot-renderer,ytm-statement-banner-renderer,ytm-brand-video-singleton-renderer,ytm-upsell-dialog-renderer,' +
      'ytm-mealbar-promo-renderer{display:none!important}';
  }
  if (CFG.shorts) {
    css += 'ytm-reel-shelf-renderer,ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2{display:none!important}';
  }
  if (css) {
    var st = document.createElement('style');
    st.textContent = css;
    (document.head || document.documentElement).appendChild(st);
  }
})();
