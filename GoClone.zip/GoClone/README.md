# NovaTube (GoClone)
Klien YouTube native: beranda kategori, pencarian, pemutar ExoPlayer, audio latar + notifikasi,
mini-player, jendela mengambang (PiP), kualitas video, mode audio saja, video terkait.
Data dari NewPipeExtractor (tanpa API key). Lisensi library: GPLv3.
Build: unggah GoClone.zip + build.yml (di .github/workflows/) ke repo, jalankan Actions > Build APK.
