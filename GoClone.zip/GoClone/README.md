# NovaTube v3 (GoClone)
(c) 2026 Ilham Galeh. Hak cipta dilindungi. Lihat NOTICE.txt untuk lisensi pihak ketiga (NewPipeExtractor: GPLv3).

Klien YouTube native bergaya GoTube. Data dari NewPipeExtractor (GPLv3), semua data pengguna disimpan lokal.

Header NovaTube (logo, Pengaturan, Cari, chip kategori), panel info pemutar ringkas, notifikasi putar/jeda/lewati.

Fitur: pemutar TextureView + fallback otomatis jika video blank, mini player berisi video asli, kanal lengkap
(Beranda/Video/Shorts/Playlist/Live + urutan), komentar bersarang dengan foto asli, antrean + playlist otomatis,
subtitle & trek audio, timer tidur, Watch Progress, tema Terang/Gelap/Dark AMOLED, mode Hemat data,
Download Manager, tes unit, dan APK rilis R8.

Tidak didukung (sumber data hanya-baca): login akun, menulis komentar/balasan, langganan & like asli YouTube.

Build: unggah GoClone.zip + build.yml (di .github/workflows/) ke repo, jalankan Actions > Build APK.
Hasil: GoClone-debug.apk, GoClone-release.apk (lebih kecil), dan laporan tes.


v3: Shorts (layar penuh, geser, suka/komentar/bagikan/langganan), navigasi 5 tab (Beranda, Shorts, Tambah,
Langganan, Profil), suka & langganan nyata ke YouTube (masuk akun via OAuth perangkat, butuh Client ID sendiri),
Background Play 2.0 (Berikutnya/Sebelumnya tanpa Activity, layar kunci, Bluetooth), Komentar 2.0,
Resume Progress diperbaiki (penjaga pergantian video & ID).
