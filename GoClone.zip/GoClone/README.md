# NovaTube 3.3 — YouTube OAuth Android

## OAuth yang digunakan

Client ID yang diberikan untuk proyek ini disimpan di `OAuthConfig.kt`:

```text
595678157449-gkhc06ofuu7b74di7ts3jc42iv9n3gbn.apps.googleusercontent.com
```

Nilai tersebut dicantumkan sebagai identitas/referensi konfigurasi. Alur Android `AuthorizationClient` di aplikasi ini menggunakan registrasi OAuth tipe **Android** berdasarkan package name dan SHA-1; Client ID tidak ditempelkan ke permintaan `authorize()`. Pastikan Client ID di atas memang milik project Google Cloud yang sama dengan OAuth Android client. Jika itu adalah OAuth client tipe Web, jangan menganggapnya sebagai pengganti Android client.

Aplikasi memakai Google Identity Services `AuthorizationClient` pada Android. Tidak ada kolom Client Secret dan tidak ada Client Secret yang ditanam di APK.

Scope default: `https://www.googleapis.com/auth/youtube.readonly`.
Scope ini untuk membaca channel, playlist, item playlist, dan subscription akun yang memberi izin. Aksi yang mengubah akun YouTube (like/dislike, subscribe/unsubscribe) tetap bersifat lokal pada build read-only ini. Jika fitur tulis ingin diaktifkan, perlu evaluasi scope tambahan dan persetujuan pengguna.

## Konfigurasi Google Cloud

1. Buka https://console.cloud.google.com/ dan buat/pilih project.
2. API & Services → Library → aktifkan **YouTube Data API v3**.
3. Google Auth Platform → Branding: lengkapi nama aplikasi, email dukungan, dan email kontak.
4. Audience: pilih External jika digunakan akun Google umum. Saat status Testing, tambahkan akun Google penguji di Test users.
5. Clients → Create Client → Android.
6. Package name harus persis: `com.novatube.app`.
7. SHA-1 harus cocok dengan sertifikat APK yang dipasang di HP.
8. Simpan. Pastikan OAuth Android client dibuat pada project yang sama dengan Client ID referensi di `OAuthConfig.kt`. Login client-side tidak memerlukan Client Secret; jangan pernah menanam Client Secret di APK.

## Mendapatkan SHA-1

Untuk debug keystore lokal:

```bash
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```

Di Windows, debug keystore biasanya berada di `%USERPROFILE%\.android\debug.keystore`.

Untuk APK release, gunakan SHA-1 dari keystore release yang menandatangani APK. SHA-1 debug dan release berbeda. Jika APK ditandatangani oleh GitHub Actions, gunakan keystore persisten yang sama untuk setiap build; jangan mengandalkan debug keystore runner yang dibuat ulang.

## Catatan sesi

Access token bersifat sementara dan disimpan hanya di memori. Setelah aplikasi dimulai ulang atau token kedaluwarsa, pengguna perlu menekan Masuk lagi; Google Identity Services dapat mengembalikan akses tanpa dialog jika izin sebelumnya masih berlaku.

## Build

Jalankan `gradle assembleDebug` atau workflow GitHub Actions yang disediakan.
