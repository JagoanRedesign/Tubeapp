# NovaTube v2 (GoClone)
Klien YouTube native bergaya GoTube. Data dari NewPipeExtractor (GPLv3), semua data pengguna disimpan lokal.

Fitur: pemutar TextureView + fallback otomatis jika video blank, mini player berisi video asli, kanal lengkap
(Beranda/Video/Shorts/Playlist/Live + urutan), komentar bersarang dengan foto asli, antrean + playlist otomatis,
subtitle & trek audio, timer tidur, Watch Progress, tema Terang/Gelap/Dark AMOLED, mode Hemat data,
Download Manager, tes unit, dan APK rilis R8.

Tidak didukung (sumber data hanya-baca): login akun, menulis komentar/balasan, langganan & like asli YouTube.

Build: unggah GoClone.zip + build.yml (di .github/workflows/) ke repo, jalankan Actions > Build APK.
Hasil: GoClone-debug.apk, GoClone-release.apk (lebih kecil), dan laporan tes.
