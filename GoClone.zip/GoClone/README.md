# NovaTube (GoClone)
Klien YouTube native bergaya GoTube: Beranda (kategori + pencarian), Pustaka (Daftar Tontonan Lokal, Langganan,
Riwayat, Nonton nanti, Video yang disukai, Daftar putar), halaman pemutar (kualitas, kecepatan, audio saja,
jendela mengambang, komentar, video terkait), dan Pengaturan > Umum (gestur volume/kecerahan, ketuk dua kali, dll).
Data dari NewPipeExtractor (GPLv3). Semua data pengguna disimpan lokal di perangkat.

Ikon: file vektor di app/src/main/res/drawable/ic_*.xml. Untuk memakai ikon Flaticon: unduh SVG, impor lewat
Android Studio (New > Vector Asset), lalu timpa file dengan nama yang sama. Cantumkan atribusi sesuai lisensi Flaticon.

Build: unggah GoClone.zip + build.yml (di .github/workflows/) ke repo, jalankan Actions > Build APK.


## Perbaikan pemutar dan halaman channel

- ExoPlayer hanya dipasang ke satu `PlayerView` aktif pada satu waktu. Surface dipindahkan antara pemutar utama dan mini player agar tidak saling berebut dan menyebabkan layar video hitam.
- Saat nama/foto channel ditekan, pemutar otomatis masuk ke mini player tanpa membuat ulang instance ExoPlayer.
- Halaman channel kini memiliki header profil, tombol berlangganan, tab tampilan, dan daftar video.
- Komentar dibuka dalam Bottom Sheet dengan tab tampilan Teratas/Terbaru dan kolom login.
- Kontrol mundur 5 detik dan maju 15 detik tetap tidak ditampilkan pada kontrol pemutar.
