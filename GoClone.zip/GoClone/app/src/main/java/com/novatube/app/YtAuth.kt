package com.novatube.app

import android.content.Context
import android.content.SharedPreferences
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Masuk akun Google lewat OAuth "perangkat" (kode di google.com/device).
 * Membutuhkan Client ID + Secret bertipe "TVs and Limited Input devices" milik pengguna sendiri.
 */
object YtAuth {
    private lateinit var sp: SharedPreferences
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    @Volatile private var access: String? = null
    @Volatile private var expiresAt = 0L

    fun init(ctx: Context) {
        if (!::sp.isInitialized) sp = ctx.applicationContext.getSharedPreferences("novatube_auth", Context.MODE_PRIVATE)
    }

    var clientId: String
        get() = sp.getString("cid", "") ?: ""
        set(v) { sp.edit().putString("cid", v.trim()).apply() }
    var clientSecret: String
        get() = sp.getString("csec", "") ?: ""
        set(v) { sp.edit().putString("csec", v.trim()).apply() }
    var refreshToken: String?
        get() = sp.getString("rt", null)
        set(v) { sp.edit().putString("rt", v).apply() }
    var accountName: String
        get() = sp.getString("name", "") ?: ""
        set(v) { sp.edit().putString("name", v).apply() }
    var accountAvatar: String?
        get() = sp.getString("avatar", null)
        set(v) { sp.edit().putString("avatar", v).apply() }

    val loggedIn: Boolean get() = !refreshToken.isNullOrEmpty()
    val configured: Boolean get() = clientId.isNotEmpty() && clientSecret.isNotEmpty()

    class DeviceCode(val deviceCode: String, val userCode: String, val url: String, val interval: Int, val expiresIn: Int)

    private fun postForm(url: String, vararg kv: Pair<String, String>): JSONObject {
        val b = FormBody.Builder()
        kv.forEach { b.add(it.first, it.second) }
        http.newCall(Request.Builder().url(url).post(b.build()).build()).execute().use { r ->
            val txt = r.body?.string() ?: "{}"
            return try { JSONObject(txt) } catch (e: Exception) { JSONObject().put("error", "HTTP ${r.code}") }
        }
    }

    fun requestDeviceCode(): DeviceCode {
        val j = postForm(
            "https://oauth2.googleapis.com/device/code",
            "client_id" to clientId,
            "scope" to "https://www.googleapis.com/auth/youtube"
        )
        if (j.has("error")) throw IOException(j.optString("error_description", j.optString("error")))
        return DeviceCode(
            j.getString("device_code"), j.getString("user_code"),
            j.optString("verification_url", "https://www.google.com/device"),
            j.optInt("interval", 5), j.optInt("expires_in", 1800)
        )
    }

    /** "ok" bila berhasil, "pending"/"slow_down" bila belum, selain itu pesan galat. */
    fun pollToken(dc: DeviceCode): String {
        val j = postForm(
            "https://oauth2.googleapis.com/token",
            "client_id" to clientId, "client_secret" to clientSecret,
            "device_code" to dc.deviceCode, "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
        )
        val err = j.optString("error")
        if (err.isNotEmpty()) {
            return when (err) {
                "authorization_pending" -> "pending"
                "slow_down" -> "slow_down"
                else -> j.optString("error_description", err)
            }
        }
        access = j.getString("access_token")
        expiresAt = System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000 - 60_000
        val rt = j.optString("refresh_token")
        if (rt.isNotEmpty()) refreshToken = rt
        return "ok"
    }

    @Synchronized
    fun token(): String {
        val t = access
        if (t != null && System.currentTimeMillis() < expiresAt) return t
        val rt = refreshToken ?: throw IOException("Belum masuk akun YouTube")
        val j = postForm(
            "https://oauth2.googleapis.com/token",
            "client_id" to clientId, "client_secret" to clientSecret,
            "refresh_token" to rt, "grant_type" to "refresh_token"
        )
        if (j.has("error")) {
            if (j.optString("error") == "invalid_grant") logout()
            throw IOException(j.optString("error_description", j.optString("error")))
        }
        val n = j.getString("access_token")
        access = n
        expiresAt = System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000 - 60_000
        return n
    }

    fun logout() {
        access = null
        refreshToken = null
        accountName = ""
        accountAvatar = null
    }
}
