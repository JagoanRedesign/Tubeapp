package com.novatube.app

import android.content.Context
import android.content.SharedPreferences
import java.io.IOException

/**
 * Session YouTube untuk akses client-side Google Identity Services.
 * Access token hanya disimpan di memori dan tidak pernah menyimpan Client Secret.
 * Jika token kedaluwarsa, aplikasi meminta otorisasi lagi melalui AuthorizationClient.
 */
object YtAuth {
    const val YOUTUBE_READONLY = "https://www.googleapis.com/auth/youtube.readonly"

    private lateinit var sp: SharedPreferences
    @Volatile private var accessToken: String? = null
    @Volatile private var expiresAt: Long = 0L

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences("novatube_auth", Context.MODE_PRIVATE)
        }
    }

    fun setAccessToken(token: String, lifetimeSeconds: Long = 3600L) {
        accessToken = token
        // Sisakan waktu aman sebelum token Google kedaluwarsa.
        expiresAt = System.currentTimeMillis() + (lifetimeSeconds.coerceAtLeast(60L) - 120L).coerceAtLeast(60L) * 1000L
    }

    val loggedIn: Boolean
        get() = !accessToken.isNullOrBlank() && System.currentTimeMillis() < expiresAt

    // Scope youtube.readonly tidak mengizinkan perubahan suka/subscription.
    val canWrite: Boolean get() = false

    var accountName: String
        get() = sp.getString("name", "") ?: ""
        set(value) { sp.edit().putString("name", value).apply() }

    var accountAvatar: String?
        get() = sp.getString("avatar", null)
        set(value) { sp.edit().putString("avatar", value).apply() }

    @Synchronized
    fun token(): String {
        val token = accessToken
        if (token.isNullOrBlank() || System.currentTimeMillis() >= expiresAt) {
            accessToken = null
            expiresAt = 0L
            throw IOException("Sesi YouTube kedaluwarsa. Masuk kembali melalui menu Profil.")
        }
        return token
    }

    fun logout() {
        accessToken = null
        expiresAt = 0L
        accountName = ""
        accountAvatar = null
    }
}
