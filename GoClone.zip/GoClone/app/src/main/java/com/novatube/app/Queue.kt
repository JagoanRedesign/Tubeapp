package com.novatube.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.bottomsheet.BottomSheetDialog

/** Antrean putar manual. Logika murni; penyimpanan lewat [persist]. */
object Queue {
    val items = ArrayList<Video>()
    var index = -1
    var persist: (List<Video>) -> Unit = {}

    /** Nama sumber antrean, mis. "Mix - judul"; null untuk antrean manual. */
    @Volatile var title: String? = null

    private fun save() = persist(items)

    fun load(l: List<Video>) {
        items.clear()
        items.addAll(l)
        index = -1
        title = null
    }

    fun current(): Video? = items.getOrNull(index)
    fun peekNext(): Video? = items.getOrNull(index + 1)
    fun peekPrev(): Video? = if (index > 0) items.getOrNull(index - 1) else null

    /** Tambah ke antrean; [next] = putar setelah video yang sedang berjalan. */
    fun add(v: Video, next: Boolean) {
        val cur = current()
        items.removeAll { Util.videoKey(it.url) == Util.videoKey(v.url) }
        if (cur != null) index = items.indexOfFirst { it.url == cur.url }
        val pos = if (next) (index + 1).coerceIn(0, items.size) else items.size
        items.add(pos, v)
        save()
    }

    fun setAll(list: List<Video>, startUrl: String?, name: String? = null) {
        title = name
        items.clear()
        items.addAll(list)
        index = if (startUrl == null) -1 else items.indexOfFirst { Util.videoKey(it.url) == Util.videoKey(startUrl) }
        save()
    }

    /** Tambah ke akhir antrean tanpa duplikat (dipakai untuk memuat halaman Mix berikutnya). */
    fun append(l: List<Video>) {
        val have = items.map { Util.videoKey(it.url) }.toHashSet()
        for (v in l) if (have.add(Util.videoKey(v.url))) items.add(v)
        save()
    }

    fun advance(): Video? {
        val n = peekNext() ?: return null
        index++
        return n
    }

    fun back(): Video? {
        val p = peekPrev() ?: return null
        index--
        return p
    }

    fun syncCurrent(url: String) {
        val i = items.indexOfFirst { Util.videoKey(it.url) == Util.videoKey(url) }
        if (i >= 0) index = i
    }

    fun remove(i: Int) {
        if (i !in items.indices) return
        items.removeAt(i)
        if (i <= index) index--
        save()
    }

    fun move(from: Int, to: Int) {
        if (from !in items.indices || to !in items.indices || from == to) return
        val cur = current()
        val x = items.removeAt(from)
        items.add(to, x)
        if (cur != null) index = items.indexOfFirst { it.url == cur.url }
        save()
    }

    fun clear() {
        items.clear()
        index = -1
        title = null
        save()
    }
}

/** Bottom sheet pengelola antrean (urutkan, hapus, putar). */
class QueueSheet(private val a: MainActivity) {
    private lateinit var adapter: Adapter
    private lateinit var header: TextView
    private lateinit var empty: View

    fun show() {
        val d = BottomSheetDialog(a)
        val v = a.layoutInflater.inflate(R.layout.sheet_queue, null)
        d.setContentView(v)
        d.expandTall(a)
        header = v.findViewById(R.id.qHeader)
        empty = v.findViewById(R.id.qEmpty)
        val list = v.findViewById<RecyclerView>(R.id.qList)
        adapter = Adapter(d)
        list.layoutManager = LinearLayoutManager(a)
        list.adapter = adapter
        val sw = v.findViewById<SwitchCompat>(R.id.qAuto)
        sw.isChecked = Prefs.autoNext
        sw.setOnCheckedChangeListener { _, c -> Prefs.autoNext = c }
        v.findViewById<View>(R.id.qClear).setOnClickListener { Queue.clear(); refresh() }
        v.findViewById<View>(R.id.qMix).setOnClickListener {
            val cur = Now.video ?: Queue.current()
            if (cur == null) a.toast("Putar video dulu untuk memulai Mix")
            else { d.dismiss(); a.startMix(cur) }
        }
        refresh()
        d.show()
    }

    private fun refresh() {
        header.text = "${Queue.title ?: "Antrean"} (${Queue.items.size})"
        empty.visibility = if (Queue.items.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private inner class Adapter(private val dialog: BottomSheetDialog) : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.qThumb)
            val title: TextView = v.findViewById(R.id.qTitle)
            val meta: TextView = v.findViewById(R.id.qMeta)
            val up: View = v.findViewById(R.id.qUp)
            val down: View = v.findViewById(R.id.qDown)
            val del: View = v.findViewById(R.id.qDel)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_queue, p, false))

        override fun getItemCount() = Queue.items.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val v = Queue.items[i]
            val now = i == Queue.index
            h.thumb.load(v.thumb)
            h.title.text = (if (now) "▶ " else "") + v.title
            h.title.setTextColor(if (now) a.getColor(R.color.accent) else a.themeColor(R.attr.ntText))
            h.meta.text = listOf(v.channel, Fmt.duration(v.duration)).filter { it.isNotBlank() }.joinToString(" • ")
            h.itemView.setOnClickListener {
                val pos = h.bindingAdapterPosition
                if (pos < 0) return@setOnClickListener
                Queue.index = pos
                dialog.dismiss()
                a.openVideo(Queue.items[pos])
            }
            h.up.setOnClickListener { val p = h.bindingAdapterPosition; if (p > 0) { Queue.move(p, p - 1); refresh() } }
            h.down.setOnClickListener { val p = h.bindingAdapterPosition; if (p >= 0) { Queue.move(p, p + 1); refresh() } }
            h.del.setOnClickListener { val p = h.bindingAdapterPosition; if (p >= 0) { Queue.remove(p); refresh() } }
        }
    }
}
