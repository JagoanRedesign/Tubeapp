package com.novatube.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Channel(val url: String, val name: String, val avatar: String?)

/** Penyimpanan lokal: riwayat, nonton nanti, disukai, langganan, daftar putar. */
object Store {
    private lateinit var sp: SharedPreferences

    private lateinit var psp: SharedPreferences
    private val progMap = java.util.concurrent.ConcurrentHashMap<String, LongArray>()
    private var saves = 0

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.getSharedPreferences("novatube_store", Context.MODE_PRIVATE)
            psp = ctx.getSharedPreferences("novatube_progress", Context.MODE_PRIVATE)
            for ((k, v) in psp.all) parseProgress(v as? String)?.let { progMap[k] = it }
        }
    }

    // ---- Watch Progress
    fun parseProgress(s: String?): LongArray? {
        val p = s?.split("|") ?: return null
        if (p.size < 3) return null
        return try { longArrayOf(p[0].toLong(), p[1].toLong(), p[2].toLong()) } catch (e: Exception) { null }
    }

    fun saveProgress(url: String, pos: Long, dur: Long) {
        if (url.startsWith("file:") || url.startsWith("content:")) return
        val k = Util.videoKey(url)
        val ts = System.currentTimeMillis()
        progMap[k] = longArrayOf(pos, dur, ts)
        psp.edit().putString(k, "$pos|$dur|$ts").apply()
        if (++saves % 40 == 0 && progMap.size > 400) prune()
    }

    private fun prune() {
        val keep = progMap.entries.sortedByDescending { it.value[2] }.take(300).map { it.key }.toSet()
        val ed = psp.edit()
        for (k in progMap.keys.toList()) if (k !in keep) { progMap.remove(k); ed.remove(k) }
        ed.apply()
    }

    fun progress(url: String): LongArray? = progMap[Util.videoKey(url)]

    fun fraction(url: String): Float {
        val p = progress(url) ?: return 0f
        if (p[1] <= 0) return 0f
        return (p[0].toFloat() / p[1]).coerceIn(0f, 1f)
    }

    fun setList(key: String, l: List<Video>) = write(key, l)

    // ---- penanda sederhana (mis. suka/tidak suka komentar secara lokal)
    @Synchronized
    fun hasFlag(key: String, id: String): Boolean = (sp.getStringSet(key, emptySet()) ?: emptySet()).contains(id)

    @Synchronized
    fun setFlag(key: String, id: String, on: Boolean) {
        val s = HashSet(sp.getStringSet(key, emptySet()) ?: emptySet())
        if (on) s.add(id) else s.remove(id)
        sp.edit().putStringSet(key, s).apply()
    }

    private fun toJson(v: Video) = JSONObject()
        .put("u", v.url).put("t", v.title).put("c", v.channel).put("v", v.views)
        .put("d", v.date).put("l", v.duration).put("th", v.thumb ?: "").put("a", v.avatar ?: "")

    private fun fromJson(o: JSONObject) = Video(
        o.getString("u"), o.optString("t"), o.optString("c"), o.optLong("v", -1),
        o.optString("d"), o.optLong("l"),
        o.optString("th").ifEmpty { null }, o.optString("a").ifEmpty { null }
    )

    private fun readArr(a: JSONArray): MutableList<Video> {
        val out = ArrayList<Video>()
        for (i in 0 until a.length()) out.add(fromJson(a.getJSONObject(i)))
        return out
    }

    private fun toArr(l: List<Video>): JSONArray {
        val a = JSONArray()
        l.forEach { a.put(toJson(it)) }
        return a
    }

    @Synchronized
    fun list(key: String): MutableList<Video> =
        try { readArr(JSONArray(sp.getString(key, "[]"))) } catch (e: Exception) { ArrayList() }

    @Synchronized
    private fun write(key: String, l: List<Video>) {
        sp.edit().putString(key, toArr(l).toString()).apply()
    }

    fun history(): List<Video> = list("hist")

    @Synchronized
    fun addHistory(v: Video) {
        val l = list("hist")
        l.removeAll { it.url == v.url }
        l.add(0, v)
        while (l.size > 100) l.removeAt(l.size - 1)
        write("hist", l)
    }

    fun clearHistory() = write("hist", emptyList())

    fun has(key: String, url: String) = list(key).any { it.url == url }

    /** Mengembalikan true jika video sekarang ada di daftar. */
    @Synchronized
    fun toggle(key: String, v: Video): Boolean {
        val l = list(key)
        val had = l.removeAll { it.url == v.url }
        if (!had) l.add(0, v)
        write(key, l)
        return !had
    }

    // ---- langganan
    @Synchronized
    fun subs(): List<Channel> = try {
        val a = JSONArray(sp.getString("subs", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Channel(o.getString("u"), o.optString("n"), o.optString("a").ifEmpty { null })
        }
    } catch (e: Exception) { emptyList() }

    fun isSub(url: String) = subs().any { it.url == url }

    @Synchronized
    fun toggleSub(c: Channel): Boolean {
        val l = subs().toMutableList()
        val had = l.removeAll { it.url == c.url }
        if (!had) l.add(0, c)
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("u", it.url).put("n", it.name).put("a", it.avatar ?: "")) }
        sp.edit().putString("subs", a.toString()).apply()
        return !had
    }

    // ---- daftar putar
    @Synchronized
    private fun readPl(): JSONObject = try { JSONObject(sp.getString("pl", "{}")) } catch (e: Exception) { JSONObject() }

    fun playlistNames(): List<String> {
        val o = readPl()
        return o.keys().asSequence().toList().sorted()
    }

    fun playlist(name: String): List<Video> =
        try { readArr(readPl().getJSONArray(name)) } catch (e: Exception) { emptyList() }

    @Synchronized
    fun createPlaylist(name: String) {
        val o = readPl()
        if (!o.has(name)) o.put(name, JSONArray())
        sp.edit().putString("pl", o.toString()).apply()
    }

    @Synchronized
    fun addToPlaylist(name: String, v: Video) {
        val o = readPl()
        val l = try { readArr(o.getJSONArray(name)) } catch (e: Exception) { ArrayList() }
        l.removeAll { it.url == v.url }
        l.add(0, v)
        o.put(name, toArr(l))
        sp.edit().putString("pl", o.toString()).apply()
    }

    @Synchronized
    fun deletePlaylist(name: String) {
        val o = readPl()
        o.remove(name)
        sp.edit().putString("pl", o.toString()).apply()
    }
}
