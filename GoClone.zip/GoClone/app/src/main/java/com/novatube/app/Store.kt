package com.novatube.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Channel(val url: String, val name: String, val avatar: String?)

/** Penyimpanan lokal: riwayat, nonton nanti, disukai, langganan, daftar putar. */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) sp = ctx.getSharedPreferences("novatube_store", Context.MODE_PRIVATE)
    }

    private fun toJson(v: Video) = JSONObject()
        .put("u", v.url).put("t", v.title).put("c", v.channel).put("v", v.views)
        .put("d", v.date).put("l", v.duration).put("th", v.thumb ?: "").put("a", v.avatar ?: "")

    private fun fromJson(o: JSONObject) = Video(
        o.getString("u"), o.optString("t"), o.optString("c"), o.optLong("v", -1),
        o.optString("d"), o.optLong("l"),
        o.optString("th").ifEmpty { null }, o.optString("a").ifEmpty { null }
    )

    private fun readArr(a: JSONArray): MutableList<Video> {
        val out = ArrayList<Video>()
        for (i in 0 until a.length()) out.add(fromJson(a.getJSONObject(i)))
        return out
    }

    private fun toArr(l: List<Video>): JSONArray {
        val a = JSONArray()
        l.forEach { a.put(toJson(it)) }
        return a
    }

    @Synchronized
    fun list(key: String): MutableList<Video> =
        try { readArr(JSONArray(sp.getString(key, "[]"))) } catch (e: Exception) { ArrayList() }

    @Synchronized
    private fun write(key: String, l: List<Video>) {
        sp.edit().putString(key, toArr(l).toString()).apply()
    }

    fun history(): List<Video> = list("hist")

    @Synchronized
    fun addHistory(v: Video) {
        val l = list("hist")
        l.removeAll { it.url == v.url }
        l.add(0, v)
        while (l.size > 100) l.removeAt(l.size - 1)
        write("hist", l)
    }

    fun clearHistory() = write("hist", emptyList())

    fun has(key: String, url: String) = list(key).any { it.url == url }

    /** Mengembalikan true jika video sekarang ada di daftar. */
    @Synchronized
    fun toggle(key: String, v: Video): Boolean {
        val l = list(key)
        val had = l.removeAll { it.url == v.url }
        if (!had) l.add(0, v)
        write(key, l)
        return !had
    }

    // ---- langganan
    @Synchronized
    fun subs(): List<Channel> = try {
        val a = JSONArray(sp.getString("subs", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Channel(o.getString("u"), o.optString("n"), o.optString("a").ifEmpty { null })
        }
    } catch (e: Exception) { emptyList() }

    fun isSub(url: String) = subs().any { it.url == url }

    @Synchronized
    fun toggleSub(c: Channel): Boolean {
        val l = subs().toMutableList()
        val had = l.removeAll { it.url == c.url }
        if (!had) l.add(0, c)
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("u", it.url).put("n", it.name).put("a", it.avatar ?: "")) }
        sp.edit().putString("subs", a.toString()).apply()
        return !had
    }

    // ---- daftar putar
    @Synchronized
    private fun readPl(): JSONObject = try { JSONObject(sp.getString("pl", "{}")) } catch (e: Exception) { JSONObject() }

    fun playlistNames(): List<String> {
        val o = readPl()
        return o.keys().asSequence().toList().sorted()
    }

    fun playlist(name: String): List<Video> =
        try { readArr(readPl().getJSONArray(name)) } catch (e: Exception) { emptyList() }

    @Synchronized
    fun createPlaylist(name: String) {
        val o = readPl()
        if (!o.has(name)) o.put(name, JSONArray())
        sp.edit().putString("pl", o.toString()).apply()
    }

    @Synchronized
    fun addToPlaylist(name: String, v: Video) {
        val o = readPl()
        val l = try { readArr(o.getJSONArray(name)) } catch (e: Exception) { ArrayList() }
        l.removeAll { it.url == v.url }
        l.add(0, v)
        o.put(name, toArr(l))
        sp.edit().putString("pl", o.toString()).apply()
    }

    @Synchronized
    fun deletePlaylist(name: String) {
        val o = readPl()
        o.remove(name)
        sp.edit().putString("pl", o.toString()).apply()
    }
}
