package com.novatube.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import java.util.concurrent.Executors

/** Callback Activity bila aplikasi terbuka (UI lengkap). Bila null, Service menangani sendiri. */
object PlaybackBus {
    @Volatile var onNext: (() -> Unit)? = null
    @Volatile var onPrev: (() -> Unit)? = null
}

/**
 * Pemutar di Service: audio tetap berjalan saat aplikasi ditutup. Notifikasi, layar kunci, dan tombol
 * Bluetooth/headset memakai MediaSession yang sama. Berikutnya/Sebelumnya dijalankan oleh Activity bila
 * terbuka, atau langsung oleh Service (mengambil stream sendiri) bila Activity sudah tertutup.
 */
class PlaybackService : MediaSessionService() {
    private lateinit var player: ExoPlayer
    private var session: MediaSession? = null
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var failStreak = 0

    inner class LocalBinder : Binder() {
        fun player(): ExoPlayer = player
    }

    private val binder = LocalBinder()

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (PlaybackBus.onNext != null) return // Activity yang menangani
            if (playbackState == Player.STATE_ENDED) {
                Now.markFinished(player)
                headlessNext(true)
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (!isPlaying && PlaybackBus.onNext == null) Now.saveProgress(player)
        }
    }

    /** Menampilkan tombol Berikutnya/Sebelumnya di notifikasi, layar kunci, dan Bluetooth. */
    private inner class QueuePlayer(p: Player) : ForwardingPlayer(p) {
        private val extra = intArrayOf(
            Player.COMMAND_SEEK_TO_NEXT,
            Player.COMMAND_SEEK_TO_PREVIOUS,
            Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
            Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM
        )

        override fun getAvailableCommands(): Player.Commands {
            val b = super.getAvailableCommands().buildUpon()
            for (c in extra) b.add(c)
            return b.build()
        }

        override fun isCommandAvailable(command: Int): Boolean = command in extra || super.isCommandAvailable(command)
        override fun hasNextMediaItem(): Boolean = true
        override fun hasPreviousMediaItem(): Boolean = true

        override fun seekToNext() {
            val f = PlaybackBus.onNext
            if (f != null) f() else headlessNext(false)
        }

        override fun seekToNextMediaItem() = seekToNext()

        override fun seekToPrevious() {
            val f = PlaybackBus.onPrev
            if (f != null) f() else headlessPrev()
        }

        override fun seekToPreviousMediaItem() = seekToPrevious()
    }

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Store.init(this)
        YtAuth.init(this)
        if (Queue.items.isEmpty()) Queue.load(Store.list("queue"))
        Queue.persist = { Store.setList("queue", it) }

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        player.addListener(listener)
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, QueuePlayer(player)).setSessionActivity(open).build()
    }

    // ------------------------------------------------------------ pemutaran tanpa Activity
    private fun headlessNext(auto: Boolean) {
        Now.video?.let { Queue.syncCurrent(it.url) }
        var next: Video? = Queue.advance()
        if (next == null) {
            if (auto && !Prefs.autoNext) return
            val cur = Util.videoKey(Now.video?.url ?: "")
            val list = Now.auto
            val idx = list.indexOfFirst { Util.videoKey(it.url) == cur }
            next = if (idx >= 0) list.getOrNull(idx + 1) else list.firstOrNull { Util.videoKey(it.url) != cur }
        }
        if (next != null) headlessPlay(next)
    }

    private fun headlessPrev() {
        Now.video?.let { Queue.syncCurrent(it.url) }
        val p = Queue.back()
        if (p == null) {
            player.seekTo(0)
            return
        }
        headlessPlay(p)
    }

    private fun headlessPlay(v: Video) {
        Now.saveProgress(player)
        Now.switching = true
        Now.ownerKey = ""
        Now.video = v
        io.execute {
            try {
                val si = Repo.stream(v.url)
                val opts = Repo.options(si, Prefs.audioQuality == 1)
                val rel = Repo.map(si.relatedItems)
                val aIdx = opts.indexOfFirst { it.audioOnly }
                val idx = if (aIdx >= 0) aIdx else Repo.pick(opts, Prefs.resolution, 0)
                val o = opts.getOrNull(idx) ?: throw IllegalStateException("tidak ada stream")
                val full = Video(
                    si.url ?: v.url, Util.htmlToText(si.name ?: v.title), si.uploaderName ?: v.channel,
                    si.viewCount, v.date, si.duration, Repo.thumb(si.thumbnails) ?: v.thumb, v.avatar
                )
                val built = PlayerFactory.build(this, o, full, null, null, false)
                val prog = Store.progress(full.url)
                val seek = if (Prefs.resumeProgress && prog != null && prog[0] > 8000 &&
                    (prog[1] <= 0 || prog[0] < prog[1] * 0.95)
                ) prog[0] else 0L
                Store.addHistory(full)
                main.post {
                    failStreak = 0
                    Now.video = full
                    Now.auto = listOf(full) + rel
                    Now.audioOnly = o.audioOnly
                    Now.ownerKey = Util.videoKey(full.url)
                    Now.switching = false
                    player.setMediaSource(built.source, seek)
                    player.prepare()
                    player.playWhenReady = true
                }
            } catch (e: Exception) {
                main.post {
                    Now.switching = false
                    // lewati ke video berikutnya bila gagal (maksimal 3 kali beruntun)
                    if (++failStreak <= 3) headlessNext(true)
                }
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onBind(intent: Intent?): IBinder? =
        if (intent?.action == ACTION_LOCAL) binder else super.onBind(intent)

    /** Aplikasi dibuang dari recent apps: tetap putar bila sedang memutar, berhenti bila tidak. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.playWhenReady || player.playbackState == Player.STATE_ENDED) {
            Now.saveProgress(player)
            stopSelf()
        }
    }

    override fun onDestroy() {
        Now.saveProgress(player)
        session?.release()
        session = null
        player.removeListener(listener)
        player.release()
        io.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val ACTION_LOCAL = "com.novatube.app.LOCAL"
    }
}
