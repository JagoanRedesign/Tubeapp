package com.novatube.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Jembatan: tombol notifikasi -> antrean di Activity (aktif selama aplikasi masih hidup). */
object PlaybackBus {
    @Volatile var onNext: (() -> Unit)? = null
    @Volatile var onPrev: (() -> Unit)? = null
}

/** Pemutar di service: audio tetap jalan di latar belakang + notifikasi dengan putar/jeda, berikutnya, sebelumnya. */
class PlaybackService : MediaSessionService() {
    private lateinit var player: ExoPlayer
    private var session: MediaSession? = null

    inner class LocalBinder : Binder() {
        fun player(): ExoPlayer = player
    }

    private val binder = LocalBinder()

    /** Membuat notifikasi menampilkan Berikutnya/Sebelumnya dan mengarahkannya ke antrean aplikasi. */
    private class QueuePlayer(p: Player) : ForwardingPlayer(p) {
        private val extra = intArrayOf(
            Player.COMMAND_SEEK_TO_NEXT,
            Player.COMMAND_SEEK_TO_PREVIOUS,
            Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
            Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM
        )

        override fun getAvailableCommands(): Player.Commands {
            val b = super.getAvailableCommands().buildUpon()
            for (c in extra) b.add(c)
            return b.build()
        }

        override fun isCommandAvailable(command: Int): Boolean = command in extra || super.isCommandAvailable(command)
        override fun hasNextMediaItem(): Boolean = true
        override fun hasPreviousMediaItem(): Boolean = true
        override fun seekToNext() { PlaybackBus.onNext?.invoke() }
        override fun seekToNextMediaItem() { PlaybackBus.onNext?.invoke() }
        override fun seekToPrevious() {
            val f = PlaybackBus.onPrev
            if (f != null) f() else super.seekToPrevious()
        }
        override fun seekToPreviousMediaItem() { seekToPrevious() }
    }

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, QueuePlayer(player)).setSessionActivity(open).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onBind(intent: Intent?): IBinder? =
        if (intent?.action == ACTION_LOCAL) binder else super.onBind(intent)

    override fun onDestroy() {
        session?.release()
        session = null
        player.release()
        super.onDestroy()
    }

    companion object {
        const val ACTION_LOCAL = "com.novatube.app.LOCAL"
    }
}
