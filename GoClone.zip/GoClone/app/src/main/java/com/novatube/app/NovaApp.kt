package com.novatube.app

import android.app.Application

/** Menginisialisasi semua singleton penyimpanan sekali di awal proses (Activity maupun Service). */
class NovaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Store.init(this)
        YtAuth.init(this)
    }
}
