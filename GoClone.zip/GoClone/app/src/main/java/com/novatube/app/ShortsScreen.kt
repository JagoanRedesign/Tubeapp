package com.novatube.app

import android.graphics.Color
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import coil.transform.CircleCropTransformation
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.schabi.newpipe.extractor.Page

/** Sumber daftar Shorts. [more] dipanggil di thread latar dan mengembalikan daftar kosong bila habis. */
interface ShortsFeed {
    fun more(): List<Video>
}

/** "Untukmu": hasil pencarian #shorts, disaring ke video pendek. */
class SearchShortsFeed(seed: List<String>) : ShortsFeed {
    private val queries = seed.shuffled()
    private var qi = 0
    private var page: Page? = null
    private var curQ: String? = null

    override fun more(): List<Video> {
        val out = ArrayList<Video>()
        var guard = 0
        while (out.size < 8 && guard++ < 6) {
            if (queries.isEmpty()) return emptyList()
            val q = curQ ?: queries[qi % queries.size].also { curQ = it; page = null }
            val pg = page
            val r = try {
                if (pg == null) Repo.search(q) else Repo.more(q, pg)
            } catch (e: Exception) {
                qi++
                curQ = null
                continue
            }
            page = r.next
            if (r.next == null) { qi++; curQ = null }
            out.addAll(r.items.filter { it.duration in 1..90 })
        }
        return out
    }
}

/** "Langganan": tab Shorts dari kanal yang diikuti. */
class ChannelShortsFeed(private val channels: List<Channel>) : ShortsFeed {
    private var i = 0

    override fun more(): List<Video> {
        val out = ArrayList<Video>()
        while (i < channels.size && out.size < 10) {
            val c = channels[i++]
            try {
                val h = Repo.channel(c.url).tabs["shorts"] ?: continue
                out.addAll(Repo.tab(h).items.filterIsInstance<Video>().take(6))
            } catch (e: Exception) {
            }
        }
        return out
    }
}

/** Daftar tetap (mis. dari tab Shorts kanal atau riwayat). */
class ListFeed : ShortsFeed {
    override fun more(): List<Video> = emptyList()
}

class ShortInfo(
    val option: Option,
    val description: String,
    val channel: Channel?,
    val likes: Long,
    val audioName: String,
    val title: String,
    val video: Video
)

/**
 * Halaman Shorts: video vertikal layar penuh, geser atas/bawah, putar otomatis, tap untuk jeda.
 * Memakai pemutar & sumber stream yang sama dengan pemutar utama (PlayerFactory), tetapi instance
 * ExoPlayer terpisah sehingga Resume Progress video biasa tidak terpengaruh.
 */
class ShortsScreen(private val a: MainActivity, root: View) {
    private val pager: ViewPager2 = root.findViewById(R.id.shortsPager)
    private val loading: ProgressBar = root.findViewById(R.id.shortsLoading)
    private val msg: TextView = root.findViewById(R.id.shortsMsg)
    private val muteBtn: ImageButton = root.findViewById(R.id.shortsMute)
    private val tabForYou: TextView = root.findViewById(R.id.shortsTabForYou)
    private val tabSubs: TextView = root.findViewById(R.id.shortsTabSubs)

    private val items = ArrayList<Video>()
    private val seen = HashSet<String>()
    private var feed: ShortsFeed? = null
    private var feedToken = 0
    private var loadingMore = false
    private var exhausted = false
    private var muted = false
    private var current = 0
    private var visible = false
    private val infos = HashMap<String, ShortInfo>()
    private val waiting = HashMap<String, MutableList<(ShortInfo?) -> Unit>>()
    private val holders = HashSet<VH>()
    private val adapter = PageAdapter()

    private val tick = object : Runnable {
        override fun run() {
            if (!visible) return
            holders.firstOrNull { it.pos == current }?.updateProgress()
            a.ui.postDelayed(this, 250)
        }
    }

    init {
        pager.orientation = ViewPager2.ORIENTATION_VERTICAL
        pager.adapter = adapter
        pager.offscreenPageLimit = 1
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                current = position
                holders.forEach { it.setActive(it.pos == position && visible) }
                if (visible) onSeen(position)
                if (position >= items.size - 3) loadMore(false)
                prefetch(position + 1)
            }
        })
        muteBtn.setOnClickListener {
            muted = !muted
            muteBtn.setImageResource(if (muted) R.drawable.ic_volume_off else R.drawable.ic_volume_up)
            holders.forEach { it.player?.volume = if (muted) 0f else 1f }
        }
        tabForYou.setOnClickListener { startForYou() }
        tabSubs.setOnClickListener { startSubs() }
    }

    private fun styleTabs(sel: Int) {
        val on = listOf(tabForYou, tabSubs)
        on.forEachIndexed { i, tv ->
            val s = i == sel
            tv.setBackgroundResource(if (s) R.drawable.bg_shorts_chip_sel else R.drawable.bg_shorts_chip)
            tv.setTextColor(if (s) Color.BLACK else Color.WHITE)
        }
    }

    fun ensureStarted() {
        if (feed == null) startForYou()
    }

    fun startForYou() {
        styleTabs(0)
        start(SearchShortsFeed(QUERIES))
    }

    fun startSubs() {
        val subs = Store.subs()
        if (subs.isEmpty()) {
            a.toast("Belum ada langganan")
            return
        }
        styleTabs(1)
        start(ChannelShortsFeed(subs))
    }

    /** Mulai sesi baru. [initial] ditampilkan lebih dulu, mulai dari [startIndex]. */
    fun start(f: ShortsFeed, initial: List<Video> = emptyList(), startIndex: Int = 0) {
        if (initial.isNotEmpty()) styleTabs(-1)
        holders.forEach { it.release() }
        feed = f
        feedToken++
        items.clear()
        seen.clear()
        exhausted = false
        loadingMore = false
        initial.forEach { addItem(it) }
        adapter.notifyDataSetChanged()
        msg.visibility = View.GONE
        if (items.isEmpty()) {
            loadMore(true)
        } else {
            val idx = startIndex.coerceIn(0, items.size - 1)
            current = idx
            pager.post { pager.setCurrentItem(idx, false) }
            if (items.size < 5) loadMore(false)
        }
    }

    private fun addItem(v: Video) {
        if (seen.add(Util.videoKey(v.url))) items.add(v)
    }

    private fun loadMore(first: Boolean) {
        val f = feed ?: return
        if (loadingMore || exhausted) return
        loadingMore = true
        if (first) loading.visibility = View.VISIBLE
        val my = feedToken
        a.io.execute {
            val list = try { f.more() } catch (e: Exception) { emptyList() }
            a.ui.post {
                if (my != feedToken) return@post
                loadingMore = false
                loading.visibility = View.GONE
                val before = items.size
                list.forEach { addItem(it) }
                if (list.isEmpty()) exhausted = true
                if (items.size > before) adapter.notifyItemRangeInserted(before, items.size - before)
                if (items.isEmpty()) {
                    msg.text = "Belum ada Shorts. Coba lagi nanti."
                    msg.visibility = View.VISIBLE
                }
            }
        }
    }

    // ------------------------------------------------------------ siklus tampil
    fun onShow() {
        visible = true
        try {
            a.pauseMain()
            holders.toList().forEach { holder ->
                runCatching { holder.prepareIfNeeded(); holder.setActive(holder.pos == current) }
                    .onFailure { android.util.Log.e("NovaTube", "Shorts player activation failed", it) }
            }
            onSeen(current)
            a.ui.removeCallbacks(tick)
            a.ui.postDelayed(tick, 250)
        } catch (e: Exception) {
            android.util.Log.e("NovaTube", "Shorts screen failed", e)
            msg.text = "Shorts tidak dapat dimuat. Coba lagi."
            msg.visibility = View.VISIBLE
            loading.visibility = View.GONE
        }
    }

    /** Berhenti & lepas pemutar saat keluar halaman. */
    fun onHide() {
        visible = false
        a.ui.removeCallbacks(tick)
        holders.toList().forEach { holder ->
            runCatching { holder.release() }
                .onFailure { android.util.Log.e("NovaTube", "Shorts player release failed", it) }
        }
    }

    fun release() {
        onHide()
        holders.clear()
    }

    private fun onSeen(pos: Int) {
        items.getOrNull(pos)?.let { Store.addTo("shorts_hist", it, 200) }
    }

    // ------------------------------------------------------------ info stream
    private fun prefetch(pos: Int) {
        items.getOrNull(pos)?.let { resolve(it) { } }
    }

    private fun resolve(v: Video, cb: (ShortInfo?) -> Unit) {
        val k = Util.videoKey(v.url)
        infos[k]?.let { cb(it); return }
        val l = waiting[k]
        if (l != null) { l.add(cb); return }
        waiting[k] = arrayListOf(cb)
        a.io.execute {
            val info = try { buildInfo(v) } catch (e: Exception) { null }
            a.ui.post {
                if (info != null) infos[k] = info
                waiting.remove(k)?.forEach { it(info) }
            }
        }
    }

    private fun buildInfo(v: Video): ShortInfo {
        val si = Repo.stream(v.url)
        val opts = Repo.options(si, false)
        val idx = Repo.pick(opts, 0, if (Repo.lowData) 360 else 720)
        val o = opts.getOrNull(idx)?.takeIf { !it.audioOnly && (it.video != null || it.hls != null) }
            ?: opts.firstOrNull { !it.audioOnly && it.video != null }
            ?: throw IllegalStateException("tidak ada stream")
        val chUrl = si.uploaderUrl
        val avatar = Repo.thumb(si.uploaderAvatars) ?: v.avatar
        val ch = if (!chUrl.isNullOrBlank()) Channel(chUrl, si.uploaderName ?: v.channel, avatar) else null
        val audio = Repo.audioTracks(si).firstOrNull()?.name
        val title = Util.htmlToText(si.name ?: v.title)
        val full = Video(si.url ?: v.url, title, si.uploaderName ?: v.channel, si.viewCount, v.date, si.duration, v.thumb, avatar)
        return ShortInfo(o, Util.htmlToText(si.description?.content), ch, si.likeCount, audio ?: "Suara asli", title, full)
    }

    // ------------------------------------------------------------ halaman
    private inner class PageAdapter : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(p: android.view.ViewGroup, t: Int): VH =
            VH(a.layoutInflater.inflate(R.layout.item_shorts_page, p, false))

        override fun getItemCount() = items.size
        override fun onBindViewHolder(h: VH, i: Int) = h.bind(i)
        override fun onViewAttachedToWindow(h: VH) { holders.add(h) }
        override fun onViewDetachedFromWindow(h: VH) { holders.remove(h); h.release() }
        override fun onViewRecycled(h: VH) { h.release() }
    }

    private inner class VH(val root: View) : RecyclerView.ViewHolder(root) {
        val thumb: ImageView = root.findViewById(R.id.spThumb)
        val playerView: PlayerView = root.findViewById(R.id.spPlayer)
        val loadingV: ProgressBar = root.findViewById(R.id.spLoading)
        val pauseIc: ImageView = root.findViewById(R.id.spPauseIc)
        val prog: ProgressBar = root.findViewById(R.id.spProg)
        val likeIc: ImageView = root.findViewById(R.id.spLikeIc)
        val likeN: TextView = root.findViewById(R.id.spLikeN)
        val disIc: ImageView = root.findViewById(R.id.spDisIc)
        val avatar: ImageView = root.findViewById(R.id.spAvatar)
        val channelV: TextView = root.findViewById(R.id.spChannel)
        val subV: TextView = root.findViewById(R.id.spSub)
        val titleV: TextView = root.findViewById(R.id.spTitle)
        val audioV: TextView = root.findViewById(R.id.spAudio)

        var pos = -1
        var video: Video? = null
        var info: ShortInfo? = null
        var player: ExoPlayer? = null
        var rating = "none"
        var ratingBase = "none"
        var subscribed = false

        init {
            root.setOnClickListener { togglePause() }
            root.findViewById<View>(R.id.spLike).setOnClickListener { rate("like") }
            root.findViewById<View>(R.id.spDis).setOnClickListener { rate("dislike") }
            root.findViewById<View>(R.id.spCom).setOnClickListener {
                video?.let { CommentsSheet(a, it.url, null, null).show() }
            }
            root.findViewById<View>(R.id.spShare).setOnClickListener { (info?.video ?: video)?.let { a.share(it) } }
            root.findViewById<View>(R.id.spInfo).setOnClickListener { showDesc() }
            titleV.setOnClickListener { showDesc() }
            subV.setOnClickListener { toggleSub() }
        }

        fun bind(i: Int) {
            release()
            pos = i
            val v = items[i]
            video = v
            info = null
            rating = "none"
            ratingBase = "none"
            subscribed = false
            thumb.visibility = View.VISIBLE
            thumb.load(v.thumb)
            loadingV.visibility = View.VISIBLE
            pauseIc.visibility = View.GONE
            prog.progress = 0
            titleV.text = v.title
            channelV.text = v.channel
            audioV.text = ""
            likeN.text = "Suka"
            val av = v.avatar
            if (av != null) avatar.load(av) { transformations(CircleCropTransformation()) } else avatar.setImageDrawable(null)
            styleLike()
            styleSub()
            resolve(v) { inf -> if (video === v) onInfo(inf) }
        }

        private fun onInfo(inf: ShortInfo?) {
            if (inf == null) {
                loadingV.visibility = View.GONE
                audioV.text = "Gagal memuat video ini. Geser untuk lanjut."
                return
            }
            info = inf
            titleV.text = inf.title
            audioV.text = "♫ ${inf.audioName} · ${inf.video.channel}"
            likeN.text = if (inf.likes >= 0) Fmt.compact(inf.likes) else "Suka"
            inf.channel?.let { ch ->
                channelV.text = ch.name
                val av = ch.avatar
                if (av != null) avatar.load(av) { transformations(CircleCropTransformation()) }
                Social.loadSub(a, ch) { on -> if (info === inf) { subscribed = on; styleSub() } }
            }
            Social.loadRating(a, inf.video) { r ->
                if (info === inf) { rating = r; ratingBase = r; styleLike() }
            }
            prepareIfNeeded()
        }

        fun prepareIfNeeded() {
            val inf = info ?: return
            if (player != null) return
            val p = ExoPlayer.Builder(a).build()
            p.setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true
            )
            p.repeatMode = Player.REPEAT_MODE_ONE
            p.volume = if (muted) 0f else 1f
            p.addListener(object : Player.Listener {
                override fun onRenderedFirstFrame() {
                    thumb.visibility = View.GONE
                    loadingV.visibility = View.GONE
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_BUFFERING) loadingV.visibility = View.VISIBLE
                    else if (playbackState == Player.STATE_READY) loadingV.visibility = View.GONE
                }

                override fun onPlayerError(error: PlaybackException) {
                    loadingV.visibility = View.GONE
                    audioV.text = "Gagal memutar (${error.errorCodeName}). Geser untuk lanjut."
                }
            })
            playerView.player = p
            val built = PlayerFactory.build(a, inf.option, inf.video, null, null, false)
            p.setMediaSource(built.source)
            p.prepare()
            p.playWhenReady = pos == current && visible
            player = p
        }

        fun setActive(on: Boolean) {
            val p = player ?: return
            if (on) {
                p.volume = if (muted) 0f else 1f
                p.playWhenReady = true
            } else {
                p.pause()
                p.seekTo(0)
            }
            pauseIc.visibility = View.GONE
        }

        fun release() {
            val p = player ?: return
            playerView.player = null
            p.release()
            player = null
            thumb.visibility = View.VISIBLE
        }

        fun updateProgress() {
            val p = player ?: return
            val d = p.duration
            if (d > 0) prog.progress = (p.currentPosition * 1000 / d).toInt()
        }

        private fun togglePause() {
            val p = player ?: return
            if (p.isPlaying) {
                p.pause()
                pauseIc.setImageResource(R.drawable.ic_play)
                pauseIc.visibility = View.VISIBLE
            } else {
                p.play()
                pauseIc.visibility = View.GONE
            }
        }

        private fun styleLike() {
            val accent = a.getColor(R.color.accent)
            likeIc.setColorFilter(if (rating == "like") accent else Color.WHITE)
            disIc.setColorFilter(if (rating == "dislike") accent else Color.WHITE)
            val base = info?.likes ?: -1L
            if (base >= 0) {
                val n = base + (if (rating == "like") 1 else 0) - (if (ratingBase == "like") 1 else 0)
                likeN.text = Fmt.compact(n.coerceAtLeast(0))
            }
        }

        private fun styleSub() {
            subV.text = if (subscribed) "TERLANGGANAN" else "BERLANGGANAN"
            subV.setBackgroundResource(if (subscribed) R.drawable.bg_sub_btn_off else R.drawable.bg_sub_btn)
            subV.visibility = if (info?.channel == null && info != null) View.GONE else View.VISIBLE
        }

        private fun rate(kind: String) {
            val inf = info ?: return
            val want = if (rating == kind) "none" else kind
            Social.setRating(a, inf.video, want) { ok, r ->
                if (ok && info === inf) { rating = r; styleLike() }
            }
        }

        private fun toggleSub() {
            val inf = info ?: return
            val ch = inf.channel ?: return
            Social.toggleSub(a, ch) { on ->
                if (info === inf) { subscribed = on; styleSub() }
                a.toast(if (on) "Berlangganan ${ch.name}" else "Berhenti berlangganan")
            }
        }

        private fun showDesc() {
            val inf = info ?: return
            val sb = StringBuilder()
            sb.append(inf.description.ifBlank { "Tidak ada deskripsi." })
            sb.append("\n\n♫ Audio: ${inf.audioName} · ${inf.video.channel}")
            MaterialAlertDialogBuilder(a)
                .setTitle(inf.title)
                .setMessage(sb.toString())
                .setPositiveButton("Tutup", null)
                .setNeutralButton("Putar audio saja") { _, _ -> a.openVideo(inf.video, audio = true, show = false) }
                .show()
        }
    }

    companion object {
        private val QUERIES = listOf(
            "#shorts viral indonesia", "#shorts lucu", "#shorts musik", "#shorts gaming",
            "#shorts olahraga", "#shorts kuliner", "#shorts teknologi"
        )
    }
}
