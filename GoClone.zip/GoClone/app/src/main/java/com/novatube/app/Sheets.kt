package com.novatube.app

import android.content.Context
import android.view.View
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

/** Bottom sheet tinggi (default 88% layar) dan langsung terbuka penuh. */
fun BottomSheetDialog.expandTall(ctx: Context, frac: Float = 0.88f) {
    setOnShowListener {
        val sheet = findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
        sheet?.layoutParams?.height = (ctx.resources.displayMetrics.heightPixels * frac).toInt()
        sheet?.let { BottomSheetBehavior.from(it).state = BottomSheetBehavior.STATE_EXPANDED }
    }
}
