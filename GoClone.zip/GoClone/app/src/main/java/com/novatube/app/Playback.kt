package com.novatube.app

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.source.SingleSampleMediaSource

/**
 * Status "sedang diputar" yang dipakai bersama oleh Activity dan Service,
 * termasuk penjaga Resume Progress agar posisi tidak pernah tertulis ke video yang salah.
 */
object Now {
    @Volatile var video: Video? = null
    @Volatile var auto: List<Video> = emptyList()
    @Volatile var audioOnly = false

    /** ID video pemilik media yang saat ini dimuat di pemutar. Kosong saat pergantian video. */
    @Volatile var ownerKey = ""

    /** True sejak pergantian video dimulai sampai sumber media baru dipasang. */
    @Volatile var switching = false

    /** Aturan murni: posisi hanya disimpan jika pemilik media = video yang sama dan pemutar siap. */
    fun canSave(owner: String, videoKey: String, switching: Boolean, state: Int, duration: Long, pos: Long): Boolean =
        !switching && owner.isNotEmpty() && owner == videoKey &&
            state == Player.STATE_READY && duration > 0 && pos > 3000

    fun saveProgress(p: Player) {
        val v = video ?: return
        if (p.mediaItemCount == 0) return
        if (canSave(ownerKey, Util.videoKey(v.url), switching, p.playbackState, p.duration, p.currentPosition)) {
            Store.saveProgress(v.url, p.currentPosition, p.duration)
        }
    }

    fun markFinished(p: Player?) {
        val v = video ?: return
        if (p == null || switching || ownerKey.isEmpty() || ownerKey != Util.videoKey(v.url)) return
        val d = p.duration
        if (d > 0) Store.saveProgress(v.url, d, d)
    }
}

class Built(val source: MediaSource, val warn: String?)

/** Pembuat sumber media yang sama untuk pemutar utama, Service (latar belakang), dan Shorts. */
object PlayerFactory {
    fun dsFactory(ctx: Context, url: String): DefaultDataSource.Factory =
        DefaultDataSource.Factory(
            ctx,
            DefaultHttpDataSource.Factory()
                .setUserAgent(Repo.uaFor(url))
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000)
        )

    fun meta(v: Video?): MediaMetadata =
        MediaMetadata.Builder()
            .setTitle(v?.title ?: "")
            .setArtist(v?.channel ?: "")
            .apply { v?.thumb?.let { setArtworkUri(Uri.parse(it)) } }
            .build()

    fun build(ctx: Context, o: Option, v: Video?, audioOverride: AudioTrack?, sub: SubTrack?, local: Boolean): Built {
        val md = meta(v)
        fun item(u: String) = MediaItem.Builder().setUri(u).setMediaMetadata(md).build()
        fun prog(u: String): MediaSource = ProgressiveMediaSource.Factory(dsFactory(ctx, u)).createMediaSource(item(u))

        val hls = o.hls?.takeIf { it.isNotBlank() }
        if (hls != null) return Built(HlsMediaSource.Factory(dsFactory(ctx, hls)).createMediaSource(item(hls)), null)

        var warn: String? = null
        var videoUrl = o.video
        var audioUrl = o.audio
        if (audioOverride != null && !local) {
            when {
                o.audioOnly -> audioUrl = audioOverride.url
                o.muxed -> {
                    if (o.altVideo != null) {
                        videoUrl = o.altVideo
                        audioUrl = audioOverride.url
                    } else {
                        warn = "Trek audio ini hanya tersedia untuk kualitas HD"
                    }
                }
                else -> audioUrl = audioOverride.url
            }
        }
        val parts = ArrayList<MediaSource>()
        videoUrl?.takeIf { it.isNotBlank() }?.let { parts.add(prog(it)) }
        audioUrl?.takeIf { it.isNotBlank() }?.let { parts.add(prog(it)) }
        if (sub != null && sub.url.isNotBlank() && !o.audioOnly && !local) {
            val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub.url))
                .setMimeType(sub.mime)
                .setLanguage(sub.lang)
                .setLabel(sub.label)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            parts.add(SingleSampleMediaSource.Factory(dsFactory(ctx, sub.url)).createMediaSource(cfg, C.TIME_UNSET))
        }
        // MergingMediaSource memerlukan sedikitnya dua sumber. Jangan membuat
        // media source kosong atau merger satu sumber ketika extractor gagal.
        if (parts.isEmpty()) throw IllegalArgumentException("Tidak ada URL stream yang valid")
        val src = when (parts.size) {
            1 -> parts.first()
            else -> MergingMediaSource(*parts.toTypedArray())
        }
        return Built(src, warn)
    }
}
