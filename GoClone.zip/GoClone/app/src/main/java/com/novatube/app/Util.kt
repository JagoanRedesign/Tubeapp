package com.novatube.app

import java.util.Locale

/** Fungsi murni (mudah diuji tanpa Android). */
object Util {
    private val idRe = Regex("(?:[?&]v=|youtu\\.be/|/shorts/|/live/|/embed/)([A-Za-z0-9_-]{11})")

    /** ID video 11 karakter bila ada, jika tidak URL apa adanya. */
    fun videoKey(url: String): String = idRe.find(url)?.groupValues?.get(1) ?: url

    fun sanitize(name: String): String {
        val s = name.replace(Regex("[\\\\/:*?\"<>|\\r\\n]"), " ").replace(Regex("\\s+"), " ").trim().take(60)
        return s.ifEmpty { "video" }
    }

    fun clock(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private val ageRe = Regex(
        "(\\d+)\\s*(detik|menit|jam|hari|minggu|bulan|tahun|second|minute|hour|day|week|month|year)",
        RegexOption.IGNORE_CASE
    )

    /** "3 minggu lalu" -> milidetik; -1 bila tidak dikenali. */
    fun ageMs(text: String): Long {
        val m = ageRe.find(text) ?: return -1
        val n = m.groupValues[1].toLongOrNull() ?: return -1
        val unit = when (m.groupValues[2].lowercase()) {
            "detik", "second" -> 1_000L
            "menit", "minute" -> 60_000L
            "jam", "hour" -> 3_600_000L
            "hari", "day" -> 86_400_000L
            "minggu", "week" -> 604_800_000L
            "bulan", "month" -> 2_592_000_000L
            else -> 31_536_000_000L
        }
        return n * unit
    }
}
