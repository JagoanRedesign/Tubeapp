package com.novatube.app

import java.util.Locale

/** Fungsi murni (mudah diuji tanpa Android). */
object Util {
    private val idRe = Regex("(?:[?&]v=|youtu\\.be/|/shorts/|/live/|/embed/)([A-Za-z0-9_-]{11})")

    /** ID video 11 karakter bila ada, jika tidak URL apa adanya. */
    fun videoKey(url: String): String = idRe.find(url)?.groupValues?.get(1) ?: url

    fun sanitize(name: String): String {
        val s = name.replace(Regex("[\\\\/:*?\"<>|\\r\\n]"), " ").replace(Regex("\\s+"), " ").trim().take(60)
        return s.ifEmpty { "video" }
    }

    fun clock(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private val ageRe = Regex(
        "(\\d+)\\s*(detik|menit|jam|hari|minggu|bulan|tahun|second|minute|hour|day|week|month|year)",
        RegexOption.IGNORE_CASE
    )

    /** "3 minggu lalu" -> milidetik; -1 bila tidak dikenali. */
    fun ageMs(text: String): Long {
        val m = ageRe.find(text) ?: return -1
        val n = m.groupValues[1].toLongOrNull() ?: return -1
        val unit = when (m.groupValues[2].lowercase()) {
            "detik", "second" -> 1_000L
            "menit", "minute" -> 60_000L
            "jam", "hour" -> 3_600_000L
            "hari", "day" -> 86_400_000L
            "minggu", "week" -> 604_800_000L
            "bulan", "month" -> 2_592_000_000L
            else -> 31_536_000_000L
        }
        return n * unit
    }

    private val isoRe = Regex("^\\d{4}-\\d{2}-\\d{2}[T ]\\d{2}:\\d{2}(:\\d{2})?(\\.\\d+)?(Z|[+-]\\d{2}:?\\d{2})?$")
    private val monthNames = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    /** "2026-11-16T21:30:27-08:00" -> "3 hari lalu". Teks non-ISO dikembalikan apa adanya. */
    fun simpleDate(raw: String, now: java.time.OffsetDateTime = java.time.OffsetDateTime.now()): String {
        val t = raw.trim()
        if (!isoRe.matches(t)) return raw
        val n = t.replace(' ', 'T')
        val d: java.time.OffsetDateTime = try {
            java.time.OffsetDateTime.parse(n)
        } catch (e: Exception) {
            try {
                java.time.LocalDateTime.parse(n.take(19)).atZone(java.time.ZoneId.systemDefault()).toOffsetDateTime()
            } catch (e2: Exception) {
                return raw
            }
        }
        val secs = java.time.Duration.between(d.toInstant(), now.toInstant()).seconds
        if (secs < 0) return "${d.dayOfMonth} ${monthNames[d.monthValue - 1]} ${d.year}"
        val m = secs / 60
        val h = m / 60
        val days = h / 24
        return when {
            secs < 60 -> "baru saja"
            m < 60 -> "$m menit lalu"
            h < 24 -> "$h jam lalu"
            days < 7 -> "$days hari lalu"
            days < 30 -> "${days / 7} minggu lalu"
            days < 365 -> "${days / 30} bulan lalu"
            else -> "${days / 365} tahun lalu"
        }
    }

    /** Ubah HTML mentah (<br>, <a>, &amp; ...) menjadi teks biasa. */
    fun htmlToText(raw: String?): String {
        if (raw.isNullOrEmpty()) return ""
        if (raw.indexOf('<') < 0 && raw.indexOf('&') < 0) return raw
        var s: String = raw
        s = s.replace(Regex("(?i)<br\\s*/?>"), "\n")
        s = s.replace(Regex("(?i)</(p|div|li|h[1-6])>"), "\n")
        s = s.replace(Regex("(?i)<li[^>]*>"), "• ")
        s = s.replace(Regex("<[^>]+>"), "")
        s = decodeEntities(s)
        s = s.replace(Regex("[ \\t]+\\n"), "\n").replace(Regex("\\n{3,}"), "\n\n")
        return s.trim()
    }

    private fun codePoint(cp: Int?, fallback: String): String {
        if (cp == null) return fallback
        return try { String(Character.toChars(cp)) } catch (e: Exception) { fallback }
    }

    private fun decodeEntities(t: String): String {
        var s = t.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
        s = Regex("&#(\\d+);").replace(s) { m -> codePoint(m.groupValues[1].toIntOrNull(), m.value) }
        s = Regex("&#[xX]([0-9a-fA-F]+);").replace(s) { m -> codePoint(m.groupValues[1].toIntOrNull(16), m.value) }
        return s.replace("&amp;", "&")
    }

    private val chRe = Regex("/channel/(UC[A-Za-z0-9_-]{22})")

    /** ID kanal "UC..." dari URL kanal, atau null. */
    fun channelId(url: String): String? = chRe.find(url)?.groupValues?.get(1)

    /** Umur teks tanggal (ms) untuk pengurutan: makin kecil makin baru; tidak dikenal = Long.MAX_VALUE. */
    fun ageOf(date: String): Long {
        val s = simpleDate(date)
        if (s == "baru saja") return 0
        val a = ageMs(s)
        return if (a < 0) Long.MAX_VALUE else a
    }
}
