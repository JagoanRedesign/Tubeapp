package com.novatube.app

import androidx.media3.common.MimeTypes
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.comments.CommentsInfoItem
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
private const val UA_ANDROID = "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"
private const val UA_IOS = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"

data class Video(
    val url: String,
    val title: String,
    val channel: String,
    val views: Long,
    val date: String,
    val duration: Long,
    val thumb: String?,
    val avatar: String? = null
)

/** Satu pilihan kualitas pemutaran. */
class Option(
    val label: String,
    val video: String?,
    val audio: String?,
    val hls: String? = null,
    val height: Int = 0,
    val muxed: Boolean = false,
    val audioOnly: Boolean = false,
    /** Video-only setara, dipakai bila trek audio lain dipilih pada kualitas langsung. */
    val altVideo: String? = null
)

data class PlaylistRef(val url: String, val name: String, val thumb: String?, val count: Long, val owner: String)

class ChannelData(
    val url: String,
    val name: String,
    val avatar: String?,
    val banner: String?,
    val subs: Long,
    val desc: String,
    val verified: Boolean,
    val tabs: Map<String, ListLinkHandler>
)

class TabPage(val items: List<Any>, val next: Page?)
class PlaylistPage(val name: String, val items: List<Video>, val next: Page?)

class Comment(
    val id: String,
    val author: String,
    val avatar: String?,
    val text: String,
    val date: String,
    val likes: Int,
    val likesText: String,
    val replies: Int,
    val repliesPage: Page?,
    val hearted: Boolean,
    val pinned: Boolean,
    val owner: Boolean,
    val verified: Boolean,
    val ts: Long
)

class CommentsPage(val items: List<Comment>, val next: Page?, val disabled: Boolean)

class SubTrack(val lang: String, val label: String, val url: String, val mime: String, val auto: Boolean)
class AudioTrack(val id: String, val name: String, val url: String, val original: Boolean)

class DownloaderImpl : Downloader() {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override fun execute(request: Request): Response {
        val method = request.httpMethod()
        val data = request.dataToSend()
        val body = when {
            data != null -> data.toRequestBody()
            method == "POST" || method == "PUT" -> ByteArray(0).toRequestBody()
            else -> null
        }
        val b = okhttp3.Request.Builder().method(method, body).url(request.url()).header("User-Agent", UA)
        for ((k, vs) in request.headers()) {
            b.removeHeader(k)
            for (v in vs) b.addHeader(k, v)
        }
        client.newCall(b.build()).execute().use { r ->
            if (r.code == 429) throw ReCaptchaException("reCaptcha diminta", request.url())
            val text = r.body?.string() ?: ""
            return Response(r.code, r.message, r.headers.toMultimap(), text, r.request.url.toString())
        }
    }
}

object Fmt {
    private val id = Locale("id", "ID")

    fun compact(n: Long): String = when {
        n < 0 -> ""
        n >= 1_000_000_000 -> String.format(id, "%.1f M", n / 1e9)
        n >= 1_000_000 -> String.format(id, "%.1f jt", n / 1e6)
        n >= 1_000 -> String.format(id, "%.1f rb", n / 1e3)
        else -> n.toString()
    }

    fun views(n: Long): String = if (n < 0) "" else compact(n) + " x ditonton"

    fun subs(n: Long): String = if (n < 0) "" else compact(n) + " subscriber"

    fun duration(sec: Long): String = if (sec <= 0) "" else Util.clock(sec * 1000)

    fun meta(v: Video): String =
        listOf(v.channel, compact(v.views), v.date).filter { it.isNotBlank() }.joinToString(" • ")
}

object Repo {
    class Result(val items: List<Video>, val next: Page?)

    @Volatile private var inited = false

    /** Mode hemat data: thumbnail kecil, kualitas rendah, komentar dimuat saat dibuka. */
    @Volatile var lowData = false

    @Synchronized
    fun init() {
        if (inited) return
        NewPipe.init(DownloaderImpl(), Localization("id", "ID"), ContentCountry("ID"))
        inited = true
    }

    /** User-Agent harus cocok dengan klien yang menghasilkan URL stream (param c=). */
    fun uaFor(url: String): String = when {
        url.contains("c=IOS") -> UA_IOS
        url.contains("c=ANDROID") -> UA_ANDROID
        else -> UA
    }

    fun thumb(list: List<Image>?): String? {
        if (list.isNullOrEmpty()) return null
        val target = if (lowData) 180 else 360
        return list.minByOrNull { abs((if (it.height > 0) it.height else target) - target) }?.url
    }

    private fun toVideo(it: StreamInfoItem) = Video(
        it.url, it.name ?: "", it.uploaderName ?: "", it.viewCount,
        it.textualUploadDate ?: "", it.duration, thumb(it.thumbnails), thumb(it.uploaderAvatars)
    )

    fun map(items: List<InfoItem>): List<Video> = items.filterIsInstance<StreamInfoItem>().map { toVideo(it) }

    private fun mapAny(items: List<InfoItem>): List<Any> = items.mapNotNull {
        when (it) {
            is StreamInfoItem -> toVideo(it)
            is PlaylistInfoItem -> PlaylistRef(it.url, it.name ?: "", thumb(it.thumbnails), it.streamCount, it.uploaderName ?: "")
            else -> null
        }
    }

    // ------------------------------------------------------------ pencarian
    fun search(q: String): Result {
        init()
        val yt = ServiceList.YouTube
        val h = yt.searchQHFactory.fromQuery(q, listOf("videos"), "")
        val info = SearchInfo.getInfo(yt, h)
        return Result(map(info.relatedItems), info.nextPage)
    }

    fun more(q: String, page: Page): Result {
        init()
        val yt = ServiceList.YouTube
        val h = yt.searchQHFactory.fromQuery(q, listOf("videos"), "")
        val p = SearchInfo.getMoreItems(yt, h, page)
        return Result(map(p.items), p.nextPage)
    }

    fun stream(url: String): StreamInfo {
        init()
        return StreamInfo.getInfo(url)
    }

    // ------------------------------------------------------------ kanal
    fun channel(url: String): ChannelData {
        init()
        val ci = ChannelInfo.getInfo(url)
        val tabs = LinkedHashMap<String, ListLinkHandler>()
        for (h in ci.tabs) {
            val k = h.contentFilters.firstOrNull()?.lowercase() ?: continue
            tabs[k] = h
        }
        return ChannelData(
            ci.url ?: url, ci.name ?: "", thumb(ci.avatars), thumb(ci.banners),
            ci.subscriberCount, ci.description ?: "", ci.isVerified, tabs
        )
    }

    fun tab(h: ListLinkHandler): TabPage {
        init()
        val ti = ChannelTabInfo.getInfo(ServiceList.YouTube, h)
        return TabPage(mapAny(ti.relatedItems), ti.nextPage)
    }

    fun tabMore(h: ListLinkHandler, page: Page): TabPage {
        init()
        val p = ChannelTabInfo.getMoreItems(ServiceList.YouTube, h, page)
        return TabPage(mapAny(p.items), p.nextPage)
    }

    // ------------------------------------------------------------ playlist
    fun playlist(url: String): PlaylistPage {
        init()
        val pi = PlaylistInfo.getInfo(url)
        return PlaylistPage(pi.name ?: "", map(pi.relatedItems), pi.nextPage)
    }

    fun playlistMore(url: String, page: Page): PlaylistPage {
        init()
        val p = PlaylistInfo.getMoreItems(ServiceList.YouTube, url, page)
        return PlaylistPage("", map(p.items), p.nextPage)
    }

    // ------------------------------------------------------------ subtitle & trek audio
    fun subtitles(info: StreamInfo): List<SubTrack> {
        val out = ArrayList<SubTrack>()
        for (s in info.subtitles) {
            if (!s.isUrl) continue
            val mime = when (s.format) {
                MediaFormat.VTT -> MimeTypes.TEXT_VTT
                MediaFormat.TTML -> MimeTypes.APPLICATION_TTML
                MediaFormat.SRT -> MimeTypes.APPLICATION_SUBRIP
                else -> continue
            }
            val tag = s.languageTag ?: ""
            out.add(SubTrack(tag, s.displayLanguageName ?: tag, s.content, mime, s.isAutoGenerated))
        }
        // satu entri per bahasa+jenis, subtitle manual lebih dulu
        return out.distinctBy { it.lang + it.auto }.sortedWith(compareBy({ it.auto }, { it.label }))
    }

    fun audioTracks(info: StreamInfo): List<AudioTrack> {
        val groups = info.audioStreams.filter { it.isUrl }.groupBy { it.audioTrackId ?: "" }
        if (groups.size <= 1) return emptyList()
        val list = groups.map { (id, streams) ->
            val pool = streams.filter { it.format == MediaFormat.M4A }.ifEmpty { streams }
            val best = pool.maxByOrNull { it.averageBitrate }!!
            val name = best.audioTrackName ?: best.audioLocale?.displayLanguage ?: id.ifEmpty { "Asli" }
            AudioTrack(id, name, best.content, name.contains("asli", true) || name.contains("original", true))
        }
        return list.sortedByDescending { it.original }
    }

    // ------------------------------------------------------------ komentar
    private fun toComment(it: CommentsInfoItem): Comment {
        val date = it.textualUploadDate ?: ""
        val real = try { it.uploadDate?.offsetDateTime()?.toInstant()?.toEpochMilli() ?: 0L } catch (e: Exception) { 0L }
        val ts = if (real > 0) real else {
            val age = Util.ageMs(date)
            if (age >= 0) System.currentTimeMillis() - age else 0L
        }
        return Comment(
            it.commentId ?: "", it.uploaderName ?: "", thumb(it.uploaderAvatars),
            it.commentText?.content ?: "", date, it.likeCount, it.textualLikeCount ?: "",
            it.replyCount, it.replies, it.isHeartedByUploader, it.isPinned,
            it.isChannelOwner, it.isUploaderVerified, ts
        )
    }

    // ------------------------------------------------------------ opsi kualitas
    /** muxed (langsung) -> HD (video+audio digabung) -> audio saja. */
    fun options(info: StreamInfo, lowAudio: Boolean): List<Option> {
        val out = ArrayList<Option>()
        val audios = info.audioStreams.filter { it.isUrl }
        val bestAudio = audios.filter { it.format == MediaFormat.M4A }.maxByOrNull { it.averageBitrate }
            ?: audios.maxByOrNull { it.averageBitrate }
        val audioOnlyStream =
            if (lowAudio) audios.minByOrNull { if (it.averageBitrate > 0) it.averageBitrate else Int.MAX_VALUE } else bestAudio
        val altVids = info.videoOnlyStreams.filter { it.isUrl && it.format == MediaFormat.MPEG_4 }

        info.videoStreams.filter { it.isUrl }.sortedByDescending { it.height }.forEach { s ->
            val alt = altVids.filter { it.height <= s.height }.maxByOrNull { it.height } ?: altVids.minByOrNull { it.height }
            out.add(Option(s.resolution, s.content, null, height = s.height, muxed = true, altVideo = alt?.content))
        }
        if (bestAudio != null) {
            altVids.sortedByDescending { it.height }.distinctBy { it.height }.forEach {
                out.add(Option(it.resolution + " HD", it.content, bestAudio.content, height = it.height))
            }
        }
        val hls = info.hlsUrl
        if (!hls.isNullOrBlank() && out.isEmpty()) {
            out.add(Option("Siaran langsung", null, null, hls = hls, muxed = true))
        }
        if (audioOnlyStream != null) {
            out.add(Option("Audio saja", null, audioOnlyStream.content, audioOnly = true))
        }
        return out
    }

    /**
     * Pilih opsi awal. "Otomatis" (target 0) memilih stream langsung terbaik (paling andal);
     * gabungan HD hanya dipakai bila dipilih eksplisit atau tidak ada stream langsung.
     * [cap] membatasi tinggi maksimum (mis. mode hemat data), 0 = tanpa batas.
     */
    fun pick(opts: List<Option>, target: Int, cap: Int = 0): Int {
        val vids = opts.withIndex().filter { !it.value.audioOnly && it.value.height > 0 }
        if (vids.isEmpty()) return opts.indexOfFirst { !it.audioOnly }.let { if (it >= 0) it else 0 }
        var limit = if (target == 0) Int.MAX_VALUE else target
        if (cap > 0) limit = minOf(limit, cap)
        val le = vids.filter { it.value.height <= limit }
        val pool = if (target == 0) {
            le.filter { it.value.muxed }.ifEmpty { le.filter { it.value.height <= 480 }.ifEmpty { le } }
        } else le
        val best = if (pool.isNotEmpty()) pool.maxWithOrNull(compareBy({ it.value.height }, { it.value.muxed }))
        else vids.minByOrNull { it.value.height }
        return best?.index ?: 0
    }

    /** Opsi cadangan jika pemutaran gagal: stream langsung dulu, lalu video terendah, terakhir audio. */
    fun fallback(opts: List<Option>, tried: Set<Int>): Int {
        val rest = opts.withIndex().filter { it.index !in tried }
        rest.firstOrNull { it.value.muxed && !it.value.audioOnly }?.let { return it.index }
        rest.filter { !it.value.audioOnly }.minByOrNull { it.value.height }?.let { return it.index }
        rest.firstOrNull()?.let { return it.index }
        return -1
    }

    // ------------------------------------------------------------ sesi komentar
    class CommentsSession(url: String) {
        private val ex = run {
            init()
            ServiceList.YouTube.getCommentsExtractor(url).also { it.fetchPage() }
        }

        fun first(): CommentsPage {
            if (ex.isCommentsDisabled) return CommentsPage(emptyList(), null, true)
            val p = ex.initialPage
            return CommentsPage(p.items.map { toComment(it) }, p.nextPage, false)
        }

        fun more(page: Page): CommentsPage {
            val p = ex.getPage(page)
            return CommentsPage(p.items.map { toComment(it) }, p.nextPage, false)
        }
    }
}

typealias CommentsSession = Repo.CommentsSession
