package com.novatube.app

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"

data class Video(
    val url: String,
    val title: String,
    val channel: String,
    val views: Long,
    val date: String,
    val duration: Long,
    val thumb: String?,
    val avatar: String? = null
)

/** Satu pilihan kualitas pemutaran. */
class Option(
    val label: String,
    val video: String?,
    val audio: String?,
    val hls: String? = null,
    val height: Int = 0,
    val muxed: Boolean = false,
    val audioOnly: Boolean = false
)

class DownloaderImpl : Downloader() {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override fun execute(request: Request): Response {
        val method = request.httpMethod()
        val data = request.dataToSend()
        val body = when {
            data != null -> data.toRequestBody()
            method == "POST" || method == "PUT" -> ByteArray(0).toRequestBody()
            else -> null
        }
        val b = okhttp3.Request.Builder().method(method, body).url(request.url()).header("User-Agent", UA)
        for ((k, vs) in request.headers()) {
            b.removeHeader(k)
            for (v in vs) b.addHeader(k, v)
        }
        client.newCall(b.build()).execute().use { r ->
            if (r.code == 429) throw ReCaptchaException("reCaptcha diminta", request.url())
            val text = r.body?.string() ?: ""
            return Response(r.code, r.message, r.headers.toMultimap(), text, r.request.url.toString())
        }
    }
}

object Fmt {
    private val id = Locale("id", "ID")

    fun compact(n: Long): String = when {
        n < 0 -> ""
        n >= 1_000_000_000 -> String.format(id, "%.1f M", n / 1e9)
        n >= 1_000_000 -> String.format(id, "%.1f jt", n / 1e6)
        n >= 1_000 -> String.format(id, "%.1f rb", n / 1e3)
        else -> n.toString()
    }

    fun views(n: Long): String = if (n < 0) "" else compact(n) + " x ditonton"

    fun subs(n: Long): String = if (n < 0) "" else compact(n) + " subscriber"

    fun duration(sec: Long): String {
        if (sec <= 0) return ""
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    /** "KANAL • 839 rb • 1 bln lalu" */
    fun meta(v: Video): String =
        listOf(v.channel, compact(v.views), v.date).filter { it.isNotBlank() }.joinToString(" • ")
}

object Repo {
    class Result(val items: List<Video>, val next: Page?)

    @Volatile private var inited = false

    @Synchronized
    fun init() {
        if (inited) return
        NewPipe.init(DownloaderImpl(), Localization("id", "ID"), ContentCountry("ID"))
        inited = true
    }

    fun thumb(list: List<Image>?): String? {
        if (list.isNullOrEmpty()) return null
        return list.minByOrNull { abs((if (it.height > 0) it.height else 360) - 360) }?.url
    }

    fun map(items: List<InfoItem>): List<Video> =
        items.filterIsInstance<StreamInfoItem>().map {
            Video(
                it.url, it.name ?: "", it.uploaderName ?: "", it.viewCount,
                it.textualUploadDate ?: "", it.duration, thumb(it.thumbnails), thumb(it.uploaderAvatars)
            )
        }

    fun search(q: String): Result {
        init()
        val yt = ServiceList.YouTube
        val h = yt.searchQHFactory.fromQuery(q, listOf("videos"), "")
        val info = SearchInfo.getInfo(yt, h)
        return Result(map(info.relatedItems), info.nextPage)
    }

    fun more(q: String, page: Page): Result {
        init()
        val yt = ServiceList.YouTube
        val h = yt.searchQHFactory.fromQuery(q, listOf("videos"), "")
        val p = SearchInfo.getMoreItems(yt, h, page)
        return Result(map(p.items), p.nextPage)
    }

    fun stream(url: String): StreamInfo {
        init()
        return StreamInfo.getInfo(url)
    }

    /** Video terbaru dari sebuah kanal. */
    fun channelVideos(url: String): List<Video> {
        init()
        val info = ChannelInfo.getInfo(url)

        // ChannelInfo hanya menyimpan metadata dan daftar tab, bukan daftar video.
        // Ambil tab "videos" melalui ChannelTabInfo sesuai API NewPipe Extractor.
        val videoTab = info.tabs.firstOrNull { tab ->
            tab.contentFilters.any { filter -> filter.equals(ChannelTabs.VIDEOS, ignoreCase = true) }
        } ?: info.tabs.firstOrNull() ?: return emptyList()

        val tabInfo = ChannelTabInfo.getInfo(ServiceList.YouTube, videoTab)
        return map(tabInfo.relatedItems)
    }

    /** Komentar teratas: pasangan (nama, isi). */
    fun comments(info: StreamInfo): List<Pair<String, String>> {
        val ci = CommentsInfo.getInfo(info.url)
        return ci.relatedItems.map {
            (it.uploaderName ?: "") to (it.commentText?.content ?: "")
        }.filter { it.second.isNotBlank() }
    }

    /** Susun pilihan: muxed (langsung) -> HD (video+audio digabung) -> audio saja. */
    fun options(info: StreamInfo, lowAudio: Boolean): List<Option> {
        val out = ArrayList<Option>()
        val audios = info.audioStreams.filter { it.isUrl }
        val bestAudio = audios.filter { it.format == MediaFormat.M4A }.maxByOrNull { it.averageBitrate }
            ?: audios.maxByOrNull { it.averageBitrate }
        val audioForAudioOnly =
            if (lowAudio) audios.minByOrNull { if (it.averageBitrate > 0) it.averageBitrate else Int.MAX_VALUE } else bestAudio

        info.videoStreams.filter { it.isUrl }.sortedByDescending { it.height }.forEach {
            out.add(Option(it.resolution, it.content, null, height = it.height, muxed = true))
        }
        if (bestAudio != null) {
            info.videoOnlyStreams.filter { it.isUrl && it.format == MediaFormat.MPEG_4 }
                .sortedByDescending { it.height }.distinctBy { it.height }.forEach {
                    out.add(Option(it.resolution + " HD", it.content, bestAudio.content, height = it.height))
                }
        }
        val hls = info.hlsUrl
        if (!hls.isNullOrBlank() && out.isEmpty()) {
            out.add(Option("Siaran langsung", null, null, hls = hls, muxed = true))
        }
        if (audioForAudioOnly != null) {
            out.add(Option("Audio saja", null, audioForAudioOnly.content, audioOnly = true))
        }
        return out
    }

    /** Pilih opsi sesuai resolusi default (0 = otomatis, dibatasi 480p). */
    fun pick(opts: List<Option>, target: Int): Int {
        val vids = opts.withIndex().filter { !it.value.audioOnly && it.value.height > 0 }
        if (vids.isEmpty()) return opts.indexOfFirst { !it.audioOnly }.let { if (it >= 0) it else 0 }
        val limit = if (target == 0) 480 else target
        val le = vids.filter { it.value.height <= limit }
        val best = if (le.isNotEmpty()) {
            le.maxWithOrNull(compareBy({ it.value.height }, { it.value.muxed }))
        } else {
            vids.minByOrNull { it.value.height }
        }
        return best?.index ?: 0
    }

    /** Opsi cadangan jika pemutaran gagal: muxed dulu, lalu video lain terendah, terakhir audio. */
    fun fallback(opts: List<Option>, tried: Set<Int>): Int {
        val rest = opts.withIndex().filter { it.index !in tried }
        rest.firstOrNull { it.value.muxed && !it.value.audioOnly }?.let { return it.index }
        rest.filter { !it.value.audioOnly }.minByOrNull { it.value.height }?.let { return it.index }
        rest.firstOrNull()?.let { return it.index }
        return -1
    }
}
