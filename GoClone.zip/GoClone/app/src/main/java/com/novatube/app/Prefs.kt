package com.novatube.app

import android.content.Context
import android.content.SharedPreferences

/** Semua pengaturan aplikasi (halaman Pengaturan > Umum). */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) sp = ctx.getSharedPreferences("novatube", Context.MODE_PRIVATE)
    }

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun setB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }

    /** 0 = otomatis, selain itu tinggi piksel (1080, 720, ...). */
    var resolution: Int
        get() = sp.getInt("res", 0)
        set(v) { sp.edit().putInt("res", v).apply() }

    /** 0 = terbaik, 1 = hemat data. */
    var audioQuality: Int
        get() = sp.getInt("aq", 0)
        set(v) { sp.edit().putInt("aq", v).apply() }

    var seekSeconds: Int
        get() = sp.getInt("seek", 10)
        set(v) { sp.edit().putInt("seek", v).apply() }

    var bgPlay: Boolean
        get() = b("bg", true)
        set(v) = setB("bg", v)
    var autoStart: Boolean
        get() = b("autostart", true)
        set(v) = setB("autostart", v)
    var autoNext: Boolean
        get() = b("autonext", true)
        set(v) = setB("autonext", v)
    var resumeAfterInterrupt: Boolean
        get() = b("resume", true)
        set(v) = setB("resume", v)
    var pipAuto: Boolean
        get() = b("pip", true)
        set(v) = setB("pip", v)
    var fastSeek: Boolean
        get() = b("fastseek", false)
        set(v) = setB("fastseek", v)
    var volGesture: Boolean
        get() = b("vol", true)
        set(v) = setB("vol", v)
    var brightGesture: Boolean
        get() = b("bright", true)
        set(v) = setB("bright", v)
}
