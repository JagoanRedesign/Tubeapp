package com.novatube.app

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration

/** Semua pengaturan aplikasi (halaman Pengaturan > Umum). */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) sp = ctx.getSharedPreferences("novatube", Context.MODE_PRIVATE)
    }

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun setB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }

    /** 0 = otomatis, selain itu tinggi piksel (1080, 720, ...). */
    var resolution: Int
        get() = sp.getInt("res", 0)
        set(v) { sp.edit().putInt("res", v).apply() }

    /** 0 = terbaik, 1 = hemat data. */
    var audioQuality: Int
        get() = sp.getInt("aq", 0)
        set(v) { sp.edit().putInt("aq", v).apply() }

    var seekSeconds: Int
        get() = sp.getInt("seek", 10)
        set(v) { sp.edit().putInt("seek", v).apply() }

    var bgPlay: Boolean
        get() = b("bg", true)
        set(v) = setB("bg", v)
    var autoStart: Boolean
        get() = b("autostart", true)
        set(v) = setB("autostart", v)
    var autoNext: Boolean
        get() = b("autonext", true)
        set(v) = setB("autonext", v)
    var resumeAfterInterrupt: Boolean
        get() = b("resume", true)
        set(v) = setB("resume", v)
    var pipAuto: Boolean
        get() = b("pip", true)
        set(v) = setB("pip", v)
    var fastSeek: Boolean
        get() = b("fastseek", false)
        set(v) = setB("fastseek", v)
    var volGesture: Boolean
        get() = b("vol", true)
        set(v) = setB("vol", v)
    var brightGesture: Boolean
        get() = b("bright", true)
        set(v) = setB("bright", v)

    /** 0 sistem, 1 terang, 2 gelap, 3 AMOLED */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    /** 0 mati, 1 aktif, 2 hanya saat data seluler */
    var dataSaver: Int
        get() = sp.getInt("ds", 0)
        set(v) { sp.edit().putInt("ds", v).apply() }

    var subLang: String
        get() = sp.getString("sublang", "") ?: ""
        set(v) { sp.edit().putString("sublang", v).apply() }

    var resumeProgress: Boolean
        get() = b("resumep", true)
        set(v) = setB("resumep", v)
    var dlWifiOnly: Boolean
        get() = b("dlwifi", false)
        set(v) = setB("dlwifi", v)

    fun themeRes(ctx: Context): Int {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return when (theme) {
            1 -> R.style.Theme_NovaTube
            2 -> R.style.Theme_NovaTubeDark
            3 -> R.style.Theme_NovaTubeAmoled
            else -> if (night) R.style.Theme_NovaTubeDark else R.style.Theme_NovaTube
        }
    }

    fun dataSaverActive(ctx: Context): Boolean {
        if (dataSaver == 0) return false
        if (dataSaver == 1) return true
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        return cm.isActiveNetworkMetered
    }
}
