package com.novatube.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation

/** Daftar video lebar penuh (gaya beranda/terkait). */
class VideoAdapter(
    private val onClick: (Video) -> Unit,
    private val onMore: (Video, View) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {
    private val items = ArrayList<Video>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val dur: TextView = v.findViewById(R.id.dur)
        val prog: ProgressBar = v.findViewById(R.id.prog)
        val avatar: ImageView = v.findViewById(R.id.avatar)
        val title: TextView = v.findViewById(R.id.title)
        val meta: TextView = v.findViewById(R.id.meta)
        val more: ImageButton = v.findViewById(R.id.more)
    }

    fun submit(l: List<Video>) {
        items.clear()
        items.addAll(l)
        notifyDataSetChanged()
    }

    fun append(l: List<Video>) {
        val s = items.size
        items.addAll(l)
        notifyItemRangeInserted(s, l.size)
    }

    fun first(): Video? = items.firstOrNull()

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH = newVideoHolder(p)

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) = bindVideo(h, items[i], onClick, onMore)
}

fun newVideoHolder(p: ViewGroup): VideoAdapter.VH {
    val v = LayoutInflater.from(p.context).inflate(R.layout.item_video, p, false)
    val vh = VideoAdapter.VH(v)
    val dm = p.context.resources.displayMetrics
    vh.thumb.layoutParams.height = minOf(dm.widthPixels, dm.heightPixels) * 9 / 16
    return vh
}

fun bindVideo(h: VideoAdapter.VH, v: Video, onClick: (Video) -> Unit, onMore: (Video, View) -> Unit) {
    h.thumb.load(v.thumb) { crossfade(!Repo.lowData) }
    val av = v.avatar
    if (av != null && !Repo.lowData) h.avatar.load(av) { transformations(CircleCropTransformation()) }
    else h.avatar.setImageDrawable(null)
    h.title.text = v.title
    h.meta.text = listOf(v.channel, Fmt.compact(v.views), Util.simpleDate(v.date)).filter { it.isNotBlank() }.joinToString(" • ")
    val d = Fmt.duration(v.duration)
    h.dur.text = d
    h.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
    val f = Store.fraction(v.url)
    h.prog.progress = (f * 1000).toInt()
    h.prog.visibility = if (f > 0.01f) View.VISIBLE else View.GONE
    h.itemView.setOnClickListener { onClick(v) }
    h.more.setOnClickListener { onMore(v, it) }
}

/** Kartu kecil horizontal untuk "Daftar Tontonan Lokal". */
class LocalAdapter(private val onClick: (Video) -> Unit) : RecyclerView.Adapter<LocalAdapter.VH>() {
    private val items = ArrayList<Video>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val dur: TextView = v.findViewById(R.id.dur)
        val prog: ProgressBar = v.findViewById(R.id.prog)
        val title: TextView = v.findViewById(R.id.title)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    fun submit(l: List<Video>) {
        items.clear()
        items.addAll(l)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_local, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val v = items[i]
        h.thumb.load(v.thumb) { crossfade(!Repo.lowData) }
        h.title.text = v.title
        h.meta.text = v.channel
        val d = Fmt.duration(v.duration)
        h.dur.text = d
        h.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
        val f = Store.fraction(v.url)
        h.prog.progress = (f * 1000).toInt()
        h.prog.visibility = if (f > 0.01f) View.VISIBLE else View.GONE
        h.itemView.setOnClickListener { onClick(v) }
    }
}
