package com.novatube.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class VideoAdapter(private val onClick: (Video) -> Unit) : RecyclerView.Adapter<VideoAdapter.VH>() {
    private val items = ArrayList<Video>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val dur: TextView = v.findViewById(R.id.dur)
        val title: TextView = v.findViewById(R.id.title)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    fun submit(l: List<Video>) {
        items.clear()
        items.addAll(l)
        notifyDataSetChanged()
    }

    fun append(l: List<Video>) {
        val s = items.size
        items.addAll(l)
        notifyItemRangeInserted(s, l.size)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item_video, p, false)
        val vh = VH(v)
        val dm = p.context.resources.displayMetrics
        val w = minOf(dm.widthPixels, dm.heightPixels) - (32 * dm.density).toInt()
        vh.thumb.layoutParams.height = w * 9 / 16
        return vh
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val v = items[i]
        h.thumb.load(v.thumb) { crossfade(true) }
        h.title.text = v.title
        h.meta.text = Fmt.meta(v)
        val d = if (v.duration > 0) Fmt.duration(v.duration) else if (v.duration < 0 && v.views >= 0) "" else ""
        h.dur.text = d
        h.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
        h.itemView.setOnClickListener { onClick(v) }
    }
}
