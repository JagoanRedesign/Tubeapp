package com.novatube.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation

/** Daftar video lebar penuh (gaya beranda/terkait). */
class VideoAdapter(
    private val onClick: (Video) -> Unit,
    private val onMore: (Video, View) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {
    private val items = ArrayList<Video>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val dur: TextView = v.findViewById(R.id.dur)
        val avatar: ImageView = v.findViewById(R.id.avatar)
        val title: TextView = v.findViewById(R.id.title)
        val meta: TextView = v.findViewById(R.id.meta)
        val more: ImageButton = v.findViewById(R.id.more)
    }

    fun submit(l: List<Video>) {
        items.clear()
        items.addAll(l)
        notifyDataSetChanged()
    }

    fun append(l: List<Video>) {
        val s = items.size
        items.addAll(l)
        notifyItemRangeInserted(s, l.size)
    }

    fun first(): Video? = items.firstOrNull()

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item_video, p, false)
        val vh = VH(v)
        val dm = p.context.resources.displayMetrics
        vh.thumb.layoutParams.height = minOf(dm.widthPixels, dm.heightPixels) * 9 / 16
        return vh
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val v = items[i]
        h.thumb.load(v.thumb) { crossfade(true) }
        if (v.avatar != null) h.avatar.load(v.avatar) { transformations(CircleCropTransformation()) }
        else h.avatar.setImageDrawable(null)
        h.title.text = v.title
        h.meta.text = listOf(v.channel, Fmt.compact(v.views), v.date)
            .filter { it.isNotBlank() }.joinToString(" • ")
        val d = Fmt.duration(v.duration)
        h.dur.text = d
        h.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
        h.itemView.setOnClickListener { onClick(v) }
        h.more.setOnClickListener { onMore(v, it) }
    }
}

/** Kartu kecil horizontal untuk "Daftar Tontonan Lokal". */
class LocalAdapter(private val onClick: (Video) -> Unit) : RecyclerView.Adapter<LocalAdapter.VH>() {
    private val items = ArrayList<Video>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val dur: TextView = v.findViewById(R.id.dur)
        val title: TextView = v.findViewById(R.id.title)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    fun submit(l: List<Video>) {
        items.clear()
        items.addAll(l)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_local, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val v = items[i]
        h.thumb.load(v.thumb) { crossfade(true) }
        h.title.text = v.title
        h.meta.text = v.channel
        val d = Fmt.duration(v.duration)
        h.dur.text = d
        h.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
        h.itemView.setOnClickListener { onClick(v) }
    }
}
