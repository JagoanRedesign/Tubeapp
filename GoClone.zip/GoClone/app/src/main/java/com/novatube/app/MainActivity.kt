package com.novatube.app

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.schabi.newpipe.extractor.Page
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newFixedThreadPool(4)

    // ---- cangkang
    private lateinit var header: View
    private lateinit var etSearch: EditText
    private lateinit var chips: LinearLayout
    private lateinit var tabHome: View
    private lateinit var tabLib: View
    private lateinit var list: RecyclerView
    private lateinit var loading: ProgressBar
    private lateinit var tvMsg: TextView
    private lateinit var localList: RecyclerView
    private lateinit var tvLocalEmpty: TextView
    private lateinit var page: View
    private lateinit var pageTitle: TextView
    private lateinit var pageList: RecyclerView
    private lateinit var pageScroll: View
    private lateinit var pageBox: LinearLayout
    private lateinit var pageEmpty: TextView
    private lateinit var mini: View
    private lateinit var miniVideoView: PlayerView
    private lateinit var miniTitle: TextView
    private lateinit var miniPlay: ImageButton
    private lateinit var navHomeIcon: ImageView
    private lateinit var navHomeText: TextView
    private lateinit var navLibIcon: ImageView
    private lateinit var navLibText: TextView

    // ---- pemutar
    private lateinit var playerScreen: View
    private lateinit var playerBox: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var playerTop: View
    private lateinit var playerLoading: ProgressBar
    private lateinit var audioCover: ImageView
    private lateinit var tvGesture: TextView
    private lateinit var tvQuality: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var info: View
    private lateinit var tvTitle: TextView
    private lateinit var tvMeta: TextView
    private lateinit var tvDesc: TextView
    private lateinit var chAvatar: ImageView
    private lateinit var chName: TextView
    private lateinit var chSubs: TextView
    private lateinit var btnSub: TextView
    private lateinit var icLike: ImageView
    private lateinit var tvLike: TextView
    private lateinit var icLater: ImageView
    private lateinit var tvLater: TextView
    private lateinit var commentPreview: View
    private lateinit var cmAvatar: TextView
    private lateinit var cmText: TextView
    private lateinit var related: RecyclerView

    private val feedAdapter = VideoAdapter({ openVideo(it) }, { v, a -> showVideoMenu(v, a) })
    private val relatedAdapter = VideoAdapter({ openVideo(it) }, { v, a -> showVideoMenu(v, a) })
    private val pageAdapter = VideoAdapter({ openVideo(it) }, { v, a -> showVideoMenu(v, a) })
    private val localAdapter = LocalAdapter { openVideo(it) }
    private val chipViews = ArrayList<TextView>()

    // state beranda
    private var tab = 0
    private var pageOpen = false
    private var currentQuery = ""
    private var nextPage: Page? = null
    private var loadingMore = false

    // state pemutar
    private var player: ExoPlayer? = null
    private val pending = ArrayList<(ExoPlayer) -> Unit>()
    private var currentVideo: Video? = null
    private var currentChannel: Channel? = null
    private var autoQueue: List<Video> = emptyList()
    private var comments: List<Pair<String, String>> = emptyList()
    private var options: List<Option> = emptyList()
    private val tried = HashSet<Int>()
    private var selected = 0
    private var lastVideoIdx = 0
    private var manualQuality = false
    private var playerOpen = false
    private var fullscreen = false
    private var inPip = false
    private var audioOnly = false
    private var gestureVol = 0f
    private var gestureBr = 0.5f

    private val hideGesture = Runnable { tvGesture.visibility = View.GONE }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val p = (binder as PlaybackService.LocalBinder).player()
            player = p
            playerView.player = p
            miniVideoView.player = p
            miniVideoView.useController = false
            p.addListener(playerListener)
            applyPlayerPrefs()
            pending.forEach { it(p) }
            pending.clear()
            updateMini()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            player = null
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            miniPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            playerLoading.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (playbackState == Player.STATE_ENDED && Prefs.autoNext) {
                val currentUrl = currentVideo?.url
                val next = autoQueue.let { queue ->
                    val index = queue.indexOfFirst { it.url == currentUrl }
                    if (index >= 0) queue.getOrNull(index + 1) else queue.firstOrNull()
                }
                next?.let { openVideo(it, audio = audioOnly, show = playerOpen) }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            playerLoading.visibility = View.GONE
            val next = Repo.fallback(options, tried)
            if (next >= 0) {
                toast("Gagal memutar, mencoba kualitas lain…")
                selectOption(next, keepPos = false)
            } else {
                toast("Gagal memutar (${error.errorCodeName})")
            }
        }
    }

    // ============================================================ siklus hidup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Store.init(this)
        setContentView(R.layout.activity_main)
        bindViews()
        setupHome()
        setupLibrary()
        setupPlayer()
        setupGestures()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    fullscreen -> setFullscreen(false)
                    playerOpen -> showPlayer(false)
                    pageOpen -> closePage()
                    tab == 1 -> showTab(0)
                    else -> moveTaskToBack(true)
                }
            }
        })

        bindService(
            Intent(this, PlaybackService::class.java).setAction(PlaybackService.ACTION_LOCAL),
            conn, Context.BIND_AUTO_CREATE
        )
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        showTab(0)
        selectChip(0)
        handleIntent(intent)
    }

    override fun onStop() {
        super.onStop()
        if (!Prefs.bgPlay && !inPip && !isChangingConfigurations) player?.pause()
    }

    override fun onDestroy() {
        playerView.player = null
        miniVideoView.player = null
        player?.removeListener(playerListener)
        try { unbindService(conn) } catch (e: Exception) { }
        io.shutdownNow()
        super.onDestroy()
    }

    private fun bindViews() {
        header = findViewById(R.id.header)
        etSearch = findViewById(R.id.etSearch)
        chips = findViewById(R.id.chips)
        tabHome = findViewById(R.id.tabHome)
        tabLib = findViewById(R.id.tabLib)
        list = findViewById(R.id.list)
        loading = findViewById(R.id.loading)
        tvMsg = findViewById(R.id.tvMsg)
        localList = findViewById(R.id.localList)
        tvLocalEmpty = findViewById(R.id.tvLocalEmpty)
        page = findViewById(R.id.page)
        pageTitle = findViewById(R.id.pageTitle)
        pageList = findViewById(R.id.pageList)
        pageScroll = findViewById(R.id.pageScroll)
        pageBox = findViewById(R.id.pageBox)
        pageEmpty = findViewById(R.id.pageEmpty)
        mini = findViewById(R.id.mini)
        miniVideoView = findViewById(R.id.miniVideoView)
        miniTitle = findViewById(R.id.miniTitle)
        miniPlay = findViewById(R.id.miniPlay)
        navHomeIcon = findViewById(R.id.navHomeIcon)
        navHomeText = findViewById(R.id.navHomeText)
        navLibIcon = findViewById(R.id.navLibIcon)
        navLibText = findViewById(R.id.navLibText)

        playerScreen = findViewById(R.id.playerScreen)
        playerBox = findViewById(R.id.playerBox)
        playerView = findViewById(R.id.playerView)
        playerTop = findViewById(R.id.playerTop)
        playerLoading = findViewById(R.id.playerLoading)
        audioCover = findViewById(R.id.audioCover)
        tvGesture = findViewById(R.id.tvGesture)
        tvQuality = findViewById(R.id.tvQuality)
        tvSpeed = findViewById(R.id.tvSpeed)
        info = findViewById(R.id.info)
        tvTitle = findViewById(R.id.tvTitle)
        tvMeta = findViewById(R.id.tvMeta)
        tvDesc = findViewById(R.id.tvDesc)
        chAvatar = findViewById(R.id.chAvatar)
        chName = findViewById(R.id.chName)
        chSubs = findViewById(R.id.chSubs)
        btnSub = findViewById(R.id.btnSub)
        icLike = findViewById(R.id.icLike)
        tvLike = findViewById(R.id.tvLike)
        icLater = findViewById(R.id.icLater)
        tvLater = findViewById(R.id.tvLater)
        commentPreview = findViewById(R.id.commentPreview)
        cmAvatar = findViewById(R.id.cmAvatar)
        cmText = findViewById(R.id.cmText)
        related = findViewById(R.id.related)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ============================================================ beranda

    private fun setupHome() {
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = feedAdapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0 && !rv.canScrollVertically(1)) load(currentQuery, true)
            }
        })
        CATS.forEachIndexed { i, c ->
            val tv = TextView(this).apply {
                text = c.first
                textSize = 14f
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setOnClickListener { selectChip(i) }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            chips.addView(tv, lp)
            chipViews.add(tv)
        }
        etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(); true } else false
        }
        findViewById<View>(R.id.btnSearch).setOnClickListener { doSearch() }
        findViewById<View>(R.id.btnMusic).setOnClickListener { showPlaylistsPage() }
        findViewById<View>(R.id.btnBell).setOnClickListener { toast("Belum ada notifikasi") }
        findViewById<View>(R.id.btnProfile).setOnClickListener { showSettingsPage() }
        findViewById<View>(R.id.navHome).setOnClickListener { showTab(0) }
        findViewById<View>(R.id.navLib).setOnClickListener { showTab(1) }
        findViewById<View>(R.id.pageBack).setOnClickListener { closePage() }
        pageList.layoutManager = LinearLayoutManager(this)
        pageList.adapter = pageAdapter

        mini.setOnClickListener { showPlayer(true) }
        miniVideoView.setOnClickListener { showPlayer(true) }
        miniPlay.setOnClickListener { player?.let { if (it.isPlaying) it.pause() else it.play() } }
        findViewById<View>(R.id.miniClose).setOnClickListener { stopAndClose() }
    }

    private fun styleChips(sel: Int) {
        chipViews.forEachIndexed { i, tv ->
            val on = i == sel
            tv.setBackgroundResource(if (on) R.drawable.bg_chip_sel else R.drawable.bg_chip)
            tv.setTextColor(if (on) 0xFFFFFFFF.toInt() else getColor(R.color.text))
        }
    }

    private fun selectChip(i: Int) {
        styleChips(i)
        etSearch.setText("")
        showTab(0)
        load(CATS[i].second)
    }

    private fun searchFor(q: String) {
        etSearch.setText(q)
        styleChips(-1)
        showTab(0)
        load(q)
    }

    private fun doSearch() {
        val q = etSearch.text.toString().trim()
        if (q.isEmpty()) return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etSearch.windowToken, 0)
        styleChips(-1)
        showTab(0)
        load(q)
    }

    private fun showTab(t: Int) {
        tab = t
        closePage()
        tabHome.visibility = if (t == 0) View.VISIBLE else View.GONE
        tabLib.visibility = if (t == 1) View.VISIBLE else View.GONE
        val on = getColor(R.color.accent)
        val off = 0xFF757575.toInt()
        navHomeIcon.setColorFilter(if (t == 0) on else off)
        navHomeText.setTextColor(if (t == 0) on else off)
        navLibIcon.setColorFilter(if (t == 1) on else off)
        navLibText.setTextColor(if (t == 1) on else off)
        if (t == 1) refreshLibrary()
    }

    private fun load(query: String, more: Boolean = false) {
        if (query.isEmpty() || loadingMore) return
        if (more) {
            if (nextPage == null) return
        } else {
            currentQuery = query
            nextPage = null
            feedAdapter.submit(emptyList())
            tvMsg.visibility = View.GONE
            loading.visibility = View.VISIBLE
        }
        loadingMore = true
        val q = currentQuery
        val pg = nextPage
        io.execute {
            try {
                val r = if (more && pg != null) Repo.more(q, pg) else Repo.search(q)
                ui.post {
                    loadingMore = false
                    if (q != currentQuery) return@post
                    loading.visibility = View.GONE
                    nextPage = r.next
                    if (more) feedAdapter.append(r.items) else feedAdapter.submit(r.items)
                    if (!more && r.items.isEmpty()) showMsg("Tidak ada hasil.")
                }
            } catch (e: Exception) {
                ui.post {
                    loadingMore = false
                    loading.visibility = View.GONE
                    if (!more) showMsg("Gagal memuat: ${e.message ?: "periksa koneksi"}\nKetuk kategori untuk mencoba lagi.")
                }
            }
        }
    }

    private fun showMsg(s: String) {
        tvMsg.text = s
        tvMsg.visibility = View.VISIBLE
    }

    // ============================================================ pustaka

    private fun setupLibrary() {
        localList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        localList.adapter = localAdapter
        findViewById<View>(R.id.rowSubs).setOnClickListener { showSubsPage() }
        findViewById<View>(R.id.rowHistory).setOnClickListener { showVideoPage("Riwayat", Store.history()) }
        findViewById<View>(R.id.rowLater).setOnClickListener { showVideoPage("Nonton nanti", Store.list("later")) }
        findViewById<View>(R.id.rowLiked).setOnClickListener { showVideoPage("Video yang disukai", Store.list("liked")) }
        findViewById<View>(R.id.rowPlaylists).setOnClickListener { showPlaylistsPage() }
        findViewById<View>(R.id.btnLocalMore).setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            pm.menu.add("Hapus riwayat")
            pm.setOnMenuItemClickListener { confirmClearHistory(); true }
            pm.show()
        }
    }

    private fun refreshLibrary() {
        val h = Store.history().take(12)
        localAdapter.submit(h)
        localList.visibility = if (h.isEmpty()) View.GONE else View.VISIBLE
        tvLocalEmpty.visibility = if (h.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmClearHistory() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus riwayat?")
            .setMessage("Semua riwayat tontonan di perangkat ini akan dihapus.")
            .setPositiveButton("Hapus") { _, _ -> Store.clearHistory(); refreshLibrary(); toast("Riwayat dihapus") }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ============================================================ halaman dalam

    private fun openPage(title: String, kind: Int) {
        pageOpen = true
        header.visibility = View.GONE
        page.visibility = View.VISIBLE
        pageTitle.text = title
        pageList.visibility = if (kind == 0) View.VISIBLE else View.GONE
        pageScroll.visibility = if (kind == 1) View.VISIBLE else View.GONE
        pageEmpty.visibility = View.GONE
        pageBox.removeAllViews()
    }

    private fun closePage() {
        pageOpen = false
        page.visibility = View.GONE
        header.visibility = View.VISIBLE
        if (tab == 1) refreshLibrary()
    }

    private fun showVideoPage(title: String, vids: List<Video>) {
        openPage(title, 0)
        pageAdapter.submit(vids)
        pageEmpty.text = "Belum ada video."
        pageEmpty.visibility = if (vids.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openChannel(ch: Channel) {
        openPage(ch.name, 0)
        pageAdapter.submit(emptyList())
        pageEmpty.text = "Memuat video kanal…"
        pageEmpty.visibility = View.VISIBLE
        io.execute {
            try {
                val videos = Repo.channelVideos(ch.url)
                ui.post {
                    if (!pageOpen) return@post
                    pageAdapter.submit(videos)
                    pageEmpty.text = "Belum ada video dari kanal ini."
                    pageEmpty.visibility = if (videos.isEmpty()) View.VISIBLE else View.GONE
                }
            } catch (e: Exception) {
                ui.post {
                    if (!pageOpen) return@post
                    pageEmpty.text = "Gagal memuat kanal: ${e.message ?: "coba lagi"}"
                    pageEmpty.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun showSubsPage() {
        openPage("Langganan", 1)
        val subs = Store.subs()
        if (subs.isEmpty()) {
            pageEmpty.text = "Belum ada langganan.\nBuka video lalu ketuk BERLANGGANAN."
            pageEmpty.visibility = View.VISIBLE
            return
        }
        subs.forEach { ch ->
            val row = layoutInflater.inflate(R.layout.row_channel, pageBox, false)
            row.findViewById<TextView>(R.id.chName).text = ch.name
            if (ch.avatar != null) {
                row.findViewById<ImageView>(R.id.chAvatar).load(ch.avatar) { transformations(CircleCropTransformation()) }
            }
            row.setOnClickListener { openChannel(ch) }
            row.findViewById<View>(R.id.chMore).setOnClickListener {
                MaterialAlertDialogBuilder(this)
                    .setTitle(ch.name)
                    .setMessage("Berhenti berlangganan?")
                    .setPositiveButton("Berhenti") { _, _ -> Store.toggleSub(ch); showSubsPage() }
                    .setNegativeButton("Batal", null)
                    .show()
            }
            pageBox.addView(row)
        }
    }

    private fun showPlaylistsPage() {
        openPage("Daftar putar", 1)
        addPlainRow("＋  Buat daftar putar baru", null) { promptNewPlaylist { showPlaylistsPage() } }
        val names = Store.playlistNames()
        names.forEach { n ->
            addPlainRow(n, "${Store.playlist(n).size} video") { showVideoPage(n, Store.playlist(n)) }
                .setOnLongClickListener {
                    MaterialAlertDialogBuilder(this)
                        .setTitle(n)
                        .setMessage("Hapus daftar putar ini?")
                        .setPositiveButton("Hapus") { _, _ -> Store.deletePlaylist(n); showPlaylistsPage() }
                        .setNegativeButton("Batal", null)
                        .show()
                    true
                }
        }
        if (names.isEmpty()) {
            pageEmpty.text = "Belum ada daftar putar."
            pageEmpty.visibility = View.VISIBLE
            pageEmpty.translationY = dp(120).toFloat()
        } else {
            pageEmpty.translationY = 0f
        }
    }

    private fun promptNewPlaylist(done: (String) -> Unit) {
        val et = EditText(this).apply { hint = "Nama daftar putar"; setSingleLine() }
        val box = FrameLayout(this).apply { setPadding(dp(24), dp(8), dp(24), 0); addView(et) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Daftar putar baru")
            .setView(box)
            .setPositiveButton("Buat") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) { Store.createPlaylist(n); done(n) }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun addToPlaylist(v: Video) {
        val names = Store.playlistNames()
        val items = (names + "＋ Daftar putar baru").toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Simpan ke daftar putar")
            .setItems(items) { _, i ->
                if (i < names.size) {
                    Store.addToPlaylist(names[i], v)
                    toast("Disimpan ke ${names[i]}")
                } else {
                    promptNewPlaylist { n -> Store.addToPlaylist(n, v); toast("Disimpan ke $n") }
                }
            }
            .show()
    }

    private fun addPlainRow(title: String, desc: String?, onClick: () -> Unit): View {
        val v = layoutInflater.inflate(R.layout.row_setting, pageBox, false)
        v.findViewById<TextView>(R.id.rsTitle).text = title
        if (desc != null) {
            v.findViewById<TextView>(R.id.rsDesc).apply { text = desc; visibility = View.VISIBLE }
        }
        v.setOnClickListener { onClick() }
        pageBox.addView(v)
        return v
    }

    // ============================================================ pengaturan

    private fun addSection(title: String) {
        val v = layoutInflater.inflate(R.layout.row_section, pageBox, false) as TextView
        v.text = title
        pageBox.addView(v)
    }

    private fun addChoice(title: String, labels: List<String>, getIdx: () -> Int, setIdx: (Int) -> Unit) {
        val v = layoutInflater.inflate(R.layout.row_setting, pageBox, false)
        v.findViewById<TextView>(R.id.rsTitle).text = title
        val value = v.findViewById<TextView>(R.id.rsValue)
        value.visibility = View.VISIBLE
        value.text = labels[getIdx()]
        v.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(title)
                .setSingleChoiceItems(labels.toTypedArray(), getIdx()) { d, i ->
                    setIdx(i)
                    value.text = labels[i]
                    d.dismiss()
                    applyPlayerPrefs()
                }
                .show()
        }
        pageBox.addView(v)
    }

    private fun addSwitch(title: String, desc: String?, get: () -> Boolean, set: (Boolean) -> Unit) {
        val v = layoutInflater.inflate(R.layout.row_setting, pageBox, false)
        v.findViewById<TextView>(R.id.rsTitle).text = title
        if (desc != null) v.findViewById<TextView>(R.id.rsDesc).apply { text = desc; visibility = View.VISIBLE }
        v.findViewById<View>(R.id.rsChevron).visibility = View.GONE
        val sw = v.findViewById<SwitchCompat>(R.id.rsSwitch)
        sw.visibility = View.VISIBLE
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, c -> set(c); applyPlayerPrefs() }
        v.setOnClickListener { sw.toggle() }
        pageBox.addView(v)
    }

    private fun showSettingsPage() {
        openPage("Umum", 1)
        val resVals = listOf(0, 1080, 720, 480, 360, 240)
        addSection("Kualitas")
        addChoice("Resolusi video default",
            resVals.map { if (it == 0) "Otomatis" else "${it}p" },
            { resVals.indexOf(Prefs.resolution).coerceAtLeast(0) }, { Prefs.resolution = resVals[it] })
        addChoice("Resolusi audio default", listOf("Otomatis", "Hemat data"),
            { Prefs.audioQuality }, { Prefs.audioQuality = it })

        addSection("Putar otomatis")
        addChoice("Background play auto", listOf("Selalu aktif", "Nonaktif"),
            { if (Prefs.bgPlay) 0 else 1 }, { Prefs.bgPlay = it == 0 })
        addChoice("Pemutaran video mulai otomatis", listOf("Selalu", "Tidak"),
            { if (Prefs.autoStart) 0 else 1 }, { Prefs.autoStart = it == 0 })
        addSwitch("Putar video berikutnya otomatis", "Memutar video terkait pertama saat video selesai",
            { Prefs.autoNext }, { Prefs.autoNext = it })
        addSwitch("Lanjutkan pemutaran", "Melanjutkan pemutaran setelah interupsi (mis. panggilan telepon)",
            { Prefs.resumeAfterInterrupt }, { Prefs.resumeAfterInterrupt = it })
        addSwitch("Jendela mengambang otomatis", "Masuk mode jendela mengambang saat keluar aplikasi",
            { Prefs.pipAuto }, { Prefs.pipAuto = it })

        addSection("Gerak Isyarat")
        addSwitch("Pencarian video cepat",
            "Mulai memutar konten lebih cepat tetapi dari posisi yang kurang tepat saat menyesuaikan bilah kemajuan video",
            { Prefs.fastSeek }, { Prefs.fastSeek = it })
        addSwitch("Kontrol gestur volume", "Gunakan gestur untuk mengontrol volume pemutar",
            { Prefs.volGesture }, { Prefs.volGesture = it })
        addSwitch("Kontrol gestur kecerahan", "Gunakan gestur untuk mengontrol kecerahan pemutar",
            { Prefs.brightGesture }, { Prefs.brightGesture = it })
        val seekVals = listOf(5, 10, 15, 30)
        addChoice("Ketuk dua kali untuk cari", seekVals.map { "$it detik" },
            { seekVals.indexOf(Prefs.seekSeconds).coerceAtLeast(0) }, { Prefs.seekSeconds = seekVals[it] })

        addSection("Data & tentang")
        addPlainRow("Hapus riwayat tontonan", null) { confirmClearHistory() }
        addPlainRow("Tentang & atribusi ikon", null) {
            MaterialAlertDialogBuilder(this)
                .setTitle("NovaTube")
                .setMessage(
                    "Data video: NewPipeExtractor (GPLv3).\n\n" +
                        "Ikon: set vektor bawaan. Jika Anda mengganti dengan ikon dari Flaticon, " +
                        "cantumkan atribusi sesuai lisensi Flaticon (nama pembuat + tautan flaticon.com)."
                )
                .setPositiveButton("Tutup", null)
                .show()
        }
    }

    private fun applyPlayerPrefs() = withPlayer { p ->
        p.setSeekParameters(if (Prefs.fastSeek) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
            Prefs.resumeAfterInterrupt
        )
    }

    // ============================================================ intent

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        i ?: return
        val raw = when (i.action) {
            Intent.ACTION_VIEW -> i.data?.toString()
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)?.let { Regex("https?://\\S+").find(it)?.value }
            else -> null
        } ?: return
        openVideo(Video(raw, "Memuat…", "", -1, "", 0, null))
    }

    // ============================================================ pemutar

    private fun setupPlayer() {
        related.layoutManager = LinearLayoutManager(this)
        related.adapter = relatedAdapter
        playerView.setFullscreenButtonClickListener { setFullscreen(!fullscreen) }
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            playerTop.visibility = if (vis == View.VISIBLE && !inPip) View.VISIBLE else View.GONE
        })

        findViewById<View>(R.id.btnMinimize).setOnClickListener { showPlayer(false) }
        tvQuality.setOnClickListener { showQuality() }
        tvSpeed.setOnClickListener { showSpeed() }
        findViewById<View>(R.id.btnMore).setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            pm.menu.add(0, 1, 0, if (audioOnly) "Putar video" else "Audio saja")
            pm.menu.add(0, 2, 1, "Jendela mengambang")
            pm.menu.add(0, 3, 2, "Bagikan")
            pm.setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> toggleAudioOnly()
                    2 -> enterPip()
                    3 -> currentVideo?.let { v2 -> share(v2) }
                }
                true
            }
            pm.show()
        }

        findViewById<View>(R.id.btnExpand).setOnClickListener {
            val open = tvDesc.visibility != View.VISIBLE
            tvDesc.visibility = if (open) View.VISIBLE else View.GONE
            tvTitle.maxLines = if (open) Int.MAX_VALUE else 2
        }
        val openCurrentChannel = View.OnClickListener {
            val ch = currentChannel
            if (ch != null) openChannel(ch) else toast("Kanal tidak tersedia")
        }
        chName.setOnClickListener(openCurrentChannel)
        chAvatar.setOnClickListener(openCurrentChannel)
        btnSub.setOnClickListener {
            val ch = currentChannel
            if (ch == null) { toast("Kanal tidak tersedia"); return@setOnClickListener }
            val on = Store.toggleSub(ch)
            toast(if (on) "Berlangganan ${ch.name}" else "Berhenti berlangganan")
            refreshActionState()
        }
        findViewById<View>(R.id.likeHit).setOnClickListener {
            val v = currentVideo ?: return@setOnClickListener
            val on = Store.toggle("liked", v)
            toast(if (on) "Ditambahkan ke Video yang disukai" else "Dihapus dari Video yang disukai")
            refreshActionState()
        }
        findViewById<View>(R.id.icDislike).setOnClickListener { toast("Terima kasih atas masukan Anda") }
        findViewById<View>(R.id.pillBg).setOnClickListener {
            val a = options.indexOfFirst { it.audioOnly }
            if (a >= 0) { tried.clear(); selectOption(a, keepPos = true) }
            showPlayer(false)
            toast("Memutar di latar belakang")
        }
        findViewById<View>(R.id.pillShare).setOnClickListener { currentVideo?.let { share(it) } }
        findViewById<View>(R.id.pillLater).setOnClickListener {
            val v = currentVideo ?: return@setOnClickListener
            val on = Store.toggle("later", v)
            toast(if (on) "Disimpan ke Nonton nanti" else "Dihapus dari Nonton nanti")
            refreshActionState()
        }
        findViewById<View>(R.id.pillPlaylist).setOnClickListener { currentVideo?.let { addToPlaylist(it) } }
        findViewById<View>(R.id.commentsRow).setOnClickListener {
            if (comments.isEmpty()) {
                toast("Komentar tidak tersedia")
            } else {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Komentar")
                    .setItems(comments.take(30).map { "${it.first}\n${it.second}" }.toTypedArray(), null)
                    .setPositiveButton("Tutup", null)
                    .show()
            }
        }
    }

    private fun withPlayer(block: (ExoPlayer) -> Unit) {
        val p = player
        if (p != null) block(p) else pending.add(block)
    }

    private fun metaLong(v: Video): String =
        listOf(Fmt.views(v.views), v.date).filter { it.isNotBlank() }.joinToString(" · ")

    private fun openVideo(v: Video, audio: Boolean = false, show: Boolean = true) {
        currentVideo = v
        currentChannel = null
        comments = emptyList()
        options = emptyList()
        tried.clear()
        manualQuality = false
        audioOnly = false
        audioCover.visibility = View.GONE
        tvTitle.text = v.title
        tvMeta.text = metaLong(v)
        tvDesc.visibility = View.GONE
        tvTitle.maxLines = 2
        chName.text = v.channel
        chName.isClickable = true
        chAvatar.isClickable = true
        chSubs.text = ""
        chAvatar.setImageDrawable(null)
        if (v.avatar != null) chAvatar.load(v.avatar) { transformations(CircleCropTransformation()) }
        commentPreview.visibility = View.GONE
        tvLike.text = "Suka"
        relatedAdapter.submit(emptyList())
        tvQuality.text = "Otomatis"
        refreshActionState()
        playerLoading.visibility = View.VISIBLE
        if (show) showPlayer(true) else updateMini()
        withPlayer { it.stop() }

        io.execute {
            try {
                val si = Repo.stream(v.url)
                val opts = Repo.options(si, Prefs.audioQuality == 1)
                val rel = Repo.map(si.relatedItems)
                ui.post {
                    if (currentVideo?.url != v.url) return@post
                    val avatar = Repo.thumb(si.uploaderAvatars) ?: v.avatar
                    val full = Video(
                        si.url ?: v.url, si.name ?: v.title, si.uploaderName ?: v.channel,
                        si.viewCount, si.textualUploadDate ?: v.date, si.duration,
                        Repo.thumb(si.thumbnails) ?: v.thumb, avatar
                    )
                    currentVideo = full
                    val chUrl = si.uploaderUrl
                    currentChannel = if (!chUrl.isNullOrBlank()) Channel(chUrl, full.channel, avatar) else null
                    tvTitle.text = full.title
                    tvMeta.text = metaLong(full)
                    tvDesc.text = si.description?.content ?: ""
                    chName.text = full.channel
                    chSubs.text = Fmt.subs(si.uploaderSubscriberCount)
                    if (avatar != null) chAvatar.load(avatar) { transformations(CircleCropTransformation()) }
                    tvLike.text = if (si.likeCount >= 0) Fmt.compact(si.likeCount) else "Suka"
                    relatedAdapter.submit(rel)
                    autoQueue = listOf(full) + rel
                    Store.addHistory(full)
                    refreshActionState()
                    options = opts
                    if (opts.isEmpty()) {
                        playerLoading.visibility = View.GONE
                        toast("Tidak ada stream yang bisa diputar.")
                    } else {
                        val a = opts.indexOfFirst { it.audioOnly }
                        val idx = if (audio && a >= 0) a else Repo.pick(opts, Prefs.resolution)
                        selectOption(idx, keepPos = false)
                    }
                    io.execute {
                        val cm = try { Repo.comments(si) } catch (e: Exception) { emptyList() }
                        ui.post { if (currentVideo === full) showComments(cm) }
                    }
                }
            } catch (e: Exception) {
                ui.post {
                    if (currentVideo?.url != v.url) return@post
                    playerLoading.visibility = View.GONE
                    toast("Gagal memuat video: ${e.message ?: "kesalahan"}")
                }
            }
        }
    }

    private fun showComments(cm: List<Pair<String, String>>) {
        comments = cm
        val first = cm.firstOrNull() ?: return
        commentPreview.visibility = View.VISIBLE
        cmAvatar.text = first.first.trimStart('@').take(1).uppercase()
        cmText.text = first.second
    }

    private fun refreshActionState() {
        val v = currentVideo
        val accent = getColor(R.color.accent)
        val muted = getColor(R.color.muted)
        val liked = v != null && Store.has("liked", v.url)
        icLike.setColorFilter(if (liked) accent else 0xFF000000.toInt())
        tvLike.setTextColor(if (liked) accent else muted)
        val later = v != null && Store.has("later", v.url)
        icLater.setColorFilter(if (later) accent else 0xFF000000.toInt())
        tvLater.text = if (later) "Tersimpan" else "Nonton nanti"
        tvLater.setTextColor(if (later) accent else muted)
        val ch = currentChannel
        val sub = ch != null && Store.isSub(ch.url)
        btnSub.text = if (sub) "TERLANGGANAN" else "BERLANGGANAN"
        btnSub.setBackgroundResource(if (sub) R.drawable.bg_sub_btn_off else R.drawable.bg_sub_btn)
    }

    private fun qualityLabel(o: Option): String = when {
        o.audioOnly -> "Audio"
        o.hls != null -> "Langsung"
        !manualQuality && Prefs.resolution == 0 -> "Otomatis (${o.height}p)"
        else -> "${o.height}p"
    }

    private fun selectOption(idx: Int, keepPos: Boolean) {
        val o = options.getOrNull(idx) ?: return
        selected = idx
        tried.add(idx)
        audioOnly = o.audioOnly
        if (!o.audioOnly) lastVideoIdx = idx
        audioCover.visibility = if (o.audioOnly) View.VISIBLE else View.GONE
        if (o.audioOnly) audioCover.load(currentVideo?.thumb)
        tvQuality.text = qualityLabel(o)
        play(o, keepPos)
    }

    private fun play(o: Option, keepPos: Boolean) = withPlayer { p ->
        val v = currentVideo
        val meta = MediaMetadata.Builder()
            .setTitle(v?.title ?: "")
            .setArtist(v?.channel ?: "")
            .apply { v?.thumb?.let { setArtworkUri(Uri.parse(it)) } }
            .build()
        val dsf = DefaultHttpDataSource.Factory()
            .setUserAgent(UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val pf = ProgressiveMediaSource.Factory(dsf)
        fun item(u: String) = MediaItem.Builder().setUri(u).setMediaMetadata(meta).build()
        val src: MediaSource = when {
            o.hls != null -> HlsMediaSource.Factory(dsf).createMediaSource(item(o.hls))
            o.video != null && o.audio != null ->
                MergingMediaSource(pf.createMediaSource(item(o.video)), pf.createMediaSource(item(o.audio)))
            else -> pf.createMediaSource(item((o.video ?: o.audio)!!))
        }
        val pos = if (keepPos) p.currentPosition else 0L
        p.setMediaSource(src)
        p.prepare()
        if (pos > 0) p.seekTo(pos)
        p.playWhenReady = if (keepPos) true else Prefs.autoStart
    }

    private fun showQuality() {
        if (options.isEmpty()) { toast("Belum ada pilihan kualitas."); return }
        MaterialAlertDialogBuilder(this)
            .setTitle("Kualitas")
            .setSingleChoiceItems(options.map { it.label }.toTypedArray(), selected) { d, i ->
                manualQuality = true
                tried.clear()
                selectOption(i, keepPos = true)
                d.dismiss()
            }
            .show()
    }

    private fun showSpeed() {
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = speeds.map { "${it}x".replace(".0x", "x") }
        val cur = player?.playbackParameters?.speed ?: 1f
        val curIdx = speeds.indexOfFirst { abs(it - cur) < 0.01f }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Kecepatan pemutaran")
            .setSingleChoiceItems(labels.toTypedArray(), curIdx) { d, i ->
                player?.setPlaybackSpeed(speeds[i])
                tvSpeed.text = labels[i]
                d.dismiss()
            }
            .show()
    }

    private fun toggleAudioOnly() {
        if (options.isEmpty()) return
        tried.clear()
        if (audioOnly) {
            selectOption(lastVideoIdx.coerceIn(0, options.size - 1), keepPos = true)
        } else {
            val a = options.indexOfFirst { it.audioOnly }
            if (a >= 0) selectOption(a, keepPos = true) else toast("Audio tidak tersedia.")
        }
    }

    private fun share(v: Video) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, "${v.title}\n${v.url}")
        startActivity(Intent.createChooser(send, "Bagikan"))
    }

    private fun showVideoMenu(v: Video, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Putar di latar belakang")
        pm.menu.add(0, 2, 1, if (Store.has("later", v.url)) "Hapus dari Nonton nanti" else "Nonton nanti")
        pm.menu.add(0, 3, 2, "Simpan ke daftar putar")
        pm.menu.add(0, 4, 3, "Bagikan")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> openVideo(v, audio = true, show = false)
                2 -> toast(if (Store.toggle("later", v)) "Disimpan ke Nonton nanti" else "Dihapus dari Nonton nanti")
                3 -> addToPlaylist(v)
                4 -> share(v)
            }
            true
        }
        pm.show()
    }

    // ============================================================ tampilan pemutar

    private fun showPlayer(show: Boolean) {
        playerOpen = show
        playerScreen.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(playerScreen.windowToken, 0)
            layoutPlayer()
            mini.visibility = View.GONE
        } else {
            if (fullscreen) setFullscreen(false)
            updateMini()
        }
    }

    private fun updateMini() {
        val p = player
        val v = currentVideo
        if (!playerOpen && v != null && p != null && p.mediaItemCount > 0) {
            mini.visibility = View.VISIBLE
            miniTitle.text = v.title
            miniPlay.setImageResource(if (p.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        } else {
            mini.visibility = View.GONE
        }
    }

    private fun stopAndClose() {
        player?.let { it.stop(); it.clearMediaItems() }
        currentVideo = null
        mini.visibility = View.GONE
    }

    private fun layoutPlayer() {
        val dm = resources.displayMetrics
        val lp = playerBox.layoutParams
        lp.height = if (fullscreen || inPip) ViewGroup.LayoutParams.MATCH_PARENT
        else minOf(dm.widthPixels * 9 / 16, (dm.heightPixels * 0.6f).toInt())
        playerBox.layoutParams = lp
        info.visibility = if (fullscreen || inPip) View.GONE else View.VISIBLE
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
        layoutPlayer()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !playerOpen) return
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (e: Exception) {
            toast("Jendela mengambang tidak didukung.")
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Prefs.pipAuto && playerOpen && !audioOnly && player?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        playerView.useController = !isInPictureInPictureMode
        if (isInPictureInPictureMode) playerTop.visibility = View.GONE
        layoutPlayer()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (playerOpen) layoutPlayer()
    }

    // ============================================================ gestur

    private fun flash(s: String) {
        tvGesture.text = s
        tvGesture.visibility = View.VISIBLE
        ui.removeCallbacks(hideGesture)
        ui.postDelayed(hideGesture, 700)
    }

    private fun setupGestures() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return false
                val w = playerView.width.coerceAtLeast(1)
                val step = Prefs.seekSeconds * 1000L
                when {
                    e.x < w / 3f -> {
                        p.seekTo((p.currentPosition - step).coerceAtLeast(0))
                        flash("« ${Prefs.seekSeconds} dtk")
                    }
                    e.x > w * 2f / 3f -> {
                        p.seekTo(p.currentPosition + step)
                        flash("${Prefs.seekSeconds} dtk »")
                    }
                    else -> if (p.isPlaying) p.pause() else p.play()
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null || abs(dy) < abs(dx)) return false
                val h = playerView.height.coerceAtLeast(1)
                val delta = dy / h
                if (e1.x > playerView.width / 2f) {
                    if (!Prefs.volGesture) return false
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    gestureVol = (gestureVol + delta * max * 1.5f).coerceIn(0f, max.toFloat())
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, gestureVol.roundToInt(), 0)
                    flash("🔊 ${(gestureVol / max * 100).roundToInt()}%")
                } else {
                    if (!Prefs.brightGesture) return false
                    gestureBr = (gestureBr + delta * 1.5f).coerceIn(0.02f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = gestureBr
                    window.attributes = lp
                    flash("☀ ${(gestureBr * 100).roundToInt()}%")
                }
                return true
            }
        })
        playerView.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                gestureVol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                val b = window.attributes.screenBrightness
                gestureBr = if (b < 0f) 0.5f else b
            }
            gd.onTouchEvent(ev)
            false
        }
    }

    companion object {
        private val CATS = listOf(
            "Trending" to "trending indonesia",
            "Musik" to "lagu terbaru",
            "DJ" to "dj terbaru full bass",
            "Dangdut" to "dangdut terbaru",
            "Gaming" to "gaming indonesia",
            "Berita" to "berita terbaru",
            "Film" to "trailer film terbaru",
            "Olahraga" to "sepak bola highlights",
            "Teknologi" to "review gadget",
            "Kuliner" to "resep masakan",
            "Podcast" to "podcast indonesia"
        )
    }
}
