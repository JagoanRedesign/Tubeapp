package com.novatube.app

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.schabi.newpipe.extractor.Page
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newFixedThreadPool(3)

    // beranda
    private lateinit var etSearch: EditText
    private lateinit var chips: LinearLayout
    private lateinit var list: RecyclerView
    private lateinit var loading: ProgressBar
    private lateinit var tvMsg: TextView
    private lateinit var mini: View
    private lateinit var miniThumb: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniPlay: ImageButton

    // pemutar
    private lateinit var playerScreen: View
    private lateinit var playerBox: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var playerLoading: ProgressBar
    private lateinit var audioCover: ImageView
    private lateinit var info: View
    private lateinit var tvTitle: TextView
    private lateinit var tvMeta: TextView
    private lateinit var btnAudio: TextView
    private lateinit var related: RecyclerView

    private val listAdapter = VideoAdapter { openVideo(it) }
    private val relatedAdapter = VideoAdapter { openVideo(it) }
    private val chipViews = ArrayList<TextView>()

    // state daftar
    private var currentQuery = ""
    private var nextPage: Page? = null
    private var loadingMore = false

    // state pemutar
    private var player: ExoPlayer? = null
    private val pending = ArrayList<(ExoPlayer) -> Unit>()
    private var currentVideo: Video? = null
    private var options: List<Option> = emptyList()
    private var selected = 0
    private var lastVideoIdx = 0
    private var retry = 0
    private var playerOpen = false
    private var fullscreen = false
    private var inPip = false
    private var audioOnly = false
    private var pipAuto = true
    private val prefs by lazy { getSharedPreferences("novatube", MODE_PRIVATE) }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val p = (binder as PlaybackService.LocalBinder).player()
            player = p
            playerView.player = p
            p.addListener(playerListener)
            pending.forEach { it(p) }
            pending.clear()
            updateMini()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            player = null
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            miniPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            playerLoading.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
        }

        override fun onPlayerError(error: PlaybackException) {
            playerLoading.visibility = View.GONE
            if (retry < 3 && selected + 1 < options.size) {
                retry++
                toast("Gagal memutar, mencoba kualitas lain…")
                selectOption(selected + 1, keepPos = false)
            } else {
                toast("Gagal memutar (${error.errorCodeName})")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        pipAuto = prefs.getBoolean("pip", true)

        list.layoutManager = LinearLayoutManager(this)
        list.adapter = listAdapter
        related.layoutManager = LinearLayoutManager(this)
        related.adapter = relatedAdapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0 && !rv.canScrollVertically(1)) load(currentQuery, true)
            }
        })

        buildChips()
        etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(); true } else false
        }
        findViewById<View>(R.id.btnSearch).setOnClickListener { doSearch() }
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }

        mini.setOnClickListener { showPlayer(true) }
        miniPlay.setOnClickListener { player?.let { if (it.isPlaying) it.pause() else it.play() } }
        findViewById<View>(R.id.miniClose).setOnClickListener { stopAndClose() }

        findViewById<View>(R.id.btnQuality).setOnClickListener { showQuality() }
        btnAudio.setOnClickListener { toggleAudioOnly() }
        findViewById<View>(R.id.btnPip).setOnClickListener { enterPip() }
        findViewById<View>(R.id.btnMin).setOnClickListener { showPlayer(false) }
        playerView.setFullscreenButtonClickListener { setFullscreen(!fullscreen) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    fullscreen -> setFullscreen(false)
                    playerOpen -> showPlayer(false)
                    else -> moveTaskToBack(true)
                }
            }
        })

        bindService(
            Intent(this, PlaybackService::class.java).setAction(PlaybackService.ACTION_LOCAL),
            conn, Context.BIND_AUTO_CREATE
        )
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        selectChip(0)
        handleIntent(intent)
    }

    private fun bindViews() {
        etSearch = findViewById(R.id.etSearch)
        chips = findViewById(R.id.chips)
        list = findViewById(R.id.list)
        loading = findViewById(R.id.loading)
        tvMsg = findViewById(R.id.tvMsg)
        mini = findViewById(R.id.mini)
        miniThumb = findViewById(R.id.miniThumb)
        miniTitle = findViewById(R.id.miniTitle)
        miniPlay = findViewById(R.id.miniPlay)
        playerScreen = findViewById(R.id.playerScreen)
        playerBox = findViewById(R.id.playerBox)
        playerView = findViewById(R.id.playerView)
        playerLoading = findViewById(R.id.playerLoading)
        audioCover = findViewById(R.id.audioCover)
        info = findViewById(R.id.info)
        tvTitle = findViewById(R.id.tvTitle)
        tvMeta = findViewById(R.id.tvMeta)
        btnAudio = findViewById(R.id.btnAudio)
        related = findViewById(R.id.related)
    }

    // ------------------------------------------------------------ beranda

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun buildChips() {
        CATS.forEachIndexed { i, c ->
            val tv = TextView(this).apply {
                text = c.first
                textSize = 13f
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setOnClickListener { selectChip(i) }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            chips.addView(tv, lp)
            chipViews.add(tv)
        }
    }

    private fun styleChips(sel: Int) {
        chipViews.forEachIndexed { i, tv ->
            val on = i == sel
            tv.setBackgroundResource(if (on) R.drawable.bg_chip_sel else R.drawable.bg_chip)
            tv.setTextColor(if (on) 0xFFFFFFFF.toInt() else getColor(R.color.muted))
        }
    }

    private fun selectChip(i: Int) {
        styleChips(i)
        etSearch.setText("")
        load(CATS[i].second)
    }

    private fun doSearch() {
        val q = etSearch.text.toString().trim()
        if (q.isEmpty()) return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etSearch.windowToken, 0)
        styleChips(-1)
        load(q)
    }

    private fun load(query: String, more: Boolean = false) {
        if (query.isEmpty() || loadingMore) return
        if (more) {
            if (nextPage == null) return
        } else {
            currentQuery = query
            nextPage = null
            listAdapter.submit(emptyList())
            tvMsg.visibility = View.GONE
            loading.visibility = View.VISIBLE
        }
        loadingMore = true
        val q = currentQuery
        val pg = nextPage
        io.execute {
            try {
                val r = if (more && pg != null) Repo.more(q, pg) else Repo.search(q)
                ui.post {
                    loadingMore = false
                    if (q != currentQuery) return@post
                    loading.visibility = View.GONE
                    nextPage = r.next
                    if (more) listAdapter.append(r.items) else listAdapter.submit(r.items)
                    if (!more && r.items.isEmpty()) showMsg("Tidak ada hasil.")
                }
            } catch (e: Exception) {
                ui.post {
                    loadingMore = false
                    loading.visibility = View.GONE
                    if (!more) showMsg("Gagal memuat: ${e.message ?: "periksa koneksi"}\nKetuk kategori untuk mencoba lagi.")
                }
            }
        }
    }

    private fun showMsg(s: String) {
        tvMsg.text = s
        tvMsg.visibility = View.VISIBLE
    }

    private fun showSettings() {
        val items = arrayOf("Jendela mengambang otomatis saat keluar aplikasi")
        val checked = booleanArrayOf(pipAuto)
        MaterialAlertDialogBuilder(this)
            .setTitle("Pengaturan")
            .setMultiChoiceItems(items, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Simpan") { _, _ ->
                pipAuto = checked[0]
                prefs.edit().putBoolean("pip", pipAuto).apply()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ------------------------------------------------------------ intent

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        i ?: return
        val raw = when (i.action) {
            Intent.ACTION_VIEW -> i.data?.toString()
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)?.let { Regex("https?://\\S+").find(it)?.value }
            else -> null
        } ?: return
        openVideo(Video(raw, "Memuat…", "", -1, "", 0, null))
    }

    // ------------------------------------------------------------ pemutar

    private fun withPlayer(block: (ExoPlayer) -> Unit) {
        val p = player
        if (p != null) block(p) else pending.add(block)
    }

    private fun openVideo(v: Video) {
        currentVideo = v
        options = emptyList()
        retry = 0
        audioOnly = false
        audioCover.visibility = View.GONE
        btnAudio.text = "🎧 Audio saja"
        tvTitle.text = v.title
        tvMeta.text = Fmt.meta(v)
        relatedAdapter.submit(emptyList())
        playerLoading.visibility = View.VISIBLE
        showPlayer(true)
        withPlayer { it.stop() }
        io.execute {
            try {
                val si = Repo.stream(v.url)
                val opts = Repo.options(si)
                val rel = Repo.map(si.relatedItems)
                ui.post {
                    if (currentVideo?.url != v.url) return@post
                    val full = Video(
                        v.url, si.name ?: v.title, si.uploaderName ?: v.channel,
                        si.viewCount, v.date, si.duration, si.thumbnails.firstOrNull()?.url ?: v.thumb
                    )
                    currentVideo = full
                    tvTitle.text = full.title
                    tvMeta.text = Fmt.meta(full)
                    relatedAdapter.submit(rel)
                    options = opts
                    if (opts.isEmpty()) {
                        playerLoading.visibility = View.GONE
                        toast("Tidak ada stream yang bisa diputar.")
                    } else {
                        selectOption(Repo.defaultIndex(opts), keepPos = false)
                    }
                }
            } catch (e: Exception) {
                ui.post {
                    if (currentVideo?.url != v.url) return@post
                    playerLoading.visibility = View.GONE
                    toast("Gagal memuat video: ${e.message ?: "kesalahan"}")
                }
            }
        }
    }

    private fun selectOption(idx: Int, keepPos: Boolean) {
        val o = options.getOrNull(idx) ?: return
        selected = idx
        audioOnly = o.audioOnly
        if (!o.audioOnly) lastVideoIdx = idx
        audioCover.visibility = if (o.audioOnly) View.VISIBLE else View.GONE
        if (o.audioOnly) audioCover.load(currentVideo?.thumb)
        btnAudio.text = if (o.audioOnly) "📺 Video" else "🎧 Audio saja"
        play(o, keepPos)
    }

    private fun play(o: Option, keepPos: Boolean) = withPlayer { p ->
        val v = currentVideo
        val meta = MediaMetadata.Builder()
            .setTitle(v?.title ?: "")
            .setArtist(v?.channel ?: "")
            .apply { v?.thumb?.let { setArtworkUri(Uri.parse(it)) } }
            .build()
        val dsf = DefaultHttpDataSource.Factory()
            .setUserAgent(UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val pf = ProgressiveMediaSource.Factory(dsf)
        fun item(u: String) = MediaItem.Builder().setUri(u).setMediaMetadata(meta).build()
        val src: MediaSource = when {
            o.hls != null -> HlsMediaSource.Factory(dsf).createMediaSource(item(o.hls))
            o.video != null && o.audio != null ->
                MergingMediaSource(pf.createMediaSource(item(o.video)), pf.createMediaSource(item(o.audio)))
            else -> pf.createMediaSource(item((o.video ?: o.audio)!!))
        }
        val pos = if (keepPos) p.currentPosition else 0L
        p.setMediaSource(src)
        p.prepare()
        if (pos > 0) p.seekTo(pos)
        p.playWhenReady = true
    }

    private fun showQuality() {
        if (options.isEmpty()) { toast("Belum ada pilihan kualitas."); return }
        MaterialAlertDialogBuilder(this)
            .setTitle("Kualitas")
            .setSingleChoiceItems(options.map { it.label }.toTypedArray(), selected) { d, i ->
                retry = 0
                selectOption(i, keepPos = true)
                d.dismiss()
            }
            .show()
    }

    private fun toggleAudioOnly() {
        if (options.isEmpty()) return
        if (audioOnly) {
            selectOption(lastVideoIdx.coerceIn(0, options.size - 1), keepPos = true)
        } else {
            val a = options.indexOfFirst { it.audioOnly }
            if (a >= 0) selectOption(a, keepPos = true) else toast("Audio tidak tersedia.")
        }
    }

    private fun showPlayer(show: Boolean) {
        playerOpen = show
        playerScreen.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            layoutPlayer()
            mini.visibility = View.GONE
        } else {
            if (fullscreen) setFullscreen(false)
            updateMini()
        }
    }

    private fun updateMini() {
        val p = player
        val v = currentVideo
        if (!playerOpen && v != null && p != null && p.mediaItemCount > 0) {
            mini.visibility = View.VISIBLE
            miniTitle.text = v.title
            miniThumb.load(v.thumb)
            miniPlay.setImageResource(if (p.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        } else {
            mini.visibility = View.GONE
        }
    }

    private fun stopAndClose() {
        player?.let { it.stop(); it.clearMediaItems() }
        currentVideo = null
        mini.visibility = View.GONE
    }

    private fun layoutPlayer() {
        val dm = resources.displayMetrics
        val lp = playerBox.layoutParams
        lp.height = if (fullscreen || inPip) ViewGroup.LayoutParams.MATCH_PARENT
        else minOf(dm.widthPixels * 9 / 16, (dm.heightPixels * 0.6f).toInt())
        playerBox.layoutParams = lp
        info.visibility = if (fullscreen || inPip) View.GONE else View.VISIBLE
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
        layoutPlayer()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !playerOpen) return
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (e: Exception) {
            toast("Jendela mengambang tidak didukung.")
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipAuto && playerOpen && !audioOnly && player?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        playerView.useController = !isInPictureInPictureMode
        layoutPlayer()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (playerOpen) layoutPlayer()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.removeListener(playerListener)
        try { unbindService(conn) } catch (e: Exception) { }
        io.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private val CATS = listOf(
            "Trending" to "trending indonesia",
            "Musik" to "lagu terbaru",
            "Gaming" to "gaming indonesia",
            "Berita" to "berita terbaru",
            "Film" to "trailer film terbaru",
            "Olahraga" to "sepak bola highlights",
            "Teknologi" to "review gadget",
            "Kuliner" to "resep masakan",
            "Podcast" to "podcast indonesia"
        )
    }
}
