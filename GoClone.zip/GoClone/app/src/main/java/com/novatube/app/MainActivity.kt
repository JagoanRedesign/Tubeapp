package com.novatube.app

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.os.SystemClock
import android.text.util.Linkify
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import android.graphics.Typeface
import android.provider.Settings
import android.util.TypedValue
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.source.SingleSampleMediaSource
import org.schabi.newpipe.extractor.Page
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    internal val ui = Handler(Looper.getMainLooper())
    internal val io: ExecutorService = Executors.newFixedThreadPool(4)

    // ---- cangkang
    private lateinit var header: View
    private lateinit var etSearch: EditText
    private lateinit var chips: LinearLayout
    private lateinit var tabHome: View
    private lateinit var tabLib: View
    private lateinit var list: RecyclerView
    private lateinit var loading: ProgressBar
    private lateinit var tvMsg: TextView
    private lateinit var localList: RecyclerView
    private lateinit var tvLocalEmpty: TextView
    private lateinit var page: View
    private lateinit var pageTitle: TextView
    private lateinit var pageList: RecyclerView
    private lateinit var pageScroll: View
    internal lateinit var pageBox: LinearLayout
    internal lateinit var pageEmpty: TextView
    private lateinit var mini: View
    private lateinit var miniVideoView: PlayerView
    private lateinit var miniTitle: TextView
    private lateinit var miniPlay: ImageButton
    private lateinit var navHomeIcon: ImageView
    private lateinit var navHomeText: TextView
    private lateinit var navShortsIcon: ImageView
    private lateinit var navShortsText: TextView
    private lateinit var navSubsIcon: ImageView
    private lateinit var navSubsText: TextView
    private lateinit var navProfileIcon: ImageView
    private lateinit var navProfileText: TextView
    private lateinit var tabSubs: View
    private lateinit var shortsRoot: View
    private lateinit var subsStrip: LinearLayout
    private lateinit var subsList: RecyclerView
    private lateinit var subsLoading: ProgressBar
    private lateinit var subsMsg: TextView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var pfAvatar: ImageView
    private lateinit var pfName: TextView
    private lateinit var pfStatus: TextView
    private lateinit var pfAction: TextView
    private lateinit var shorts: ShortsScreen
    private val subsAdapter = VideoAdapter({ openVideo(it) }, { v, anchor -> showVideoMenu(v, anchor) })
    private var subsLoadedAt = 0L
    private var pendingKey = ""
    private var ytRating = "none"
    private var ytRatingBase = "none"
    private var ytLikeBase = -1L
    private var isSubscribed = false
    private var hintShown = false

    // ---- pemutar
    private lateinit var playerScreen: View
    private lateinit var playerBox: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var playerTop: View
    private lateinit var playerLoading: ProgressBar
    private lateinit var audioCover: ImageView
    private lateinit var tvGesture: TextView
    private lateinit var tvQuality: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var info: View
    private lateinit var tvTitle: TextView
    private lateinit var tvMeta: TextView
    private lateinit var tvDesc: TextView
    private lateinit var chAvatar: ImageView
    private lateinit var chName: TextView
    private lateinit var chSubs: TextView
    private lateinit var btnSub: TextView
    private lateinit var icLike: ImageView
    private lateinit var tvLike: TextView
    private var searchOpen = false
    private var searching = false
    private lateinit var commentPreview: View
    private lateinit var cmAvatar: ImageView
    private lateinit var cmText: TextView
    private lateinit var related: RecyclerView

    private val feedAdapter = VideoAdapter({ openVideo(it) }, { v, a -> showVideoMenu(v, a) })
    private val relatedAdapter = VideoAdapter({ openVideo(it) }, { v, a -> showVideoMenu(v, a) })
    private val pageAdapter = VideoAdapter({ openVideo(it) }, { v, a -> showVideoMenu(v, a) })
    private val localAdapter = LocalAdapter { openVideo(it) }
    private val chipViews = ArrayList<TextView>()

    // state beranda
    private var tab = 0
    private var pageOpen = false
    private var currentQuery = ""
    private var nextPage: Page? = null
    private var loadingMore = false

    // state pemutar
    private var player: ExoPlayer? = null
    private val pending = ArrayList<(ExoPlayer) -> Unit>()
    private var currentVideo: Video? = null
    private var currentChannel: Channel? = null
    private var autoQueue: List<Video> = emptyList()
    private lateinit var miniProgress: ProgressBar
    private lateinit var tvSleep: TextView
    private lateinit var pageAction: TextView
    internal var pageMore: (() -> Unit)? = null
    internal var pageCloseHook: (() -> Unit)? = null
    private var commentSession: CommentsSession? = null
    private var firstComments: CommentsPage? = null
    private var subs: List<SubTrack> = emptyList()
    private var audioTracks: List<AudioTrack> = emptyList()
    private var activeSub: SubTrack? = null
    private var audioOverride: AudioTrack? = null
    private var currentOption: Option? = null
    private var pendingSeek = 0L
    private var gotVideo = false
    private var sleepEndAt = 0L
    private var sleepAtEnd = false
    private var tickCount = 0
    private var lastError = ""
    private var localMode = false
    private var comments: List<Pair<String, String>> = emptyList()
    private var options: List<Option> = emptyList()
    private val tried = HashSet<Int>()
    private var selected = 0
    private var lastVideoIdx = 0
    private var manualQuality = false
    private var playerOpen = false
    private var fullscreen = false
    private var inPip = false
    private var audioOnly = false
    private var gestureVol = 0f
    private var gestureBr = 0.5f

    private val hideGesture = Runnable { tvGesture.visibility = View.GONE }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (!ok) toast("Izin notifikasi ditolak: tombol putar/jeda di notifikasi tidak akan tampil")
        }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val p = (binder as PlaybackService.LocalBinder).player()
            player = p
            // Satu ExoPlayer hanya boleh terpasang ke satu PlayerView aktif.
            attachPlayerSurface(playerOpen)
            miniVideoView.useController = false
            p.addListener(playerListener)
            applyPlayerPrefs()
            pending.forEach { it(p) }
            pending.clear()
            if (currentVideo == null && p.mediaItemCount > 0) {
                Now.video?.let {
                    currentVideo = it
                    autoQueue = Now.auto
                    audioOnly = Now.audioOnly
                }
            }
            updateMini()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            player = null
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            miniPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            if (!isPlaying) saveProgressNow()
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0) gotVideo = true
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            playerLoading.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (playbackState == Player.STATE_ENDED) onVideoEnded()
        }

        override fun onPlayerError(error: PlaybackException) {
            playerLoading.visibility = View.GONE
            lastError = "${error.errorCodeName}: ${error.cause?.javaClass?.simpleName ?: ""} ${error.cause?.message ?: ""}"
            val next = Repo.fallback(options, tried)
            if (next >= 0 && !localMode) {
                toast("Gagal memutar, mencoba kualitas lain…")
                selectOption(next, keepPos = true)
            } else {
                toast("Gagal memutar (${error.errorCodeName})")
            }
        }
    }

    private val blankCheck = Runnable {
        val p = player ?: return@Runnable
        if (!audioOnly && !localMode && p.isPlaying && !gotVideo && p.videoSize.width == 0) {
            val next = Repo.fallback(options, tried)
            if (next >= 0) {
                toast("Gambar tidak muncul, mencoba kualitas lain…")
                selectOption(next, keepPos = true)
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            tickCount++
            val p = player
            if (p != null) {
                if (p.isPlaying && tickCount % 5 == 0) saveProgressNow()
                if (mini.visibility == View.VISIBLE && p.duration > 0) {
                    miniProgress.progress = (p.currentPosition * 1000 / p.duration).toInt()
                }
            }
            sleepTick()
            ui.postDelayed(this, 1000)
        }
    }

    // ============================================================ siklus hidup

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        YtAuth.init(this)
        setTheme(Prefs.themeRes(this))
        super.onCreate(savedInstanceState)
        Store.init(this)
        Downloads.init(this)
        Queue.persist = { Store.setList("queue", it) }
        Queue.load(Store.list("queue"))
        Repo.lowData = Prefs.dataSaverActive(this)
        setContentView(R.layout.activity_main)
        bindViews()
        setupHome()
        setupLibrary()
        setupPlayer()
        setupGestures()
        setupShortsAndTabs()
        ui.postDelayed(ticker, 1000)
        PlaybackBus.onNext = { runOnUiThread { playNext(false) } }
        PlaybackBus.onPrev = { runOnUiThread { playPrev() } }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    fullscreen -> setFullscreen(false)
                    playerOpen -> showPlayer(false)
                    pageOpen -> closePage()
                    searchOpen -> closeSearch()
                    tab != 0 -> showTab(0)
                    else -> moveTaskToBack(true)
                }
            }
        })

        bindService(
            Intent(this, PlaybackService::class.java).setAction(PlaybackService.ACTION_LOCAL),
            conn, Context.BIND_AUTO_CREATE
        )
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        showTab(0)
        selectChip(0)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Repo.lowData = Prefs.dataSaverActive(this)
        if (tab == 1) shorts.onShow()
    }

    override fun onStop() {
        super.onStop()
        if (tab == 1) shorts.onHide()
        saveProgressNow()
        if (!Prefs.bgPlay && !inPip && !isChangingConfigurations) player?.pause()
    }

    override fun onDestroy() {
        saveProgressNow()
        shorts.release()
        ui.removeCallbacks(ticker)
        PlaybackBus.onNext = null
        PlaybackBus.onPrev = null
        ui.removeCallbacks(blankCheck)
        playerView.player = null
        miniVideoView.player = null
        player?.removeListener(playerListener)
        try { unbindService(conn) } catch (e: Exception) { }
        io.shutdownNow()
        super.onDestroy()
    }

    private fun bindViews() {
        header = findViewById(R.id.header)
        etSearch = findViewById(R.id.etSearch)
        chips = findViewById(R.id.chips)
        tabHome = findViewById(R.id.tabHome)
        tabLib = findViewById(R.id.tabLib)
        list = findViewById(R.id.list)
        loading = findViewById(R.id.loading)
        tvMsg = findViewById(R.id.tvMsg)
        localList = findViewById(R.id.localList)
        tvLocalEmpty = findViewById(R.id.tvLocalEmpty)
        page = findViewById(R.id.page)
        pageTitle = findViewById(R.id.pageTitle)
        pageList = findViewById(R.id.pageList)
        pageScroll = findViewById(R.id.pageScroll)
        pageBox = findViewById(R.id.pageBox)
        pageEmpty = findViewById(R.id.pageEmpty)
        mini = findViewById(R.id.mini)
        miniVideoView = findViewById(R.id.miniVideoView)
        miniTitle = findViewById(R.id.miniTitle)
        miniPlay = findViewById(R.id.miniPlay)
        navHomeIcon = findViewById(R.id.navHomeIcon)
        navHomeText = findViewById(R.id.navHomeText)
        navShortsIcon = findViewById(R.id.navShortsIcon)
        navShortsText = findViewById(R.id.navShortsText)
        navSubsIcon = findViewById(R.id.navSubsIcon)
        navSubsText = findViewById(R.id.navSubsText)
        navProfileIcon = findViewById(R.id.navProfileIcon)
        navProfileText = findViewById(R.id.navProfileText)
        tabSubs = findViewById(R.id.tabSubs)
        shortsRoot = findViewById(R.id.shortsRoot)
        subsStrip = findViewById(R.id.subsStrip)
        subsList = findViewById(R.id.subsList)
        subsLoading = findViewById(R.id.subsLoading)
        subsMsg = findViewById(R.id.subsMsg)
        refresh = findViewById(R.id.refresh)
        pfAvatar = findViewById(R.id.pfAvatar)
        pfName = findViewById(R.id.pfName)
        pfStatus = findViewById(R.id.pfStatus)
        pfAction = findViewById(R.id.pfAction)

        playerScreen = findViewById(R.id.playerScreen)
        playerBox = findViewById(R.id.playerBox)
        playerView = findViewById(R.id.playerView)
        playerTop = findViewById(R.id.playerTop)
        playerLoading = findViewById(R.id.playerLoading)
        audioCover = findViewById(R.id.audioCover)
        tvGesture = findViewById(R.id.tvGesture)
        tvQuality = findViewById(R.id.tvQuality)
        tvSpeed = findViewById(R.id.tvSpeed)
        info = findViewById(R.id.info)
        tvTitle = findViewById(R.id.tvTitle)
        tvMeta = findViewById(R.id.tvMeta)
        tvDesc = findViewById(R.id.tvDesc)
        chAvatar = findViewById(R.id.chAvatar)
        chName = findViewById(R.id.chName)
        chSubs = findViewById(R.id.chSubs)
        btnSub = findViewById(R.id.btnSub)
        icLike = findViewById(R.id.icLike)
        tvLike = findViewById(R.id.tvLike)
        commentPreview = findViewById(R.id.commentPreview)
        cmAvatar = findViewById(R.id.cmAvatar)
        cmText = findViewById(R.id.cmText)
        related = findViewById(R.id.related)
        miniProgress = findViewById(R.id.miniProgress)
        tvSleep = findViewById(R.id.tvSleep)
        pageAction = findViewById(R.id.pageAction)
    }

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    internal fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ============================================================ beranda

    private fun setupHome() {
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = feedAdapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0 && !rv.canScrollVertically(1)) load(currentQuery, true)
            }
        })
        CATS.forEachIndexed { i, c ->
            val tv = TextView(this).apply {
                text = c.first
                textSize = 14f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { selectChip(i) }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            chips.addView(tv, lp)
            chipViews.add(tv)
        }
        etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(); true } else false
        }
        findViewById<View>(R.id.btnSearch).setOnClickListener { doSearch() }
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettingsPage() }
        findViewById<View>(R.id.btnSearchOpen).setOnClickListener { openSearch() }
        findViewById<View>(R.id.btnSearchBack).setOnClickListener { closeSearch() }
        findViewById<View>(R.id.btnExplore).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Jelajahi")
                .setItems(CATS.map { it.first }.toTypedArray()) { _, i -> selectChip(i) }
                .show()
        }
        findViewById<View>(R.id.navHome).setOnClickListener { showTab(0) }
        findViewById<View>(R.id.navShorts).setOnClickListener { showTab(1) }
        findViewById<View>(R.id.navAdd).setOnClickListener { showAddSheet() }
        findViewById<View>(R.id.navSubs).setOnClickListener { showTab(3) }
        findViewById<View>(R.id.navProfile).setOnClickListener { showTab(4) }
        refresh.setOnRefreshListener {
            refresh.isRefreshing = false
            load(currentQuery)
        }
        findViewById<View>(R.id.pageBack).setOnClickListener { closePage() }
        pageList.layoutManager = LinearLayoutManager(this)
        pageList.adapter = pageAdapter
        pageList.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0 && !rv.canScrollVertically(1)) pageMore?.invoke()
            }
        })

        mini.setOnClickListener { showPlayer(true); ensureDetails() }
        miniVideoView.setOnClickListener { showPlayer(true) }
        miniPlay.setOnClickListener { player?.let { if (it.isPlaying) it.pause() else it.play() } }
        findViewById<View>(R.id.miniClose).setOnClickListener { stopAndClose() }
    }

    private fun openSearch() {
        searchOpen = true
        findViewById<View>(R.id.headerMain).visibility = View.GONE
        findViewById<View>(R.id.headerSearch).visibility = View.VISIBLE
        etSearch.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideSearchUi() {
        searchOpen = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etSearch.windowToken, 0)
        findViewById<View>(R.id.headerSearch).visibility = View.GONE
        findViewById<View>(R.id.headerMain).visibility = View.VISIBLE
    }

    private fun closeSearch() {
        hideSearchUi()
        if (searching) {
            searching = false
            selectChip(0)
        }
    }

    private fun styleChips(sel: Int) {
        chipViews.forEachIndexed { i, tv ->
            val on = i == sel
            tv.setBackgroundResource(if (on) R.drawable.bg_chip_sel else R.drawable.bg_chip)
            tv.setTextColor(if (on) themeColor(R.attr.ntChipSelText) else themeColor(R.attr.ntText))
        }
    }

    private fun selectChip(i: Int) {
        if (searchOpen) hideSearchUi()
        searching = false
        styleChips(i)
        etSearch.setText("")
        showTab(0)
        load(CATS[i].second)
    }

    private fun searchFor(q: String) {
        etSearch.setText(q)
        styleChips(-1)
        showTab(0)
        load(q)
    }

    private fun doSearch() {
        val q = etSearch.text.toString().trim()
        if (q.isEmpty()) return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etSearch.windowToken, 0)
        searching = true
        styleChips(-1)
        showTab(0)
        load(q)
    }

    private fun showTab(t: Int) {
        if (searchOpen && t != 0) hideSearchUi()
        val leavingShorts = tab == 1 && t != 1
        tab = t
        closePage()
        tabHome.visibility = if (t == 0) View.VISIBLE else View.GONE
        shortsRoot.visibility = if (t == 1) View.VISIBLE else View.GONE
        tabSubs.visibility = if (t == 3) View.VISIBLE else View.GONE
        tabLib.visibility = if (t == 4) View.VISIBLE else View.GONE
        header.visibility = if (t == 0 || t == 3) View.VISIBLE else View.GONE
        styleNav(t)
        if (t == 1) {
            shorts.ensureStarted()
            shorts.onShow()
        } else if (leavingShorts) {
            shorts.onHide()
        }
        if (t == 3) refreshSubs(false)
        if (t == 4) {
            refreshProfile()
            refreshLibrary()
        }
    }

    private fun styleNav(t: Int) {
        val on = getColor(R.color.accent)
        val off = themeColor(R.attr.ntMuted)
        fun s(icon: ImageView, text: TextView, sel: Boolean) {
            icon.setColorFilter(if (sel) on else off)
            text.setTextColor(if (sel) on else off)
        }
        s(navHomeIcon, navHomeText, t == 0)
        s(navShortsIcon, navShortsText, t == 1)
        s(navSubsIcon, navSubsText, t == 3)
        s(navProfileIcon, navProfileText, t == 4)
    }

    private fun setupShortsAndTabs() {
        shorts = ShortsScreen(this, shortsRoot)
        subsList.layoutManager = LinearLayoutManager(this)
        subsList.adapter = subsAdapter
        pfAction.setOnClickListener { if (YtAuth.loggedIn) confirmLogout() else startLogin() }
    }

    internal fun pauseMain() {
        player?.pause()
    }

    private fun ensureDetails() {
        val v = currentVideo ?: return
        if (options.isEmpty() && !localMode) openVideo(v, show = true, resume = true)
    }

    /** Buka tampilan Shorts dengan daftar tertentu, mulai dari [index]. */
    internal fun openShorts(list: List<Video>, index: Int) {
        shorts.start(ListFeed(), list, index)
        showTab(1)
    }

    private fun showShortsHistory() {
        val list = Store.list("shorts_hist")
        val ad = VideoAdapter(
            { v -> openShorts(list, list.indexOfFirst { it.url == v.url }.coerceAtLeast(0)) },
            { v, anchor -> showVideoMenu(v, anchor) }
        )
        showCustomPage("Riwayat Shorts", ad, LinearLayoutManager(this), null, null)
        ad.submit(list)
        pageEmpty.text = "Belum ada riwayat Shorts."
        pageEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------ tab Langganan
    private fun buildSubsStrip() {
        subsStrip.removeAllViews()
        for (c in Store.subs()) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(6), dp(6), dp(2))
                setOnClickListener { openChannel(c) }
            }
            val iv = ImageView(this).apply {
                setBackgroundResource(R.drawable.bg_circle)
                layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
            }
            val av = c.avatar
            if (av != null) iv.load(av) { transformations(CircleCropTransformation()) }
            val tv = TextView(this).apply {
                text = c.name
                textSize = 11f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                maxWidth = dp(64)
                gravity = android.view.Gravity.CENTER
                setTextColor(themeColor(R.attr.ntMuted))
                setPadding(0, dp(4), 0, 0)
            }
            col.addView(iv)
            col.addView(tv)
            subsStrip.addView(col)
        }
    }

    private fun refreshSubs(force: Boolean) {
        buildSubsStrip()
        val subs = Store.subs()
        if (subs.isEmpty()) {
            subsAdapter.submit(emptyList())
            subsLoading.visibility = View.GONE
            subsMsg.text = "Belum ada langganan.\nBerlangganan kanal dari halaman video, atau masuk akun YouTube di Profil untuk mengimpor langganan Anda."
            subsMsg.visibility = View.VISIBLE
            return
        }
        subsMsg.visibility = View.GONE
        if (!force && subsAdapter.itemCount > 0 && System.currentTimeMillis() - subsLoadedAt < 5 * 60_000) return
        subsLoading.visibility = View.VISIBLE
        io.execute {
            val pool = Executors.newFixedThreadPool(4)
            val tasks = subs.take(15).map { c ->
                java.util.concurrent.Callable<List<Video>> {
                    try {
                        val h = Repo.channel(c.url).tabs["videos"]
                        if (h == null) emptyList()
                        else Repo.tab(h).items.filterIsInstance<Video>().take(4)
                            .map { it.copy(avatar = it.avatar ?: c.avatar, channel = it.channel.ifBlank { c.name }) }
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
            }
            val all = try {
                pool.invokeAll(tasks).flatMap { f -> try { f.get() } catch (e: Exception) { emptyList<Video>() } }
            } finally {
                pool.shutdown()
            }
            val sorted = all.sortedBy { Util.ageOf(it.date) }
            ui.post {
                subsLoading.visibility = View.GONE
                subsLoadedAt = System.currentTimeMillis()
                subsAdapter.submit(sorted)
                if (sorted.isEmpty()) {
                    subsMsg.text = "Belum ada video terbaru dari kanal yang Anda ikuti."
                    subsMsg.visibility = View.VISIBLE
                }
            }
        }
    }

    // ------------------------------------------------------------ tombol Tambah
    private fun showAddSheet() {
        val items = arrayOf("Tempel tautan YouTube", "Buat daftar putar", "Buka antrean", "Buka unduhan")
        MaterialAlertDialogBuilder(this)
            .setTitle("Tambah")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> promptLink()
                    1 -> promptNewPlaylist { showPlaylistsPage() }
                    2 -> QueueSheet(this).show()
                    3 -> DownloadsPage(this).open()
                }
            }
            .show()
    }

    private fun promptLink() {
        val et = EditText(this).apply { hint = "https://youtu.be/…"; setSingleLine() }
        val box = FrameLayout(this).apply { setPadding(dp(24), dp(8), dp(24), 0); addView(et) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Buka tautan")
            .setView(box)
            .setPositiveButton("Buka") { _, _ -> openFromLink(et.text.toString()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    internal fun openFromLink(raw: String) {
        val u = raw.trim()
        if (!u.startsWith("http")) { toast("Tautan tidak valid"); return }
        if (u.contains("/shorts/")) {
            shorts.start(ListFeed(), listOf(Video(u, "Shorts", "", -1, "", 0, null)), 0)
            showTab(1)
        } else {
            openVideo(Video(u, "Memuat…", "", -1, "", 0, null))
        }
    }

    // ------------------------------------------------------------ profil & akun YouTube
    private fun refreshProfile() {
        if (YtAuth.loggedIn) {
            pfName.text = YtAuth.accountName.ifBlank { "Akun YouTube" }
            pfStatus.text = "Terhubung ke YouTube • suka & langganan dikirim ke akun Anda"
            pfAction.text = "KELUAR"
            val av = YtAuth.accountAvatar
            if (av != null) {
                pfAvatar.setPadding(0, 0, 0, 0)
                pfAvatar.load(av) { transformations(CircleCropTransformation()) }
            }
        } else {
            pfName.text = "Tamu"
            pfStatus.text = "Masuk akun YouTube agar suka & langganan terkirim ke YouTube"
            pfAction.text = "MASUK"
            pfAvatar.setImageResource(R.drawable.ic_account)
            pfAvatar.setPadding(dp(12), dp(12), dp(12), dp(12))
        }
    }

    private fun confirmLogout() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Keluar dari akun YouTube?")
            .setMessage("Suka dan langganan akan kembali tersimpan di perangkat saja.")
            .setPositiveButton("Keluar") { _, _ ->
                YtAuth.logout()
                Social.reset()
                refreshProfile()
                toast("Anda sudah keluar")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showOAuthHelp() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Membuat Client ID OAuth")
            .setMessage(
                "1. Buka console.cloud.google.com dan buat proyek.\n" +
                    "2. APIs & Services → Library → aktifkan “YouTube Data API v3”.\n" +
                    "3. OAuth consent screen → External → tambahkan akun Google Anda sebagai Test user.\n" +
                    "4. Credentials → Create credentials → OAuth client ID → jenis “TVs and Limited Input devices”.\n" +
                    "5. Salin Client ID dan Client secret ke aplikasi ini.\n\n" +
                    "Kuota gratis 10.000 unit/hari; satu suka atau langganan sekitar 50 unit."
            )
            .setPositiveButton("Tutup", null)
            .show()
    }

    private fun showOAuthDialog(done: (() -> Unit)?) {
        val idEt = EditText(this).apply { hint = "Client ID"; setSingleLine(); setText(YtAuth.clientId) }
        val secEt = EditText(this).apply { hint = "Client secret"; setSingleLine(); setText(YtAuth.clientSecret) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(idEt)
            addView(secEt)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Client OAuth (TV & perangkat terbatas)")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                YtAuth.clientId = idEt.text.toString()
                YtAuth.clientSecret = secEt.text.toString()
                if (YtAuth.configured) done?.invoke() else toast("Client ID dan secret wajib diisi")
            }
            .setNeutralButton("Panduan") { _, _ -> showOAuthHelp() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun startLogin() {
        if (!YtAuth.configured) {
            showOAuthDialog { startLogin() }
            return
        }
        toast("Meminta kode masuk…")
        io.execute {
            try {
                val dc = YtAuth.requestDeviceCode()
                ui.post { showDeviceDialog(dc) }
            } catch (e: Exception) {
                ui.post { toast("Gagal: ${e.message ?: ""}") }
            }
        }
    }

    private fun showDeviceDialog(dc: YtAuth.DeviceCode) {
        var cancelled = false
        val d = MaterialAlertDialogBuilder(this)
            .setTitle("Masuk ke YouTube")
            .setMessage("1. Buka ${dc.url}\n2. Masukkan kode:\n\n      ${dc.userCode}\n\nSetelah menyetujui, jendela ini menutup otomatis.")
            .setPositiveButton("Salin kode & buka", null)
            .setNegativeButton("Batal") { _, _ -> cancelled = true }
            .setOnCancelListener { cancelled = true }
            .create()
        d.show()
        d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("kode", dc.userCode))
            toast("Kode disalin")
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(dc.url))) } catch (e: Exception) { }
        }
        io.execute {
            var wait = dc.interval.coerceAtLeast(3) * 1000L
            val end = System.currentTimeMillis() + dc.expiresIn * 1000L
            while (!cancelled && System.currentTimeMillis() < end) {
                try { Thread.sleep(wait) } catch (e: InterruptedException) { return@execute }
                if (cancelled) break
                val r = try { YtAuth.pollToken(dc) } catch (e: Exception) { "pending" }
                when (r) {
                    "pending" -> {}
                    "slow_down" -> wait += 3000
                    "ok" -> {
                        val me = try { YtApi.me() } catch (e: Exception) { null }
                        YtAuth.accountName = me?.first ?: ""
                        YtAuth.accountAvatar = me?.second
                        Social.reset()
                        ui.post {
                            d.dismiss()
                            toast("Berhasil masuk")
                            refreshProfile()
                            Social.importSubscriptions(this) { n -> if (n > 0) toast("$n langganan diimpor dari YouTube") }
                        }
                        return@execute
                    }
                    else -> {
                        ui.post { d.dismiss(); toast("Gagal masuk: $r") }
                        return@execute
                    }
                }
            }
            ui.post { if (d.isShowing) d.dismiss() }
        }
    }

    private fun hintLogin() {
        if (!YtAuth.loggedIn && !hintShown) {
            hintShown = true
            toast("Disimpan di perangkat. Masuk akun YouTube di Profil agar terkirim ke YouTube.")
        }
    }

    private fun load(query: String, more: Boolean = false) {
        if (query.isEmpty() || loadingMore) return
        if (more) {
            if (nextPage == null) return
        } else {
            currentQuery = query
            nextPage = null
            feedAdapter.submit(emptyList())
            tvMsg.visibility = View.GONE
            loading.visibility = View.VISIBLE
        }
        loadingMore = true
        val q = currentQuery
        val pg = nextPage
        io.execute {
            try {
                val r = if (more && pg != null) Repo.more(q, pg) else Repo.search(q)
                ui.post {
                    loadingMore = false
                    if (q != currentQuery) return@post
                    loading.visibility = View.GONE
                    nextPage = r.next
                    if (more) feedAdapter.append(r.items) else feedAdapter.submit(r.items)
                    if (!more && r.items.isEmpty()) showMsg("Tidak ada hasil.")
                }
            } catch (e: Exception) {
                ui.post {
                    loadingMore = false
                    loading.visibility = View.GONE
                    if (!more) showMsg("Gagal memuat: ${e.message ?: "periksa koneksi"}\nKetuk kategori untuk mencoba lagi.")
                }
            }
        }
    }

    private fun showMsg(s: String) {
        tvMsg.text = s
        tvMsg.visibility = View.VISIBLE
    }

    // ============================================================ pustaka

    private fun setupLibrary() {
        localList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        localList.adapter = localAdapter
        findViewById<View>(R.id.rowSubs).setOnClickListener { showSubsPage() }
        findViewById<View>(R.id.rowHistory).setOnClickListener { showVideoPage("Riwayat", Store.history()) }
        findViewById<View>(R.id.rowLater).setOnClickListener { showVideoPage("Nonton nanti", Store.list("later")) }
        findViewById<View>(R.id.rowLiked).setOnClickListener { showVideoPage("Video yang disukai", Store.list("liked")) }
        findViewById<View>(R.id.rowPlaylists).setOnClickListener { showPlaylistsPage() }
        findViewById<View>(R.id.rowQueue).setOnClickListener { QueueSheet(this).show() }
        findViewById<View>(R.id.rowDownloads).setOnClickListener { DownloadsPage(this).open() }
        findViewById<View>(R.id.rowShortsHist).setOnClickListener { showShortsHistory() }
        findViewById<View>(R.id.rowSettings).setOnClickListener { showSettingsPage() }
        findViewById<View>(R.id.btnLocalMore).setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            pm.menu.add("Hapus riwayat")
            pm.setOnMenuItemClickListener { confirmClearHistory(); true }
            pm.show()
        }
    }

    private fun refreshLibrary() {
        val h = Store.history().take(12)
        localAdapter.submit(h)
        localList.visibility = if (h.isEmpty()) View.GONE else View.VISIBLE
        tvLocalEmpty.visibility = if (h.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmClearHistory() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus riwayat?")
            .setMessage("Semua riwayat tontonan di perangkat ini akan dihapus.")
            .setPositiveButton("Hapus") { _, _ -> Store.clearHistory(); refreshLibrary(); toast("Riwayat dihapus") }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ============================================================ halaman dalam

    internal fun openPage(title: String, kind: Int) {
        pageCloseHook?.invoke()
        pageCloseHook = null
        pageMore = null
        pageAction.visibility = View.GONE
        if (pageList.adapter !== pageAdapter) {
            pageList.layoutManager = LinearLayoutManager(this)
            pageList.adapter = pageAdapter
        }
        pageOpen = true
        header.visibility = View.GONE
        page.visibility = View.VISIBLE
        pageTitle.text = title
        pageList.visibility = if (kind == 0) View.VISIBLE else View.GONE
        pageScroll.visibility = if (kind == 1) View.VISIBLE else View.GONE
        pageEmpty.visibility = View.GONE
        pageEmpty.translationY = 0f
        pageBox.removeAllViews()
    }

    /** Halaman daftar dengan adapter/layout manager sendiri (kanal, playlist). */
    internal fun showCustomPage(
        title: String,
        adapter: RecyclerView.Adapter<*>,
        lm: RecyclerView.LayoutManager,
        more: (() -> Unit)?,
        action: Pair<String, () -> Unit>?
    ) {
        openPage(title, 0)
        pageList.layoutManager = lm
        pageList.adapter = adapter
        pageMore = more
        if (action != null) {
            pageAction.text = action.first
            pageAction.visibility = View.VISIBLE
            pageAction.setOnClickListener { action.second() }
        }
    }

    private fun closePage() {
        pageCloseHook?.invoke()
        pageCloseHook = null
        pageMore = null
        pageAction.visibility = View.GONE
        pageOpen = false
        page.visibility = View.GONE
        header.visibility = if (tab == 0 || tab == 3) View.VISIBLE else View.GONE
        if (tab == 4) refreshLibrary()
    }

    private fun showVideoPage(title: String, vids: List<Video>) {
        openPage(title, 0)
        pageAdapter.submit(vids)
        pageEmpty.text = "Belum ada video."
        pageEmpty.visibility = if (vids.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openChannel(ch: Channel) {
        if (playerOpen) showPlayer(false)
        ChannelScreen(this).open(ch)
    }

    internal fun openPlaylist(ref: PlaylistRef) {
        val all = ArrayList<Video>()
        var next: org.schabi.newpipe.extractor.Page? = null
        var busy = false
        val ad = VideoAdapter({ v -> Queue.setAll(all, v.url); openVideo(v) }, { v, anchor -> showVideoMenu(v, anchor) })
        showCustomPage(ref.name, ad, LinearLayoutManager(this), {
            val pg = next
            if (pg != null && !busy) {
                busy = true
                io.execute {
                    try {
                        val r = Repo.playlistMore(ref.url, pg)
                        ui.post { all.addAll(r.items); next = r.next; busy = false; ad.append(r.items) }
                    } catch (e: Exception) {
                        ui.post { busy = false }
                    }
                }
            }
        }, "PUTAR" to { playlistActions(all) })
        pageEmpty.text = "Memuat…"
        pageEmpty.visibility = View.VISIBLE
        io.execute {
            try {
                val r = Repo.playlist(ref.url)
                ui.post {
                    all.addAll(r.items)
                    next = r.next
                    ad.submit(all.toList())
                    pageEmpty.text = "Playlist kosong."
                    pageEmpty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
                }
            } catch (e: Exception) {
                ui.post { pageEmpty.text = "Gagal memuat playlist: ${e.message ?: ""}" }
            }
        }
    }

    private fun playlistActions(all: List<Video>) {
        if (all.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setItems(arrayOf("Putar semua", "Acak")) { _, i ->
                val list = if (i == 1) all.shuffled() else all.toList()
                Queue.setAll(list, list.first().url)
                openVideo(list.first())
            }
            .show()
    }

    private fun showSubsPage() {
        openPage("Langganan", 1)
        val subs = Store.subs()
        if (subs.isEmpty()) {
            pageEmpty.text = "Belum ada langganan.\nBuka video lalu ketuk BERLANGGANAN."
            pageEmpty.visibility = View.VISIBLE
            return
        }
        subs.forEach { ch ->
            val row = layoutInflater.inflate(R.layout.row_channel, pageBox, false)
            row.findViewById<TextView>(R.id.chName).text = ch.name
            if (ch.avatar != null) {
                row.findViewById<ImageView>(R.id.chAvatar).load(ch.avatar) { transformations(CircleCropTransformation()) }
            }
            row.setOnClickListener { openChannel(ch) }
            row.findViewById<View>(R.id.chMore).setOnClickListener {
                MaterialAlertDialogBuilder(this)
                    .setTitle(ch.name)
                    .setMessage("Berhenti berlangganan?")
                    .setPositiveButton("Berhenti") { _, _ -> Store.toggleSub(ch); showSubsPage() }
                    .setNegativeButton("Batal", null)
                    .show()
            }
            pageBox.addView(row)
        }
    }

    private fun showPlaylistsPage() {
        openPage("Daftar putar", 1)
        addPlainRow("＋  Buat daftar putar baru", null) { promptNewPlaylist { showPlaylistsPage() } }
        val names = Store.playlistNames()
        names.forEach { n ->
            addPlainRow(n, "${Store.playlist(n).size} video") { showVideoPage(n, Store.playlist(n)) }
                .setOnLongClickListener {
                    MaterialAlertDialogBuilder(this)
                        .setTitle(n)
                        .setMessage("Hapus daftar putar ini?")
                        .setPositiveButton("Hapus") { _, _ -> Store.deletePlaylist(n); showPlaylistsPage() }
                        .setNegativeButton("Batal", null)
                        .show()
                    true
                }
        }
        if (names.isEmpty()) {
            pageEmpty.text = "Belum ada daftar putar."
            pageEmpty.visibility = View.VISIBLE
            pageEmpty.translationY = dp(120).toFloat()
        } else {
            pageEmpty.translationY = 0f
        }
    }

    private fun promptNewPlaylist(done: (String) -> Unit) {
        val et = EditText(this).apply { hint = "Nama daftar putar"; setSingleLine() }
        val box = FrameLayout(this).apply { setPadding(dp(24), dp(8), dp(24), 0); addView(et) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Daftar putar baru")
            .setView(box)
            .setPositiveButton("Buat") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) { Store.createPlaylist(n); done(n) }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun addToPlaylist(v: Video) {
        val names = Store.playlistNames()
        val items = (names + "＋ Daftar putar baru").toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Simpan ke daftar putar")
            .setItems(items) { _, i ->
                if (i < names.size) {
                    Store.addToPlaylist(names[i], v)
                    toast("Disimpan ke ${names[i]}")
                } else {
                    promptNewPlaylist { n -> Store.addToPlaylist(n, v); toast("Disimpan ke $n") }
                }
            }
            .show()
    }

    private fun addPlainRow(title: String, desc: String?, onClick: () -> Unit): View {
        val v = layoutInflater.inflate(R.layout.row_setting, pageBox, false)
        v.findViewById<TextView>(R.id.rsTitle).text = title
        if (desc != null) {
            v.findViewById<TextView>(R.id.rsDesc).apply { text = desc; visibility = View.VISIBLE }
        }
        v.setOnClickListener { onClick() }
        pageBox.addView(v)
        return v
    }

    // ============================================================ pengaturan

    private fun addSection(title: String) {
        val v = layoutInflater.inflate(R.layout.row_section, pageBox, false) as TextView
        v.text = title
        pageBox.addView(v)
    }

    private fun addChoice(title: String, labels: List<String>, getIdx: () -> Int, setIdx: (Int) -> Unit) {
        val v = layoutInflater.inflate(R.layout.row_setting, pageBox, false)
        v.findViewById<TextView>(R.id.rsTitle).text = title
        val value = v.findViewById<TextView>(R.id.rsValue)
        value.visibility = View.VISIBLE
        value.text = labels[getIdx()]
        v.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(title)
                .setSingleChoiceItems(labels.toTypedArray(), getIdx()) { d, i ->
                    setIdx(i)
                    value.text = labels[i]
                    d.dismiss()
                    applyPlayerPrefs()
                }
                .show()
        }
        pageBox.addView(v)
    }

    private fun addSwitch(title: String, desc: String?, get: () -> Boolean, set: (Boolean) -> Unit) {
        val v = layoutInflater.inflate(R.layout.row_setting, pageBox, false)
        v.findViewById<TextView>(R.id.rsTitle).text = title
        if (desc != null) v.findViewById<TextView>(R.id.rsDesc).apply { text = desc; visibility = View.VISIBLE }
        v.findViewById<View>(R.id.rsChevron).visibility = View.GONE
        val sw = v.findViewById<SwitchCompat>(R.id.rsSwitch)
        sw.visibility = View.VISIBLE
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, c -> set(c); applyPlayerPrefs() }
        v.setOnClickListener { sw.toggle() }
        pageBox.addView(v)
    }

    private fun showSettingsPage() {
        openPage("Umum", 1)
        val resVals = listOf(0, 1080, 720, 480, 360, 240)
        addSection("Akun YouTube")
        addPlainRow(
            if (YtAuth.loggedIn) "Akun: " + YtAuth.accountName.ifBlank { "terhubung" } else "Masuk akun YouTube",
            if (YtAuth.loggedIn) "Ketuk untuk keluar" else "Kirim suka & langganan ke YouTube"
        ) { if (YtAuth.loggedIn) confirmLogout() else startLogin() }
        addPlainRow("Client ID & Secret OAuth", if (YtAuth.configured) "Sudah diisi" else "Belum diisi") { showOAuthDialog(null) }
        addPlainRow("Panduan membuat Client ID", null) { showOAuthHelp() }

        addSection("Tampilan & data")
        addChoice("Tema", listOf("Ikuti sistem", "Terang", "Gelap", "Dark AMOLED"),
            { Prefs.theme }, { Prefs.theme = it; ui.post { recreate() } })
        addChoice("Hemat data", listOf("Nonaktif", "Aktif", "Hanya saat data seluler"),
            { Prefs.dataSaver }, { Prefs.dataSaver = it; Repo.lowData = Prefs.dataSaverActive(this) })

        addSection("Kualitas")
        addChoice("Resolusi video default",
            resVals.map { if (it == 0) "Otomatis" else "${it}p" },
            { resVals.indexOf(Prefs.resolution).coerceAtLeast(0) }, { Prefs.resolution = resVals[it] })
        addChoice("Resolusi audio default", listOf("Otomatis", "Hemat data"),
            { Prefs.audioQuality }, { Prefs.audioQuality = it })

        addSection("Putar otomatis")
        addChoice("Background play auto", listOf("Selalu aktif", "Nonaktif"),
            { if (Prefs.bgPlay) 0 else 1 }, { Prefs.bgPlay = it == 0 })
        addChoice("Pemutaran video mulai otomatis", listOf("Selalu", "Tidak"),
            { if (Prefs.autoStart) 0 else 1 }, { Prefs.autoStart = it == 0 })
        addSwitch("Putar video berikutnya otomatis", "Memutar video terkait pertama saat video selesai",
            { Prefs.autoNext }, { Prefs.autoNext = it })
        addSwitch("Lanjutkan pemutaran", "Melanjutkan pemutaran setelah interupsi (mis. panggilan telepon)",
            { Prefs.resumeAfterInterrupt }, { Prefs.resumeAfterInterrupt = it })
        addSwitch("Jendela mengambang otomatis", "Masuk mode jendela mengambang saat keluar aplikasi",
            { Prefs.pipAuto }, { Prefs.pipAuto = it })

        addSection("Gerak Isyarat")
        addSwitch("Pencarian video cepat",
            "Mulai memutar konten lebih cepat tetapi dari posisi yang kurang tepat saat menyesuaikan bilah kemajuan video",
            { Prefs.fastSeek }, { Prefs.fastSeek = it })
        addSwitch("Kontrol gestur volume", "Gunakan gestur untuk mengontrol volume pemutar",
            { Prefs.volGesture }, { Prefs.volGesture = it })
        addSwitch("Kontrol gestur kecerahan", "Gunakan gestur untuk mengontrol kecerahan pemutar",
            { Prefs.brightGesture }, { Prefs.brightGesture = it })
        val seekVals = listOf(5, 10, 15, 30)
        addChoice("Ketuk dua kali untuk cari", seekVals.map { "$it detik" },
            { seekVals.indexOf(Prefs.seekSeconds).coerceAtLeast(0) }, { Prefs.seekSeconds = seekVals[it] })

        addSection("Subtitle & unduhan")
        addChoice("Subtitle otomatis", listOf("Mati", "Bahasa Indonesia", "English"),
            { when (Prefs.subLang) { "id" -> 1; "en" -> 2; else -> 0 } },
            { Prefs.subLang = listOf("", "id", "en")[it] })
        addSwitch("Lanjutkan dari terakhir ditonton", "Melanjutkan video dari posisi terakhir (Watch Progress)",
            { Prefs.resumeProgress }, { Prefs.resumeProgress = it })
        addSwitch("Unduh hanya lewat Wi-Fi", null, { Prefs.dlWifiOnly }, { Prefs.dlWifiOnly = it })

        addSection("Data & tentang")
        addPlainRow("Notifikasi pemutaran", "Tombol putar/jeda dan lewati di notifikasi") {
            try {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            } catch (e: Exception) { toast("Tidak tersedia") }
        }
        addPlainRow("Izinkan berjalan di latar belakang", "Matikan optimasi baterai agar pemutaran stabil") {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) { toast("Tidak tersedia") }
        }
        addPlainRow("Hapus riwayat tontonan", null) { confirmClearHistory() }
        addPlainRow("Tentang & atribusi ikon", null) {
            MaterialAlertDialogBuilder(this)
                .setTitle("NovaTube")
                .setMessage(
                    "NovaTube © 2026 Ilham Galeh. Hak cipta dilindungi.\n\n" +
                        "Data video: NewPipeExtractor (GPLv3).\n\n" +
                        "Ikon: set vektor bawaan. Jika Anda mengganti dengan ikon dari Flaticon, " +
                        "cantumkan atribusi sesuai lisensi Flaticon (nama pembuat + tautan flaticon.com)."
                )
                .setPositiveButton("Tutup", null)
                .show()
        }
    }

    private fun applyPlayerPrefs() = withPlayer { p ->
        p.setSeekParameters(if (Prefs.fastSeek) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
            Prefs.resumeAfterInterrupt
        )
    }

    // ============================================================ intent

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        i ?: return
        val raw = when (i.action) {
            Intent.ACTION_VIEW -> i.data?.toString()
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)?.let { Regex("https?://\\S+").find(it)?.value }
            else -> null
        } ?: return
        openFromLink(raw)
    }

    // ============================================================ pemutar

    private fun setupPlayer() {
        // Pertahankan frame terakhir ketika Surface berpindah ke mini player.
        playerView.setKeepContentOnPlayerReset(true)
        miniVideoView.setKeepContentOnPlayerReset(true)
        related.layoutManager = LinearLayoutManager(this)
        related.adapter = relatedAdapter
        playerView.setFullscreenButtonClickListener { setFullscreen(!fullscreen) }
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            playerTop.visibility = if (vis == View.VISIBLE && !inPip) View.VISIBLE else View.GONE
        })

        findViewById<View>(R.id.btnMinimize).setOnClickListener { showPlayer(false) }
        tvQuality.setOnClickListener { showQuality() }
        tvSpeed.setOnClickListener { showSpeed() }
        findViewById<View>(R.id.btnMore).setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            pm.menu.add(0, 1, 0, if (audioOnly) "Putar video" else "Audio saja")
            pm.menu.add(0, 2, 1, "Subtitle")
            pm.menu.add(0, 3, 2, "Trek audio")
            pm.menu.add(0, 4, 3, "Timer tidur")
            pm.menu.add(0, 5, 4, "Video berikutnya")
            pm.menu.add(0, 6, 5, "Video sebelumnya")
            pm.menu.add(0, 7, 6, "Jendela mengambang")
            pm.menu.add(0, 8, 7, "Bagikan")
            pm.menu.add(0, 9, 8, "Info pemutaran")
            pm.setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> toggleAudioOnly()
                    2 -> showSubtitleDialog()
                    3 -> showAudioTrackDialog()
                    4 -> showSleepDialog()
                    5 -> playNext(false)
                    6 -> playPrev()
                    7 -> enterPip()
                    8 -> currentVideo?.let { v2 -> share(v2) }
                    9 -> showInfo()
                }
                true
            }
            pm.show()
        }

        findViewById<View>(R.id.btnExpand).setOnClickListener {
            val open = tvDesc.visibility != View.VISIBLE
            tvDesc.visibility = if (open) View.VISIBLE else View.GONE
            tvTitle.maxLines = if (open) Int.MAX_VALUE else 2
        }
        val openCurrentChannel = View.OnClickListener {
            val ch = currentChannel
            if (ch != null) openChannel(ch) else toast("Kanal tidak tersedia")
        }
        chName.setOnClickListener(openCurrentChannel)
        chAvatar.setOnClickListener(openCurrentChannel)
        findViewById<View>(R.id.pillBg).setOnClickListener {
            val a = options.indexOfFirst { it.audioOnly }
            if (a >= 0) { tried.clear(); selectOption(a, keepPos = true) }
            showPlayer(false)
            toast("Memutar di latar belakang")
        }
        findViewById<View>(R.id.commentsRow).setOnClickListener { showCommentsSheet() }
        commentPreview.setOnClickListener { showCommentsSheet() }
        findViewById<View>(R.id.likeHit).setOnClickListener {
            val v = currentVideo ?: return@setOnClickListener
            if (localMode) return@setOnClickListener
            val want = if (ytRating == "like") "none" else "like"
            Social.setRating(this, v, want) { ok, r -> if (ok) { ytRating = r; refreshActionState(); hintLogin() } }
        }
        findViewById<View>(R.id.icDislike).setOnClickListener {
            val v = currentVideo ?: return@setOnClickListener
            if (localMode) return@setOnClickListener
            val want = if (ytRating == "dislike") "none" else "dislike"
            Social.setRating(this, v, want) { ok, r -> if (ok) { ytRating = r; refreshActionState(); hintLogin() } }
        }
        btnSub.setOnClickListener {
            val ch = currentChannel
            if (ch == null) {
                toast("Kanal tidak tersedia")
                return@setOnClickListener
            }
            Social.toggleSub(this, ch) { on ->
                isSubscribed = on
                refreshActionState()
                toast(if (on) "Berlangganan ${ch.name}" else "Berhenti berlangganan")
                hintLogin()
            }
        }
        findViewById<View>(R.id.pillMore).setOnClickListener { anchor ->
            val v = currentVideo ?: return@setOnClickListener
            val pm = PopupMenu(this, anchor)
            pm.menu.add(0, 1, 0, "Bagikan")
            pm.menu.add(0, 2, 1, if (Store.has("later", v.url)) "Hapus dari Nonton nanti" else "Nonton nanti")
            pm.menu.add(0, 3, 2, "Simpan ke daftar putar")
            pm.menu.add(0, 4, 3, "Antrean")
            pm.menu.add(0, 5, 4, "Tambah ke antrean")
            pm.menu.add(0, 6, 5, "Unduh")
            pm.setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> share(v)
                    2 -> toast(if (Store.toggle("later", v)) "Disimpan ke Nonton nanti" else "Dihapus dari Nonton nanti")
                    3 -> addToPlaylist(v)
                    4 -> QueueSheet(this).show()
                    5 -> { Queue.add(v, false); toast("Ditambahkan ke antrean") }
                    6 -> downloadVideo(v)
                }
                true
            }
            pm.show()
        }
    }

    private fun withPlayer(block: (ExoPlayer) -> Unit) {
        val p = player
        if (p != null) block(p) else pending.add(block)
    }

    private fun metaLong(v: Video): String =
        listOf(Fmt.views(v.views), Util.simpleDate(v.date)).filter { it.isNotBlank() }.joinToString(" · ")

    internal fun openVideo(v: Video, audio: Boolean = false, show: Boolean = true, resume: Boolean = false) {
        // 1) simpan posisi video lama SEBELUM apa pun diganti
        saveProgressNow()
        // 2) tandai pergantian: tidak ada penyimpanan posisi sampai sumber media baru terpasang
        Now.switching = !resume
        if (!resume) Now.ownerKey = ""
        localMode = false
        currentVideo = v
        Now.video = v
        currentChannel = null
        comments = emptyList()
        commentSession = null
        firstComments = null
        options = emptyList()
        subs = emptyList()
        audioTracks = emptyList()
        activeSub = null
        audioOverride = null
        pendingSeek = 0L
        pendingKey = ""
        tried.clear()
        manualQuality = false
        audioOnly = false
        audioCover.visibility = View.GONE
        tvTitle.text = v.title
        tvMeta.text = metaLong(v)
        tvDesc.visibility = View.GONE
        tvTitle.maxLines = 2
        chName.text = v.channel
        chName.isClickable = true
        chAvatar.isClickable = true
        chSubs.text = ""
        chAvatar.setImageDrawable(null)
        if (v.avatar != null) chAvatar.load(v.avatar) { transformations(CircleCropTransformation()) }
        commentPreview.visibility = View.GONE
        tvLike.text = "Suka"
        ytRating = "none"
        ytRatingBase = "none"
        ytLikeBase = -1L
        isSubscribed = false
        relatedAdapter.submit(emptyList())
        tvQuality.text = "Otomatis"
        Queue.syncCurrent(v.url)
        refreshActionState()
        playerLoading.visibility = View.VISIBLE
        if (show) showPlayer(true) else updateMini()
        if (!resume) withPlayer { it.stop() }

        io.execute {
            try {
                val si = Repo.stream(v.url)
                val low = Repo.lowData
                val opts = Repo.options(si, Prefs.audioQuality == 1 || low)
                val rel = Repo.map(si.relatedItems)
                val subList = Repo.subtitles(si)
                val tracks = Repo.audioTracks(si)
                ui.post {
                    if (currentVideo?.url != v.url) return@post
                    val avatar = Repo.thumb(si.uploaderAvatars) ?: v.avatar
                    val full = Video(
                        si.url ?: v.url, Util.htmlToText(si.name ?: v.title), si.uploaderName ?: v.channel,
                        si.viewCount, si.textualUploadDate ?: v.date, si.duration,
                        Repo.thumb(si.thumbnails) ?: v.thumb, avatar
                    )
                    currentVideo = full
                    val chUrl = si.uploaderUrl
                    currentChannel = if (!chUrl.isNullOrBlank()) Channel(chUrl, full.channel, avatar) else null
                    tvTitle.text = full.title
                    tvMeta.text = metaLong(full)
                    tvDesc.text = Util.htmlToText(si.description?.content)
                    Linkify.addLinks(tvDesc, Linkify.WEB_URLS)
                    chName.text = full.channel
                    chSubs.text = Fmt.subs(si.uploaderSubscriberCount)
                    if (si.uploaderSubscriberCount < 0 && !chUrl.isNullOrBlank()) {
                        io.execute {
                            val cd = try { Repo.channel(chUrl) } catch (e: Exception) { null }
                            ui.post {
                                if (cd != null && cd.subs >= 0 && currentVideo === full) chSubs.text = Fmt.subs(cd.subs)
                            }
                        }
                    }
                    if (avatar != null) chAvatar.load(avatar) { transformations(CircleCropTransformation()) }
                    ytLikeBase = si.likeCount
                    relatedAdapter.submit(rel)
                    autoQueue = listOf(full) + rel
                    Now.auto = autoQueue
                    subs = subList
                    audioTracks = tracks
                    activeSub = pickSubtitle(subList)
                    Queue.syncCurrent(full.url)
                    Store.addHistory(full)
                    refreshActionState()
                    Social.loadRating(this, full) { r ->
                        if (currentVideo === full) { ytRating = r; ytRatingBase = r; refreshActionState() }
                    }
                    currentChannel?.let { c ->
                        Social.loadSub(this, c) { on -> if (currentVideo === full) { isSubscribed = on; refreshActionState() } }
                    }
                    if (Prefs.resumeProgress && !resume) {
                        Store.progress(full.url)?.let { p ->
                            if (p[0] > 8000 && (p[1] <= 0 || p[0] < p[1] * 0.95)) {
                                pendingSeek = p[0]
                                pendingKey = Util.videoKey(full.url)
                                toast("Melanjutkan dari ${Util.clock(p[0])}")
                            }
                        }
                    }
                    options = opts
                    if (opts.isEmpty()) {
                        playerLoading.visibility = View.GONE
                        toast("Tidak ada stream yang bisa diputar.")
                    } else {
                        val aIdx = opts.indexOfFirst { it.audioOnly }
                        val idx = if (audio && aIdx >= 0) aIdx else Repo.pick(opts, Prefs.resolution, if (low) 360 else 0)
                        selectOption(idx, keepPos = resume)
                    }
                    if (!low) {
                        io.execute {
                            try {
                                val cs = CommentsSession(full.url)
                                val f = cs.first()
                                ui.post {
                                    if (currentVideo === full) {
                                        commentSession = cs
                                        firstComments = f
                                        showComments(f)
                                    }
                                }
                            } catch (e: Exception) {
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                ui.post {
                    if (currentVideo?.url != v.url) return@post
                    playerLoading.visibility = View.GONE
                    toast("Gagal memuat video: ${e.message ?: "kesalahan"}")
                }
            }
        }
    }

    private fun pickSubtitle(list: List<SubTrack>): SubTrack? {
        val lang = Prefs.subLang
        if (lang.isEmpty()) return null
        return list.filter { it.lang.startsWith(lang, ignoreCase = true) }.sortedBy { it.auto }.firstOrNull()
    }

    private fun showComments(first: CommentsPage?) {
        val c = first?.items?.firstOrNull() ?: return
        commentPreview.visibility = View.VISIBLE
        cmText.text = c.text
        val av = c.avatar
        if (av != null) cmAvatar.load(av) { transformations(CircleCropTransformation()) } else cmAvatar.setImageDrawable(null)
    }

    private fun showCommentsSheet() {
        val v = currentVideo ?: return
        if (localMode) { toast("Komentar tidak tersedia untuk video offline"); return }
        CommentsSheet(this, v.url, commentSession, firstComments).show()
    }

    private fun refreshActionState() {
        val accent = getColor(R.color.accent)
        val muted = themeColor(R.attr.ntMuted)
        val icon = themeColor(R.attr.ntIcon)
        icLike.setColorFilter(if (ytRating == "like") accent else icon)
        tvLike.setTextColor(if (ytRating == "like") accent else muted)
        findViewById<ImageView>(R.id.icDislike).setColorFilter(if (ytRating == "dislike") accent else icon)
        if (ytLikeBase >= 0) {
            val n = ytLikeBase + (if (ytRating == "like") 1 else 0) - (if (ytRatingBase == "like") 1 else 0)
            tvLike.text = Fmt.compact(n.coerceAtLeast(0))
        } else {
            tvLike.text = "Suka"
        }
        btnSub.text = if (isSubscribed) "TERLANGGANAN" else "BERLANGGANAN"
        btnSub.setBackgroundResource(if (isSubscribed) R.drawable.bg_sub_btn_off else R.drawable.bg_sub_btn)
    }

    private fun qualityLabel(o: Option): String = when {
        o.audioOnly -> "Audio"
        o.hls != null -> "Langsung"
        !manualQuality && Prefs.resolution == 0 -> "Otomatis (${o.height}p)"
        else -> "${o.height}p"
    }

    private fun selectOption(idx: Int, keepPos: Boolean) {
        val o = options.getOrNull(idx) ?: return
        currentOption = o
        selected = idx
        tried.add(idx)
        audioOnly = o.audioOnly
        if (!o.audioOnly) lastVideoIdx = idx
        audioCover.visibility = if (o.audioOnly) View.VISIBLE else View.GONE
        if (o.audioOnly) audioCover.load(currentVideo?.thumb)
        tvQuality.text = qualityLabel(o)
        play(o, keepPos)
    }

    private fun play(o: Option, keepPos: Boolean) = withPlayer { p ->
        val v = currentVideo
        val built = PlayerFactory.build(this, o, v, audioOverride, activeSub, localMode)
        built.warn?.let { toast(it) }
        gotVideo = false
        val key = Util.videoKey(v?.url ?: "")
        // Video baru yang belum pernah ditonton selalu mulai dari 0; resume hanya untuk ID video yang sama.
        val seek = when {
            keepPos -> p.currentPosition
            pendingKey.isNotEmpty() && pendingKey == key -> pendingSeek
            else -> 0L
        }
        pendingSeek = 0L
        pendingKey = ""
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, activeSub == null)
            .build()
        Now.video = v
        Now.audioOnly = o.audioOnly
        Now.ownerKey = key
        Now.switching = false
        p.setMediaSource(built.source, seek)
        p.prepare()
        p.playWhenReady = if (keepPos) true else Prefs.autoStart
        ui.removeCallbacks(blankCheck)
        if (!o.audioOnly) ui.postDelayed(blankCheck, 10_000)
    }

    private fun reapply() {
        val o = options.getOrNull(selected) ?: return
        tried.clear()
        tried.add(selected)
        play(o, keepPos = true)
    }

    private fun showSubtitleDialog() {
        if (subs.isEmpty()) { toast("Video ini tidak punya subtitle"); return }
        val shown = subs.take(60)
        val labels = arrayOf("Mati") + shown.map { it.label + if (it.auto) " (otomatis)" else "" }
        val cur = shown.indexOfFirst { it === activeSub } + 1
        MaterialAlertDialogBuilder(this)
            .setTitle("Subtitle")
            .setSingleChoiceItems(labels, cur) { d, i ->
                activeSub = if (i == 0) null else shown[i - 1]
                d.dismiss()
                reapply()
            }
            .show()
    }

    private fun showAudioTrackDialog() {
        if (audioTracks.isEmpty()) { toast("Video ini hanya punya satu trek audio"); return }
        val labels = audioTracks.map { it.name }.toTypedArray()
        val cur = audioTracks.indexOfFirst { it === audioOverride }.let { if (it >= 0) it else 0 }
        MaterialAlertDialogBuilder(this)
            .setTitle("Trek audio")
            .setSingleChoiceItems(labels, cur) { d, i ->
                audioOverride = if (i == 0) null else audioTracks[i]
                d.dismiss()
                reapply()
            }
            .show()
    }

    private fun showInfo() {
        val p = player
        val o = currentOption
        val sb = StringBuilder()
        sb.append("Opsi: ${o?.label ?: "-"} (${if (o?.muxed == true) "langsung" else "gabungan"})\n")
        sb.append("Ukuran video: ${p?.videoSize?.width ?: 0}x${p?.videoSize?.height ?: 0}\n")
        sb.append("Status: ${p?.playbackState}  memutar=${p?.isPlaying}\n")
        sb.append("UA: ${Repo.uaFor(o?.video ?: o?.audio ?: "")}\n")
        sb.append("Hemat data: ${Repo.lowData}\n")
        sb.append("Subtitle: ${subs.size}, trek audio: ${audioTracks.size}\n")
        if (lastError.isNotEmpty()) sb.append("Galat terakhir: $lastError")
        MaterialAlertDialogBuilder(this).setTitle("Info pemutaran").setMessage(sb.toString())
            .setPositiveButton("Tutup", null).show()
    }

    // ============================================================ progres, antrean, timer tidur

    private fun saveProgressNow() {
        val p = player ?: return
        if (localMode) return
        Now.saveProgress(p)
    }

    private fun onVideoEnded() {
        if (!localMode) Now.markFinished(player)
        if (sleepAtEnd) {
            clearSleep()
            toast("Timer tidur: pemutaran dihentikan")
            return
        }
        if (localMode) return
        playNext(auto = true)
    }

    internal fun playNext(auto: Boolean): Boolean {
        currentVideo?.let { Queue.syncCurrent(it.url) }
        var next: Video? = Queue.advance()
        if (next == null) {
            if (auto && !Prefs.autoNext) return false
            val cur = Util.videoKey(currentVideo?.url ?: "")
            val idx = autoQueue.indexOfFirst { Util.videoKey(it.url) == cur }
            next = if (idx >= 0) autoQueue.getOrNull(idx + 1) else autoQueue.firstOrNull { Util.videoKey(it.url) != cur }
        }
        if (next == null) {
            if (!auto) toast("Tidak ada video berikutnya")
            return false
        }
        openVideo(next, audio = audioOnly, show = playerOpen)
        return true
    }

    internal fun playPrev() {
        currentVideo?.let { Queue.syncCurrent(it.url) }
        val p = Queue.back()
        if (p == null) {
            player?.seekTo(0)
            return
        }
        openVideo(p, audio = audioOnly, show = playerOpen)
    }

    private fun showSleepDialog() {
        val labels = arrayOf("Nonaktif", "15 menit", "30 menit", "45 menit", "60 menit", "90 menit", "Akhir video")
        val vals = intArrayOf(0, 15, 30, 45, 60, 90, -1)
        MaterialAlertDialogBuilder(this).setTitle("Timer tidur").setItems(labels) { _, i -> setSleep(vals[i]) }.show()
    }

    private fun setSleep(minutes: Int) {
        sleepAtEnd = minutes == -1
        sleepEndAt = if (minutes > 0) SystemClock.elapsedRealtime() + minutes * 60_000L else 0L
        player?.volume = 1f
        updateSleepLabel(minutes * 60_000L)
        toast(
            when {
                minutes == 0 -> "Timer tidur dimatikan"
                minutes == -1 -> "Berhenti di akhir video"
                else -> "Berhenti dalam $minutes menit"
            }
        )
    }

    private fun clearSleep() {
        sleepEndAt = 0L
        sleepAtEnd = false
        player?.volume = 1f
        updateSleepLabel(0L)
    }

    private fun sleepTick() {
        if (sleepEndAt == 0L) return
        val left = sleepEndAt - SystemClock.elapsedRealtime()
        if (left <= 0) {
            player?.pause()
            clearSleep()
            toast("Timer tidur selesai")
            return
        }
        if (left <= 15_000) player?.volume = (left / 15_000f).coerceIn(0.05f, 1f)
        updateSleepLabel(left)
    }

    private fun updateSleepLabel(left: Long) {
        tvSleep.visibility = if (sleepEndAt > 0 || sleepAtEnd) View.VISIBLE else View.GONE
        tvSleep.text = if (sleepAtEnd) "⏾ akhir" else "⏾ " + Util.clock(left)
    }

    // ============================================================ unduhan & offline

    internal fun downloadVideo(v: Video, preferAudio: Boolean = false) {
        toast("Menyiapkan unduhan…")
        io.execute {
            try {
                val si = Repo.stream(v.url)
                val opts = Repo.options(si, false).filter { (it.muxed && it.video != null && it.hls == null) || it.audioOnly }
                ui.post {
                    if (opts.isEmpty()) {
                        toast("Tidak ada stream yang bisa diunduh")
                        return@post
                    }
                    if (preferAudio) {
                        val au = opts.firstOrNull { it.audioOnly }
                        if (au != null) { startDownload(v, au); return@post }
                    }
                    val labels = opts.map { if (it.audioOnly) "Audio saja (m4a)" else "Video ${it.label}" }.toTypedArray()
                    MaterialAlertDialogBuilder(this).setTitle("Unduh").setItems(labels) { _, i -> startDownload(v, opts[i]) }.show()
                }
            } catch (e: Exception) {
                ui.post { toast("Gagal menyiapkan unduhan: ${e.message ?: ""}") }
            }
        }
    }

    private fun startDownload(v: Video, o: Option) {
        val url = (if (o.audioOnly) o.audio else o.video) ?: return
        try {
            Downloads.enqueue(this, v, url, o.audioOnly, if (o.audioOnly) "m4a" else "mp4")
            toast("Mengunduh… lihat di Pustaka > Unduhan")
        } catch (e: Exception) {
            toast("Gagal memulai unduhan: ${e.message ?: ""}")
        }
    }

    internal fun playLocal(d: DlItem, uri: String) {
        saveProgressNow()
        localMode = true
        val v = Video(uri, d.title, d.channel, -1, "Offline", d.duration, d.thumb)
        currentVideo = v
        currentChannel = null
        tried.clear()
        subs = emptyList()
        audioTracks = emptyList()
        activeSub = null
        audioOverride = null
        audioOnly = d.audio
        autoQueue = emptyList()
        tvTitle.text = d.title
        tvMeta.text = "Putar offline"
        chName.text = d.channel
        chSubs.text = ""
        chAvatar.setImageDrawable(null)
        commentPreview.visibility = View.GONE
        relatedAdapter.submit(emptyList())
        audioCover.visibility = if (d.audio) View.VISIBLE else View.GONE
        if (d.audio) audioCover.load(d.thumb)
        options = listOf(Option("Offline", if (d.audio) null else uri, if (d.audio) uri else null, muxed = true, audioOnly = d.audio))
        tvQuality.text = "Offline"
        refreshActionState()
        showPlayer(true)
        selectOption(0, keepPos = false)
    }

    internal fun themeColor(attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    private fun showQuality() {
        if (options.isEmpty()) { toast("Belum ada pilihan kualitas."); return }
        MaterialAlertDialogBuilder(this)
            .setTitle("Kualitas")
            .setSingleChoiceItems(options.map { it.label }.toTypedArray(), selected) { d, i ->
                manualQuality = true
                tried.clear()
                selectOption(i, keepPos = true)
                d.dismiss()
            }
            .show()
    }

    private fun showSpeed() {
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = speeds.map { "${it}x".replace(".0x", "x") }
        val cur = player?.playbackParameters?.speed ?: 1f
        val curIdx = speeds.indexOfFirst { abs(it - cur) < 0.01f }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Kecepatan pemutaran")
            .setSingleChoiceItems(labels.toTypedArray(), curIdx) { d, i ->
                player?.setPlaybackSpeed(speeds[i])
                tvSpeed.text = labels[i]
                d.dismiss()
            }
            .show()
    }

    private fun toggleAudioOnly() {
        if (options.isEmpty()) return
        tried.clear()
        if (audioOnly) {
            selectOption(lastVideoIdx.coerceIn(0, options.size - 1), keepPos = true)
        } else {
            val a = options.indexOfFirst { it.audioOnly }
            if (a >= 0) selectOption(a, keepPos = true) else toast("Audio tidak tersedia.")
        }
    }

    internal fun share(v: Video) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, "${v.title}\n${v.url}")
        startActivity(Intent.createChooser(send, "Bagikan"))
    }

    internal fun showVideoMenu(v: Video, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Putar di latar belakang")
        pm.menu.add(0, 2, 1, "Putar berikutnya")
        pm.menu.add(0, 3, 2, "Tambah ke antrean")
        pm.menu.add(0, 4, 3, if (Store.has("later", v.url)) "Hapus dari Nonton nanti" else "Nonton nanti")
        pm.menu.add(0, 5, 4, "Simpan ke daftar putar")
        pm.menu.add(0, 6, 5, "Unduh")
        pm.menu.add(0, 7, 6, "Bagikan")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> openVideo(v, audio = true, show = false)
                2 -> { Queue.add(v, true); toast("Diputar berikutnya") }
                3 -> { Queue.add(v, false); toast("Ditambahkan ke antrean") }
                4 -> toast(if (Store.toggle("later", v)) "Disimpan ke Nonton nanti" else "Dihapus dari Nonton nanti")
                5 -> addToPlaylist(v)
                6 -> downloadVideo(v)
                7 -> share(v)
            }
            true
        }
        pm.show()
    }

    // ============================================================ tampilan pemutar

    /** Memindahkan Surface antar PlayerView tanpa membuat ulang ExoPlayer. */
    private fun attachPlayerSurface(showMain: Boolean) {
        val p = player ?: return
        if (showMain) {
            if (miniVideoView.player === p) miniVideoView.player = null
            if (playerView.player !== p) playerView.player = p
        } else {
            if (playerView.player === p) playerView.player = null
            if (miniVideoView.player !== p) miniVideoView.player = p
            miniVideoView.useController = false
        }
    }

    private fun showPlayer(show: Boolean) {
        playerOpen = show
        playerScreen.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(playerScreen.windowToken, 0)
            attachPlayerSurface(true)
            layoutPlayer()
            mini.visibility = View.GONE
        } else {
            if (fullscreen) setFullscreen(false)
            attachPlayerSurface(false)
            updateMini()
        }
    }

    private fun updateMini() {
        val p = player
        val v = currentVideo
        if (!playerOpen && v != null && p != null && p.mediaItemCount > 0) {
            mini.visibility = View.VISIBLE
            attachPlayerSurface(false)
            miniTitle.text = v.title
            miniPlay.setImageResource(if (p.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        } else {
            mini.visibility = View.GONE
        }
    }

    private fun stopAndClose() {
        saveProgressNow()
        clearSleep()
        player?.let { it.stop(); it.clearMediaItems() }
        currentVideo = null
        mini.visibility = View.GONE
    }

    private fun layoutPlayer() {
        val dm = resources.displayMetrics
        val lp = playerBox.layoutParams
        lp.height = if (fullscreen || inPip) ViewGroup.LayoutParams.MATCH_PARENT
        else minOf(dm.widthPixels * 9 / 16, (dm.heightPixels * 0.6f).toInt())
        playerBox.layoutParams = lp
        info.visibility = if (fullscreen || inPip) View.GONE else View.VISIBLE
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
        layoutPlayer()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !playerOpen) return
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (e: Exception) {
            toast("Jendela mengambang tidak didukung.")
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Prefs.pipAuto && playerOpen && !audioOnly && player?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        playerView.useController = !isInPictureInPictureMode
        if (isInPictureInPictureMode) playerTop.visibility = View.GONE
        layoutPlayer()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (playerOpen) layoutPlayer()
    }

    // ============================================================ gestur

    private fun flash(s: String) {
        tvGesture.text = s
        tvGesture.visibility = View.VISIBLE
        ui.removeCallbacks(hideGesture)
        ui.postDelayed(hideGesture, 700)
    }

    private fun setupGestures() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return false
                val w = playerView.width.coerceAtLeast(1)
                val step = Prefs.seekSeconds * 1000L
                when {
                    e.x < w / 3f -> {
                        p.seekTo((p.currentPosition - step).coerceAtLeast(0))
                        flash("« ${Prefs.seekSeconds} dtk")
                    }
                    e.x > w * 2f / 3f -> {
                        p.seekTo(p.currentPosition + step)
                        flash("${Prefs.seekSeconds} dtk »")
                    }
                    else -> if (p.isPlaying) p.pause() else p.play()
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null || abs(dy) < abs(dx)) return false
                val h = playerView.height.coerceAtLeast(1)
                val delta = dy / h
                if (e1.x > playerView.width / 2f) {
                    if (!Prefs.volGesture) return false
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    gestureVol = (gestureVol + delta * max * 1.5f).coerceIn(0f, max.toFloat())
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, gestureVol.roundToInt(), 0)
                    flash("🔊 ${(gestureVol / max * 100).roundToInt()}%")
                } else {
                    if (!Prefs.brightGesture) return false
                    gestureBr = (gestureBr + delta * 1.5f).coerceIn(0.02f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = gestureBr
                    window.attributes = lp
                    flash("☀ ${(gestureBr * 100).roundToInt()}%")
                }
                return true
            }
        })
        playerView.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                gestureVol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                val b = window.attributes.screenBrightness
                gestureBr = if (b < 0f) 0.5f else b
            }
            gd.onTouchEvent(ev)
            false
        }
    }

    companion object {
        private val CATS = listOf(
            "Trending" to "trending indonesia",
            "Musik" to "lagu terbaru",
            "DJ" to "dj terbaru full bass",
            "Dangdut" to "dangdut terbaru",
            "Gaming" to "gaming indonesia",
            "Berita" to "berita terbaru",
            "Film" to "trailer film terbaru",
            "Olahraga" to "sepak bola highlights",
            "Teknologi" to "review gadget",
            "Kuliner" to "resep masakan",
            "Podcast" to "podcast indonesia"
        )
    }
}
