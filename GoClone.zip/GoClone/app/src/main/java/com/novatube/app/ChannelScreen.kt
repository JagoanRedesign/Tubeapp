package com.novatube.app

import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import org.schabi.newpipe.extractor.Page

/** Halaman kanal: header profil + tab Beranda / Video / Shorts / Playlist (/ Live) + urutan. */
class ChannelScreen(private val a: MainActivity) {
    private sealed class Row {
        object Head : Row()
        class Section(val t: String) : Row()
        class Vid(val v: Video, val short: Boolean) : Row()
        class Pl(val p: PlaylistRef) : Row()
        class Msg(val t: String) : Row()
    }

    private class Simple(v: View) : RecyclerView.ViewHolder(v)

    private lateinit var ch: Channel
    private var data: ChannelData? = null
    private var tab = "home"
    private var sort = 0 // 0 terbaru, 1 populer, 2 terlama
    private var token = 0
    private val items = ArrayList<Any>()
    private var next: Page? = null
    private var busy = false
    private var homeVids: List<Video> = emptyList()
    private var homeShorts: List<Video> = emptyList()
    private var homePls: List<PlaylistRef> = emptyList()
    private var rows: List<Row> = listOf(Row.Head)
    private lateinit var header: View
    private val adapter = Adapter()
    private val tabViews = LinkedHashMap<String, TextView>()
    private lateinit var sortRow: View
    private lateinit var sortNew: TextView
    private lateinit var sortPop: TextView
    private lateinit var sortOld: TextView
    private lateinit var subBtn: TextView

    fun open(c: Channel) {
        ch = c
        data = null
        tab = "home"
        sort = 0
        token++
        items.clear()
        next = null
        busy = false
        header = a.layoutInflater.inflate(R.layout.item_channel_header, null)
        bindHeaderStatic()

        val lm = GridLayoutManager(a, 3)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                val r = rows.getOrNull(position)
                return if (r is Row.Vid && r.short) 1 else 3
            }
        }
        a.showCustomPage(c.name, adapter, lm, { onEnd() }, null)
        setRows(listOf(Row.Head, Row.Msg("Memuat kanal…")))

        val my = token
        a.io.execute {
            try {
                val d = Repo.channel(c.url)
                a.ui.post {
                    if (my != token) return@post
                    data = d
                    fillHeader(d)
                    selectTab("home")
                }
            } catch (e: Exception) {
                a.ui.post {
                    if (my == token) setRows(listOf(Row.Head, Row.Msg("Gagal memuat kanal: ${e.message ?: "coba lagi"}")))
                }
            }
        }
    }

    private fun setRows(r: List<Row>) {
        rows = r
        adapter.notifyDataSetChanged()
    }

    // ------------------------------------------------------------ header
    private fun bindHeaderStatic() {
        header.findViewById<TextView>(R.id.chTitle).text = ch.name
        val av = ch.avatar
        if (av != null) header.findViewById<ImageView>(R.id.chAvatarBig).load(av) { transformations(CircleCropTransformation()) }
        header.findViewById<View>(R.id.chBanner).visibility = View.GONE
        subBtn = header.findViewById(R.id.chSubBtn)
        refreshSub()
        subBtn.setOnClickListener {
            val on = Store.toggleSub(ch)
            refreshSub()
            a.toast(if (on) "Berlangganan ${ch.name} (disimpan di perangkat)" else "Berhenti berlangganan")
        }
        sortRow = header.findViewById(R.id.chSortRow)
        sortNew = header.findViewById(R.id.sortNew)
        sortPop = header.findViewById(R.id.sortPop)
        sortOld = header.findViewById(R.id.sortOld)
        sortNew.setOnClickListener { setSort(0) }
        sortPop.setOnClickListener { setSort(1) }
        sortOld.setOnClickListener { setSort(2) }
        styleSort()
    }

    private fun refreshSub() {
        val sub = Store.isSub(ch.url)
        subBtn.text = if (sub) "TERLANGGANAN" else "BERLANGGANAN"
        subBtn.setBackgroundResource(if (sub) R.drawable.bg_sub_btn_off else R.drawable.bg_sub_btn)
    }

    private fun fillHeader(d: ChannelData) {
        header.findViewById<TextView>(R.id.chTitle).text = d.name.ifEmpty { ch.name }
        header.findViewById<TextView>(R.id.chMeta).text =
            listOf(Fmt.subs(d.subs), if (d.verified) "✓ Terverifikasi" else "").filter { it.isNotBlank() }.joinToString(" • ")
        val desc = header.findViewById<TextView>(R.id.chDesc)
        desc.text = d.desc
        desc.visibility = if (d.desc.isBlank()) View.GONE else View.VISIBLE
        var expanded = false
        desc.setOnClickListener {
            expanded = !expanded
            desc.maxLines = if (expanded) Int.MAX_VALUE else 2
        }
        val av = d.avatar ?: ch.avatar
        if (av != null) header.findViewById<ImageView>(R.id.chAvatarBig).load(av) { transformations(CircleCropTransformation()) }
        val bn = d.banner
        val banner = header.findViewById<ImageView>(R.id.chBanner)
        if (bn != null && !Repo.lowData) {
            banner.visibility = View.VISIBLE
            banner.load(bn)
        }

        val box = header.findViewById<LinearLayout>(R.id.chTabs)
        box.removeAllViews()
        tabViews.clear()
        val keys = ArrayList<String>()
        keys.add("home")
        d.tabs.keys.filter { it in LABELS }.forEach { keys.add(it) }
        keys.forEach { k ->
            val tv = TextView(a).apply {
                text = LABELS[k]
                textSize = 15f
                setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12))
                setOnClickListener { if (tab != k) selectTab(k) }
            }
            box.addView(tv)
            tabViews[k] = tv
        }
    }

    private fun styleTabs() {
        val on = a.getColor(R.color.accent)
        val off = a.themeColor(R.attr.ntMuted)
        tabViews.forEach { (k, tv) ->
            tv.setTextColor(if (k == tab) on else off)
            tv.setTypeface(null, if (k == tab) Typeface.BOLD else Typeface.NORMAL)
        }
        sortRow.visibility = if (tab == "videos" || tab == "shorts" || tab == "livestreams") View.VISIBLE else View.GONE
    }

    private fun styleSort() {
        listOf(sortNew, sortPop, sortOld).forEachIndexed { i, tv ->
            val on = i == sort
            tv.setBackgroundResource(if (on) R.drawable.bg_chip_sel else R.drawable.bg_chip)
            tv.setTextColor(if (on) 0xFFFFFFFF.toInt() else a.themeColor(R.attr.ntText))
        }
    }

    // ------------------------------------------------------------ memuat konten
    private fun selectTab(key: String) {
        tab = key
        sort = 0
        token++
        items.clear()
        next = null
        busy = false
        styleTabs()
        styleSort()
        loadFirst()
    }

    private fun loadFirst() {
        val d = data ?: return
        val my = token
        val key = tab
        setRows(listOf(Row.Head, Row.Msg("Memuat…")))
        a.io.execute {
            try {
                if (key == "home") {
                    val v = d.tabs["videos"]?.let { runCatching { Repo.tab(it) }.getOrNull() }
                    val s = d.tabs["shorts"]?.let { runCatching { Repo.tab(it) }.getOrNull() }
                    val p = d.tabs["playlists"]?.let { runCatching { Repo.tab(it) }.getOrNull() }
                    a.ui.post {
                        if (my != token) return@post
                        homeVids = v?.items?.filterIsInstance<Video>() ?: emptyList()
                        homeShorts = s?.items?.filterIsInstance<Video>() ?: emptyList()
                        homePls = p?.items?.filterIsInstance<PlaylistRef>() ?: emptyList()
                        render()
                    }
                } else {
                    val h = d.tabs[key] ?: throw IllegalStateException("Tab tidak tersedia")
                    val pg = Repo.tab(h)
                    a.ui.post {
                        if (my != token) return@post
                        items.clear()
                        items.addAll(pg.items)
                        next = pg.next
                        render()
                    }
                }
            } catch (e: Exception) {
                a.ui.post {
                    if (my == token) setRows(listOf(Row.Head, Row.Msg("Gagal memuat: ${e.message ?: "coba lagi"}")))
                }
            }
        }
    }

    /** Dipanggil saat daftar mencapai ujung bawah. */
    private fun onEnd() {
        if (tab == "home" || sort != 0 || busy) return
        val pg = next ?: return
        val h = data?.tabs?.get(tab) ?: return
        busy = true
        val my = token
        a.io.execute {
            try {
                val r = Repo.tabMore(h, pg)
                a.ui.post {
                    if (my != token) return@post
                    items.addAll(r.items)
                    next = r.next
                    busy = false
                    render()
                }
            } catch (e: Exception) {
                a.ui.post { busy = false }
            }
        }
    }

    private fun setSort(s: Int) {
        if (sort == s) return
        sort = s
        styleSort()
        if (s != 0 && next != null && !busy) {
            // Urutan Populer/Terlama dihitung dari item yang termuat: muat beberapa halaman dulu.
            val h = data?.tabs?.get(tab) ?: return render()
            busy = true
            val my = token
            a.toast("Memuat lebih banyak untuk mengurutkan…")
            a.io.execute {
                var pg = next
                var guard = 0
                val extra = ArrayList<Any>()
                try {
                    while (pg != null && guard < 4) {
                        val r = Repo.tabMore(h, pg)
                        extra.addAll(r.items)
                        pg = r.next
                        guard++
                    }
                } catch (e: Exception) {
                }
                a.ui.post {
                    if (my != token) return@post
                    items.addAll(extra)
                    next = pg
                    busy = false
                    render()
                }
            }
        } else {
            render()
        }
    }

    private fun render() {
        val r = ArrayList<Row>()
        r.add(Row.Head)
        if (tab == "home") {
            if (homeVids.isNotEmpty()) {
                r.add(Row.Section("Video terbaru"))
                homeVids.take(5).forEach { r.add(Row.Vid(it, false)) }
            }
            if (homeShorts.isNotEmpty()) {
                r.add(Row.Section("Shorts"))
                homeShorts.take(6).forEach { r.add(Row.Vid(it, true)) }
            }
            if (homePls.isNotEmpty()) {
                r.add(Row.Section("Playlist"))
                homePls.take(4).forEach { r.add(Row.Pl(it)) }
            }
            if (r.size == 1) r.add(Row.Msg("Belum ada konten di beranda kanal ini."))
        } else {
            val vids = items.filterIsInstance<Video>()
            if (tab == "playlists") {
                items.filterIsInstance<PlaylistRef>().forEach { r.add(Row.Pl(it)) }
            } else {
                val sorted = when (sort) {
                    1 -> vids.sortedByDescending { it.views }
                    2 -> vids.reversed()
                    else -> vids
                }
                if (sort != 0 && vids.isNotEmpty()) r.add(Row.Msg("Diurutkan dari ${vids.size} video yang dimuat"))
                sorted.forEach { r.add(Row.Vid(it, tab == "shorts")) }
            }
            if (r.size == 1) r.add(Row.Msg("Belum ada konten."))
        }
        setRows(r)
    }

    // ------------------------------------------------------------ adapter
    private inner class Adapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = rows.size

        override fun getItemViewType(position: Int): Int = when (val r = rows[position]) {
            is Row.Head -> 0
            is Row.Section -> 1
            is Row.Vid -> if (r.short) 3 else 2
            is Row.Pl -> 4
            is Row.Msg -> 5
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder = when (t) {
            0 -> Simple(FrameLayout(p.context).apply { layoutParams = RecyclerView.LayoutParams(-1, -2) })
            1, 5 -> Simple(TextView(p.context).apply {
                layoutParams = RecyclerView.LayoutParams(-1, -2)
                setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(8))
            })
            2 -> newVideoHolder(p)
            3 -> {
                val v = a.layoutInflater.inflate(R.layout.item_short, p, false)
                val w = p.context.resources.displayMetrics.widthPixels / 3 - a.dp(6)
                v.findViewById<View>(R.id.sThumb).layoutParams.height = w * 16 / 9
                Simple(v)
            }
            else -> Simple(a.layoutInflater.inflate(R.layout.item_playlist, p, false))
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
            when (val r = rows[i]) {
                is Row.Head -> {
                    val c = h.itemView as FrameLayout
                    (header.parent as? ViewGroup)?.removeView(header)
                    c.removeAllViews()
                    c.addView(header, FrameLayout.LayoutParams(-1, -2))
                }
                is Row.Section -> (h.itemView as TextView).apply {
                    text = r.t
                    textSize = 17f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(a.themeColor(R.attr.ntText))
                }
                is Row.Msg -> (h.itemView as TextView).apply {
                    text = r.t
                    textSize = 14f
                    setTypeface(null, Typeface.NORMAL)
                    setTextColor(a.themeColor(R.attr.ntMuted))
                }
                is Row.Vid -> if (r.short) bindShort(h.itemView, r.v) else
                    bindVideo(h as VideoAdapter.VH, r.v, { a.openVideo(it) }, { v, anchor -> a.showVideoMenu(v, anchor) })
                is Row.Pl -> bindPlaylist(h.itemView, r.p)
            }
        }
    }

    private fun bindShort(v: View, s: Video) {
        v.findViewById<ImageView>(R.id.sThumb).load(s.thumb)
        v.findViewById<TextView>(R.id.sTitle).text = s.title
        v.findViewById<TextView>(R.id.sViews).text = Fmt.views(s.views)
        v.setOnClickListener { a.openVideo(s) }
    }

    private fun bindPlaylist(v: View, p: PlaylistRef) {
        v.findViewById<ImageView>(R.id.plThumb).load(p.thumb)
        v.findViewById<TextView>(R.id.plCount).text = if (p.count >= 0) "${p.count} video" else "Playlist"
        v.findViewById<TextView>(R.id.plTitle).text = p.name
        v.findViewById<TextView>(R.id.plMeta).text = p.owner
        v.setOnClickListener { a.openPlaylist(p) }
    }

    companion object {
        private val LABELS = mapOf(
            "home" to "Beranda",
            "videos" to "Video",
            "shorts" to "Shorts",
            "playlists" to "Playlist",
            "livestreams" to "Live"
        )
    }
}
