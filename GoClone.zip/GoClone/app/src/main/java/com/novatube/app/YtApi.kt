package com.novatube.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** YouTube Data API v3 (resmi). Semua pemanggilan memakai token akun pengguna. */
object YtApi {
    private const val BASE = "https://www.googleapis.com/youtube/v3"
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun call(method: String, path: String, body: String? = null): JSONObject? {
        val rb = when {
            body != null -> body.toRequestBody("application/json".toMediaType())
            method == "POST" -> ByteArray(0).toRequestBody(null)
            else -> null
        }
        val req = Request.Builder()
            .url(BASE + path)
            .header("Authorization", "Bearer " + YtAuth.token())
            .method(method, rb)
            .build()
        http.newCall(req).execute().use { r ->
            val txt = r.body?.string() ?: ""
            if (!r.isSuccessful) {
                val msg = try { JSONObject(txt).getJSONObject("error").optString("message") } catch (e: Exception) { "" }
                throw IOException(msg.ifEmpty { "HTTP ${r.code}" })
            }
            return if (txt.isBlank()) null else JSONObject(txt)
        }
    }

    /** "like" | "dislike" | "none" */
    fun getRating(videoId: String): String {
        val j = call("GET", "/videos/getRating?id=$videoId")
        val r = j?.optJSONArray("items")?.optJSONObject(0)?.optString("rating", "none") ?: "none"
        return if (r == "like" || r == "dislike") r else "none"
    }

    fun rate(videoId: String, rating: String) {
        call("POST", "/videos/rate?id=$videoId&rating=$rating")
    }

    /** ID langganan jika sudah berlangganan, atau null. */
    fun subscriptionId(channelId: String): String? {
        val j = call("GET", "/subscriptions?part=id&mine=true&forChannelId=$channelId")
        return j?.optJSONArray("items")?.optJSONObject(0)?.optString("id")?.takeIf { it.isNotEmpty() }
    }

    fun subscribe(channelId: String): String {
        val body = "{\"snippet\":{\"resourceId\":{\"kind\":\"youtube#channel\",\"channelId\":\"$channelId\"}}}"
        val j = call("POST", "/subscriptions?part=snippet", body)
        return j?.optString("id") ?: ""
    }

    fun unsubscribe(subscriptionId: String) {
        call("DELETE", "/subscriptions?id=$subscriptionId")
    }

    /** Daftar langganan akun (hingga 3 halaman x 50). */
    fun mySubscriptions(): List<Channel> {
        val out = ArrayList<Channel>()
        var token: String? = null
        var guard = 0
        do {
            val path = "/subscriptions?part=snippet&mine=true&maxResults=50&order=alphabetical" +
                (if (token != null) "&pageToken=$token" else "")
            val j = call("GET", path) ?: break
            val items = j.optJSONArray("items")
            if (items != null) {
                for (i in 0 until items.length()) {
                    val sn = items.getJSONObject(i).optJSONObject("snippet") ?: continue
                    val id = sn.optJSONObject("resourceId")?.optString("channelId") ?: continue
                    val thumb = sn.optJSONObject("thumbnails")?.optJSONObject("default")?.optString("url")
                    out.add(Channel("https://www.youtube.com/channel/$id", sn.optString("title"), thumb))
                }
            }
            token = j.optString("nextPageToken").takeIf { it.isNotEmpty() }
            guard++
        } while (token != null && guard < 3)
        return out
    }

    /** Playlist milik akun yang sedang terotorisasi. */
    fun myPlaylists(): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        var pageToken: String? = null
        var guard = 0
        do {
            val path = "/playlists?part=snippet,contentDetails&mine=true&maxResults=50" +
                (pageToken?.let { "&pageToken=${java.net.URLEncoder.encode(it, "UTF-8")}" } ?: "")
            val j = call("GET", path) ?: break
            val items = j.optJSONArray("items")
            if (items != null) for (i in 0 until items.length()) items.optJSONObject(i)?.let(out::add)
            pageToken = j.optString("nextPageToken").takeIf { it.isNotBlank() }
            guard++
        } while (pageToken != null && guard < 5)
        return out
    }

    /** Video dalam playlist tertentu. */
    fun playlistItems(playlistId: String): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        var pageToken: String? = null
        var guard = 0
        val encodedId = java.net.URLEncoder.encode(playlistId, "UTF-8")
        do {
            val path = "/playlistItems?part=snippet,contentDetails&playlistId=$encodedId&maxResults=50" +
                (pageToken?.let { "&pageToken=${java.net.URLEncoder.encode(it, "UTF-8")}" } ?: "")
            val j = call("GET", path) ?: break
            val items = j.optJSONArray("items")
            if (items != null) for (i in 0 until items.length()) items.optJSONObject(i)?.let(out::add)
            pageToken = j.optString("nextPageToken").takeIf { it.isNotBlank() }
            guard++
        } while (pageToken != null && guard < 5)
        return out
    }

    /** Data channel akun aktif, termasuk ID dan snippet. */
    fun myChannelDetails(): JSONObject? =
        call("GET", "/channels?part=snippet,contentDetails,statistics&mine=true")
            ?.optJSONArray("items")?.optJSONObject(0)

    /** Nama & foto akun. */
    fun me(): Pair<String, String?>? {
        val sn = call("GET", "/channels?part=snippet&mine=true")?.optJSONArray("items")?.optJSONObject(0)
            ?.optJSONObject("snippet") ?: return null
        return sn.optString("title") to sn.optJSONObject("thumbnails")?.optJSONObject("default")?.optString("url")
    }
}
