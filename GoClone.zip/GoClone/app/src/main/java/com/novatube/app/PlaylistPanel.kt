package com.novatube.app

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Panel daftar putar di bawah pemutar: ulangi, acak, simpan, bagikan, urutkan dengan geser. */
class PlaylistPanel(private val a: MainActivity, root: View) {
    private val list: RecyclerView = root.findViewById(R.id.plList)
    private val btnRepeat: ImageView = root.findViewById(R.id.plRepeat)
    private val btnShuffle: ImageView = root.findViewById(R.id.plShuffle)
    private val btnSave: ImageView = root.findViewById(R.id.plSave)
    private val btnShare: ImageView = root.findViewById(R.id.plShare)
    private val adapter = Adapter()

    private val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
        override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
            val f = vh.bindingAdapterPosition
            val t = target.bindingAdapterPosition
            if (f < 0 || t < 0) return false
            Queue.move(f, t)
            adapter.notifyItemMoved(f, t)
            return true
        }

        override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}
        override fun isLongPressDragEnabled() = false
    })

    init {
        list.layoutManager = LinearLayoutManager(a)
        list.adapter = adapter
        touch.attachToRecyclerView(list)
        btnRepeat.setOnClickListener {
            Queue.loop = !Queue.loop
            a.toast(if (Queue.loop) "Ulangi antrean: aktif" else "Ulangi antrean: mati")
            styleButtons()
        }
        btnShuffle.setOnClickListener {
            Queue.shuffleRest()
            a.toast("Video berikutnya diacak")
            a.updatePlaylistBar()
        }
        btnSave.setOnClickListener { saveAll() }
        btnShare.setOnClickListener { shareAll() }
        styleButtons()
    }

    private fun styleButtons() {
        val on = a.getColor(R.color.accent)
        val off = a.themeColor(R.attr.ntIcon)
        btnRepeat.setColorFilter(if (Queue.loop) on else off)
    }

    fun refresh() {
        styleButtons()
        adapter.notifyDataSetChanged()
    }

    fun scrollToCurrent() {
        val i = Queue.index
        if (i in Queue.items.indices) (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(i, 0)
    }

    private fun saveAll() {
        val items = ArrayList(Queue.items)
        if (items.isEmpty()) return
        val names = Store.playlistNames()
        val labels = (names + "＋  Daftar putar baru").toTypedArray()
        MaterialAlertDialogBuilder(a)
            .setTitle("Simpan ${items.size} video ke…")
            .setItems(labels) { _, i ->
                fun put(n: String) {
                    items.asReversed().forEach { Store.addToPlaylist(n, it) }
                    a.toast("Disimpan ke $n")
                }
                if (i < names.size) put(names[i]) else a.promptNewPlaylist { n -> put(n) }
            }
            .show()
    }

    private fun shareAll() {
        val items = Queue.items.take(50)
        if (items.isEmpty()) return
        val head = Queue.title ?: "Antrean"
        val body = head + "\n" + items.joinToString("\n") { "${it.title}\n${it.url}" }
        a.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, body), "Bagikan"))
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val handle: ImageView = v.findViewById(R.id.plqHandle)
            val thumb: ImageView = v.findViewById(R.id.plqThumb)
            val dur: TextView = v.findViewById(R.id.plqDur)
            val title: TextView = v.findViewById(R.id.plqTitle)
            val more: ImageView = v.findViewById(R.id.plqMore)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_plqueue, p, false))

        override fun getItemCount() = Queue.items.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val v = Queue.items[i]
            h.thumb.load(v.thumb)
            val d = Fmt.duration(v.duration)
            h.dur.text = d
            h.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
            h.title.text = v.title
            h.itemView.setBackgroundColor(if (i == Queue.index) Color.argb(40, 128, 128, 128) else Color.TRANSPARENT)
            h.handle.setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) touch.startDrag(h)
                false
            }
            h.itemView.setOnClickListener {
                val pos = h.bindingAdapterPosition
                if (pos < 0) return@setOnClickListener
                Queue.index = pos
                a.openVideo(Queue.items[pos])
            }
            h.more.setOnClickListener { anchor ->
                val pos = h.bindingAdapterPosition
                if (pos < 0) return@setOnClickListener
                val vid = Queue.items[pos]
                val pm = PopupMenu(a, anchor)
                pm.menu.add(0, 1, 0, "Putar sekarang")
                pm.menu.add(0, 2, 1, "Simpan ke daftar putar")
                pm.menu.add(0, 3, 2, "Bagikan")
                pm.menu.add(0, 4, 3, "Hapus dari antrean")
                pm.setOnMenuItemClickListener {
                    when (it.itemId) {
                        1 -> { Queue.index = pos; a.openVideo(vid) }
                        2 -> a.addToPlaylist(vid)
                        3 -> a.share(vid)
                        4 -> { Queue.remove(pos); notifyDataSetChanged(); a.updatePlaylistBar() }
                    }
                    true
                }
                pm.show()
            }
        }
    }
}
