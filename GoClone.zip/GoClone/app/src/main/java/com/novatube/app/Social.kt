package com.novatube.app

import java.util.concurrent.ConcurrentHashMap

/**
 * Suka & langganan. Jika sudah masuk akun YouTube, aksi dikirim ke YouTube lewat API resmi;
 * jika belum, tersimpan di perangkat saja.
 */
object Social {
    private val ratings = ConcurrentHashMap<String, String>()
    private val subIds = ConcurrentHashMap<String, String>() // channelId -> id langganan ("" = belum)

    private fun localRating(v: Video): String =
        if (Store.has("liked", v.url)) "like"
        else if (Store.hasFlag("vdis", Util.videoKey(v.url))) "dislike" else "none"

    private fun setLocal(v: Video, rating: String) {
        val has = Store.has("liked", v.url)
        if (rating == "like" && !has) Store.toggle("liked", v)
        if (rating != "like" && has) Store.toggle("liked", v)
        Store.setFlag("vdis", Util.videoKey(v.url), rating == "dislike")
    }

    fun loadRating(a: MainActivity, v: Video, cb: (String) -> Unit) {
        val id = Util.videoKey(v.url)
        if (!YtAuth.loggedIn) { cb(localRating(v)); return }
        ratings[id]?.let { cb(it); return }
        a.io.execute {
            val r = try { YtApi.getRating(id) } catch (e: Exception) { localRating(v) }
            ratings[id] = r
            a.ui.post { cb(r) }
        }
    }

    fun setRating(a: MainActivity, v: Video, rating: String, cb: (Boolean, String) -> Unit) {
        val id = Util.videoKey(v.url)
        if (!YtAuth.loggedIn) {
            setLocal(v, rating)
            cb(true, rating)
            return
        }
        a.io.execute {
            try {
                YtApi.rate(id, rating)
                ratings[id] = rating
                setLocal(v, rating)
                a.ui.post { cb(true, rating) }
            } catch (e: Exception) {
                a.ui.post { a.toast("Gagal mengirim ke YouTube: ${e.message ?: ""}"); cb(false, rating) }
            }
        }
    }

    fun loadSub(a: MainActivity, ch: Channel, cb: (Boolean) -> Unit) {
        val cid = Util.channelId(ch.url)
        if (!YtAuth.loggedIn || cid == null) { cb(Store.isSub(ch.url)); return }
        subIds[cid]?.let { cb(it.isNotEmpty()); return }
        a.io.execute {
            val sid = try { YtApi.subscriptionId(cid) } catch (e: Exception) { null }
            subIds[cid] = sid ?: ""
            a.ui.post { cb(sid != null) }
        }
    }

    /** Membalik status langganan. [cb] menerima status baru. */
    fun toggleSub(a: MainActivity, ch: Channel, cb: (Boolean) -> Unit) {
        val cid = Util.channelId(ch.url)
        if (!YtAuth.loggedIn || cid == null) {
            cb(Store.toggleSub(ch))
            return
        }
        a.io.execute {
            try {
                val cur = subIds[cid] ?: (YtApi.subscriptionId(cid) ?: "")
                if (cur.isEmpty()) {
                    subIds[cid] = YtApi.subscribe(cid).ifEmpty { "-" }
                    Store.addSubIfAbsent(ch)
                    a.ui.post { cb(true) }
                } else {
                    YtApi.unsubscribe(cur)
                    subIds[cid] = ""
                    if (Store.isSub(ch.url)) Store.toggleSub(ch)
                    a.ui.post { cb(false) }
                }
            } catch (e: Exception) {
                a.ui.post { a.toast("Gagal mengirim ke YouTube: ${e.message ?: ""}"); cb(Store.isSub(ch.url)) }
            }
        }
    }

    /** Impor langganan akun YouTube ke daftar lokal. */
    fun importSubscriptions(a: MainActivity, done: (Int) -> Unit) {
        if (!YtAuth.loggedIn) { done(0); return }
        a.io.execute {
            val list = try { YtApi.mySubscriptions() } catch (e: Exception) { emptyList() }
            var added = 0
            for (c in list) {
                if (Store.addSubIfAbsent(c)) added++
            }
            a.ui.post { done(added) }
        }
    }

    fun reset() {
        ratings.clear()
        subIds.clear()
    }
}
