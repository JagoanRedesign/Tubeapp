package com.novatube.app

import android.app.DownloadManager
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Environment
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import coil.load
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class DlItem(
    val id: Long,
    val title: String,
    val channel: String,
    val thumb: String?,
    val duration: Long,
    val audio: Boolean,
    val file: String,
    val src: String
)

/** Pengelola unduhan memakai DownloadManager sistem (notifikasi, lanjut otomatis, Wi-Fi saja). */
object Downloads {
    private lateinit var sp: SharedPreferences

    class St(val status: Int, val done: Long, val total: Long, val reason: Int, val localUri: String?)

    fun init(ctx: Context) {
        if (!::sp.isInitialized) sp = ctx.getSharedPreferences("novatube_dl", Context.MODE_PRIVATE)
    }

    @Synchronized
    fun list(): List<DlItem> = try {
        val a = JSONArray(sp.getString("l", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            DlItem(
                o.getLong("id"), o.optString("t"), o.optString("c"), o.optString("th").ifEmpty { null },
                o.optLong("d"), o.optBoolean("a"), o.optString("f"), o.optString("s")
            )
        }
    } catch (e: Exception) { emptyList() }

    @Synchronized
    private fun save(l: List<DlItem>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("t", it.title).put("c", it.channel).put("th", it.thumb ?: "")
                    .put("d", it.duration).put("a", it.audio).put("f", it.file).put("s", it.src)
            )
        }
        sp.edit().putString("l", a.toString()).apply()
    }

    fun enqueue(ctx: Context, v: Video, url: String, audio: Boolean, ext: String): Long {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val dir = if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        val name = Util.sanitize(v.title) + " [" + Util.videoKey(v.url) + "]." + ext
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(v.title)
            .setDescription("NovaTube")
            .addRequestHeader("User-Agent", Repo.uaFor(url))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(!Prefs.dlWifiOnly)
            .setDestinationInExternalFilesDir(ctx, dir, "NovaTube/$name")
        val id = dm.enqueue(req)
        val base = ctx.getExternalFilesDir(dir) ?: ctx.filesDir
        val file = File(base, "NovaTube/$name").absolutePath
        save(listOf(DlItem(id, v.title, v.channel, v.thumb, v.duration, audio, file, v.url)) + list())
        return id
    }

    fun status(ctx: Context, id: Long): St? {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.query(DownloadManager.Query().setFilterById(id)).use { c ->
            if (!c.moveToFirst()) return null
            return St(
                c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)),
                c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
            )
        }
    }

    fun remove(ctx: Context, d: DlItem) {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        try { dm.remove(d.id) } catch (e: Exception) { }
        try { File(d.file).delete() } catch (e: Exception) { }
        save(list().filter { it.id != d.id })
    }
}

/** Halaman "Unduhan": progres langsung, putar offline, hapus, coba lagi. */
class DownloadsPage(private val a: MainActivity) {
    private var alive = false
    private class Row(val d: DlItem, val status: TextView, val prog: ProgressBar)
    private val rows = ArrayList<Row>()

    fun open() {
        a.openPage("Unduhan", 1)
        alive = true
        a.pageCloseHook = { alive = false }
        build()
        tick()
    }

    private fun mb(b: Long) = String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)

    private fun build() {
        a.pageBox.removeAllViews()
        rows.clear()
        val l = Downloads.list()
        if (l.isEmpty()) {
            a.pageEmpty.text = "Belum ada unduhan.\nGunakan tombol Unduh di pemutar atau menu ⋮ pada video."
            a.pageEmpty.visibility = View.VISIBLE
            return
        }
        l.forEach { d ->
            val v = a.layoutInflater.inflate(R.layout.row_download, a.pageBox, false)
            v.findViewById<ImageView>(R.id.dThumb).load(d.thumb)
            v.findViewById<TextView>(R.id.dTitle).text = (if (d.audio) "🎧 " else "") + d.title
            val st = v.findViewById<TextView>(R.id.dStatus)
            val pr = v.findViewById<ProgressBar>(R.id.dProg)
            v.setOnClickListener { play(d) }
            v.findViewById<ImageButton>(R.id.dMore).setOnClickListener { anchor ->
                val pm = PopupMenu(a, anchor)
                pm.menu.add(0, 1, 0, "Putar")
                pm.menu.add(0, 2, 1, "Coba lagi / unduh ulang")
                pm.menu.add(0, 3, 2, "Hapus")
                pm.setOnMenuItemClickListener {
                    when (it.itemId) {
                        1 -> play(d)
                        2 -> {
                            Downloads.remove(a, d)
                            a.downloadVideo(Video(d.src, d.title, d.channel, -1, "", d.duration, d.thumb), d.audio)
                            build()
                        }
                        3 -> { Downloads.remove(a, d); build() }
                    }
                    true
                }
                pm.show()
            }
            a.pageBox.addView(v)
            rows.add(Row(d, st, pr))
        }
    }

    private fun play(d: DlItem) {
        val s = Downloads.status(a, d.id)
        if (s != null && s.status == DownloadManager.STATUS_SUCCESSFUL) {
            a.playLocal(d, s.localUri ?: Uri.fromFile(File(d.file)).toString())
        } else {
            a.toast("Unduhan belum selesai")
        }
    }

    private fun tick() {
        if (!alive) return
        rows.forEach { r ->
            val s = Downloads.status(a, r.d.id)
            when {
                s == null -> { r.status.text = "Tidak ditemukan / dibatalkan"; r.prog.progress = 0 }
                s.status == DownloadManager.STATUS_SUCCESSFUL -> {
                    r.status.text = "Selesai • " + mb(s.total.coerceAtLeast(s.done)); r.prog.progress = 1000
                }
                s.status == DownloadManager.STATUS_FAILED -> {
                    r.status.text = "Gagal (kode ${s.reason}) — buka menu ⋮ lalu pilih Coba lagi"; r.prog.progress = 0
                }
                s.status == DownloadManager.STATUS_PAUSED -> {
                    r.status.text = "Dijeda (menunggu jaringan) • " + mb(s.done)
                    r.prog.progress = if (s.total > 0) (s.done * 1000 / s.total).toInt() else 0
                }
                s.status == DownloadManager.STATUS_PENDING -> { r.status.text = "Menunggu…"; r.prog.progress = 0 }
                else -> {
                    r.status.text = mb(s.done) + (if (s.total > 0) " / " + mb(s.total) else "")
                    r.prog.progress = if (s.total > 0) (s.done * 1000 / s.total).toInt() else 0
                }
            }
        }
        a.ui.postDelayed({ tick() }, 1000)
    }
}
