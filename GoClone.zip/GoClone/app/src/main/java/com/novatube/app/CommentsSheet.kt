package com.novatube.app

import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.schabi.newpipe.extractor.Page

/** Pengurutan komentar di sisi klien. mode 0 = Teratas (urutan asli), 1 = Terbaru (berdasarkan waktu). */
fun <T> sortComments(list: List<T>, mode: Int, ts: (T) -> Long): List<T> =
    if (mode == 1) list.sortedByDescending(ts) else list

/** Komentar bergaya YouTube: foto asli, suka/tidak suka (lokal), balasan bersarang, muat bertahap. */
class CommentsSheet(
    private val a: MainActivity,
    private val url: String,
    private val preload: CommentsSession?,
    private val first: CommentsPage?
) {
    private class Th(val c: Comment) {
        val replies = ArrayList<Comment>()
        var expanded = false
        var next: Page? = c.repliesPage
        var loading = false
        var loaded = false
    }

    private sealed class Row {
        class C(val c: Comment, val depth: Int, val t: Th) : Row()
        class More(val t: Th) : Row()
        object Loading : Row()
    }

    private val threads = ArrayList<Th>()
    private var rows: List<Row> = emptyList()
    private var session: CommentsSession? = null
    private var next: Page? = null
    private var busy = false
    private var sortMode = 0
    private val adapter = Adapter()
    private lateinit var loadingView: ProgressBar
    private lateinit var empty: TextView
    private lateinit var note: TextView
    private lateinit var sortTop: TextView
    private lateinit var sortNew: TextView

    fun show() {
        val d = BottomSheetDialog(a)
        val v = a.layoutInflater.inflate(R.layout.sheet_comments, null)
        d.setContentView(v)
        d.expandTall(a)
        loadingView = v.findViewById(R.id.cmLoading)
        empty = v.findViewById(R.id.cmEmpty)
        note = v.findViewById(R.id.cmNote)
        sortTop = v.findViewById(R.id.sortTop)
        sortNew = v.findViewById(R.id.sortNew)
        val list = v.findViewById<RecyclerView>(R.id.cmList)
        list.layoutManager = LinearLayoutManager(a)
        list.adapter = adapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0 && !rv.canScrollVertically(1)) loadMore()
            }
        })
        v.findViewById<View>(R.id.cmClose).setOnClickListener { d.dismiss() }
        v.findViewById<View>(R.id.cmInput).setOnClickListener {
            a.toast("Menulis komentar memerlukan login akun YouTube, yang belum didukung sumber data ini.")
        }
        sortTop.setOnClickListener { setSort(0) }
        sortNew.setOnClickListener { setSort(1) }
        styleSort()
        d.show()
        start()
    }

    private fun styleSort() {
        listOf(sortTop, sortNew).forEachIndexed { i, tv ->
            val on = i == sortMode
            tv.setBackgroundResource(if (on) R.drawable.bg_chip_sel else R.drawable.bg_chip)
            tv.setTextColor(if (on) 0xFFFFFFFF.toInt() else a.themeColor(R.attr.ntText))
        }
    }

    private fun start() {
        if (first != null && preload != null) {
            session = preload
            addPage(first)
            return
        }
        a.io.execute {
            try {
                val s = CommentsSession(url)
                val f = s.first()
                a.ui.post { session = s; addPage(f) }
            } catch (e: Exception) {
                a.ui.post {
                    loadingView.visibility = View.GONE
                    empty.text = "Gagal memuat komentar: ${e.message ?: "coba lagi"}"
                    empty.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun addPage(p: CommentsPage) {
        loadingView.visibility = View.GONE
        if (p.disabled) {
            empty.text = "Komentar dinonaktifkan untuk video ini."
            empty.visibility = View.VISIBLE
            return
        }
        val have = threads.map { it.c.id }.toHashSet()
        p.items.filter { it.id !in have }.forEach { threads.add(Th(it)) }
        next = p.next
        rebuild()
        if (threads.isEmpty()) {
            empty.text = "Belum ada komentar."
            empty.visibility = View.VISIBLE
        }
    }

    private fun loadMore() {
        val pg = next ?: return
        val s = session ?: return
        if (busy) return
        busy = true
        a.io.execute {
            try {
                val r = s.more(pg)
                a.ui.post { busy = false; addPage(r) }
            } catch (e: Exception) {
                a.ui.post { busy = false }
            }
        }
    }

    private fun setSort(m: Int) {
        if (sortMode == m) return
        sortMode = m
        styleSort()
        if (m == 1) {
            note.visibility = View.VISIBLE
            note.text = "Diurutkan dari komentar yang termuat (waktu terbaru di atas)."
            // muat beberapa halaman lagi agar urutan terbaru lebih berarti
            val s = session
            var pg = next
            if (s != null && pg != null && !busy) {
                busy = true
                a.io.execute {
                    val extra = ArrayList<Comment>()
                    var guard = 0
                    try {
                        while (pg != null && guard < 3) {
                            val r = s.more(pg!!)
                            extra.addAll(r.items)
                            pg = r.next
                            guard++
                        }
                    } catch (e: Exception) {
                    }
                    a.ui.post { busy = false; addPage(CommentsPage(extra, pg, false)) }
                }
            }
        } else {
            note.visibility = View.GONE
        }
        rebuild()
    }

    private fun rebuild() {
        val base = sortComments(threads, sortMode) { it.c.ts }
        val r = ArrayList<Row>()
        for (t in base) {
            r.add(Row.C(t.c, 0, t))
            if (t.expanded) {
                t.replies.forEach { r.add(Row.C(it, 1, t)) }
                if (t.loading) r.add(Row.Loading) else if (t.next != null) r.add(Row.More(t))
            }
        }
        rows = r
        adapter.notifyDataSetChanged()
    }

    private fun toggleReplies(t: Th) {
        t.expanded = !t.expanded
        if (t.expanded && !t.loaded) loadReplies(t)
        rebuild()
    }

    private fun loadReplies(t: Th) {
        val s = session
        val pg = t.next
        if (s == null || pg == null || t.loading) { t.loaded = true; return }
        t.loading = true
        a.io.execute {
            try {
                val r = s.more(pg)
                a.ui.post { t.replies.addAll(r.items); t.next = r.next; t.loaded = true; t.loading = false; rebuild() }
            } catch (e: Exception) {
                a.ui.post { t.loading = false; t.loaded = true; a.toast("Gagal memuat balasan"); rebuild() }
            }
        }
    }

    private inner class Adapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        private inner class Simple(v: View) : RecyclerView.ViewHolder(v)

        override fun getItemCount() = rows.size

        override fun getItemViewType(position: Int) = when (rows[position]) {
            is Row.C -> 0
            is Row.More -> 1
            is Row.Loading -> 2
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder = when (t) {
            0 -> Simple(a.layoutInflater.inflate(R.layout.item_comment, p, false))
            1 -> Simple(TextView(p.context).apply {
                layoutParams = RecyclerView.LayoutParams(-1, -2)
                setPadding(a.dp(68), a.dp(10), a.dp(16), a.dp(10))
                textSize = 13f
                setTextColor(a.getColor(R.color.accent))
                text = "Muat balasan lainnya"
            })
            else -> Simple(ProgressBar(p.context).apply { layoutParams = RecyclerView.LayoutParams(-1, a.dp(48)) })
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
            when (val r = rows[i]) {
                is Row.More -> h.itemView.setOnClickListener { loadReplies(r.t); rebuild() }
                is Row.Loading -> {}
                is Row.C -> bindComment(h.itemView, r)
            }
        }

        private fun bindComment(v: View, r: Row.C) {
            val c = r.c
            val root = v.findViewById<View>(R.id.cRoot)
            root.setPadding(if (r.depth == 0) a.dp(16) else a.dp(56), root.paddingTop, root.paddingRight, root.paddingBottom)
            val av = v.findViewById<ImageView>(R.id.cAvatar)
            val size = a.dp(if (r.depth == 0) 40 else 28)
            av.layoutParams.width = size
            av.layoutParams.height = size
            if (c.avatar != null && !Repo.lowData) av.load(c.avatar) { transformations(CircleCropTransformation()) }
            else av.setImageDrawable(null)
            v.findViewById<TextView>(R.id.cName).text = c.author.ifBlank { "Pengguna" }
            v.findViewById<TextView>(R.id.cDate).text = c.date
            val badges = listOfNotNull(
                if (c.pinned) "📌 Disematkan" else null,
                if (c.owner) "✓ Pembuat" else null,
                if (c.hearted) "❤ Disukai pembuat" else null
            ).joinToString("  ")
            v.findViewById<TextView>(R.id.cBadge).apply {
                text = badges
                visibility = if (badges.isEmpty()) View.GONE else View.VISIBLE
            }
            v.findViewById<TextView>(R.id.cText).text = c.text

            val liked = Store.hasFlag("clike", c.id)
            val disliked = Store.hasFlag("cdis", c.id)
            val accent = a.getColor(R.color.accent)
            val muted = a.themeColor(R.attr.ntMuted)
            val likeIc = v.findViewById<ImageView>(R.id.cLikeIc)
            val disIc = v.findViewById<ImageView>(R.id.cDislikeIc)
            likeIc.setColorFilter(if (liked) accent else muted)
            disIc.setColorFilter(if (disliked) accent else muted)
            val n = c.likes + if (liked) 1 else 0
            v.findViewById<TextView>(R.id.cLikeN).text =
                if (n > 0) Fmt.compact(n.toLong()) else c.likesText.takeIf { it.isNotBlank() && it != "0" } ?: ""
            likeIc.setOnClickListener {
                Store.setFlag("clike", c.id, !liked)
                if (!liked) Store.setFlag("cdis", c.id, false)
                adapter.notifyItemChanged(bindingPos(v))
            }
            disIc.setOnClickListener {
                Store.setFlag("cdis", c.id, !disliked)
                if (!disliked) Store.setFlag("clike", c.id, false)
                adapter.notifyItemChanged(bindingPos(v))
            }
            v.findViewById<View>(R.id.cReply).setOnClickListener {
                a.toast("Menulis balasan memerlukan login akun YouTube.")
            }
            val toggle = v.findViewById<TextView>(R.id.cToggle)
            if (r.depth == 0 && c.replies > 0) {
                toggle.visibility = View.VISIBLE
                toggle.text = if (r.t.expanded) "▾ Sembunyikan balasan" else "▸ ${c.replies} balasan"
                toggle.setOnClickListener { toggleReplies(r.t) }
            } else {
                toggle.visibility = View.GONE
            }
        }

        private fun bindingPos(v: View): Int {
            var p: View? = v
            while (p != null && p.parent !is RecyclerView) p = p.parent as? View
            val rv = p?.parent as? RecyclerView ?: return RecyclerView.NO_POSITION
            return rv.getChildAdapterPosition(p)
        }
    }
}
