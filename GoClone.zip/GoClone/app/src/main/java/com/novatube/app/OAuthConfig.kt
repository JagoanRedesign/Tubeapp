package com.novatube.app

/**
 * Konfigurasi identitas OAuth proyek NovaTube.
 *
 * Catatan: AuthorizationClient pada Android mengidentifikasi aplikasi melalui
 * registrasi OAuth tipe Android (package name + SHA-1), bukan dengan mengirim
 * GOOGLE_OAUTH_CLIENT_ID pada setiap permintaan authorize().
 * Nilai ini disimpan sebagai referensi konfigurasi proyek. Jangan pernah
 * menambahkan Client Secret ke aplikasi Android.
 */
object OAuthConfig {
    const val GOOGLE_OAUTH_CLIENT_ID =
        "595678157449-gkhc06ofuu7b74di7ts3jc42iv9n3gbn.apps.googleusercontent.com"

    const val ANDROID_PACKAGE_NAME = "com.novatube.app"
    const val YOUTUBE_DATA_API = "YouTube Data API v3"
    const val YOUTUBE_READONLY_SCOPE = "https://www.googleapis.com/auth/youtube.readonly"
}
