package com.novatube.app

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class LogicTest {

    private fun v(c: Char) = Video("https://www.youtube.com/watch?v=" + c.toString().repeat(11), "t$c", "ch", 0, "", 0, null)

    private fun opts() = listOf(
        Option("360p", "v360", null, height = 360, muxed = true),
        Option("720p", "v720", null, height = 720, muxed = true),
        Option("480p HD", "vo480", "a", height = 480),
        Option("1080p HD", "vo1080", "a", height = 1080),
        Option("Audio saja", null, "a", audioOnly = true)
    )

    @Before
    fun reset() {
        Queue.persist = {}
        Queue.load(emptyList())
    }

    // ---------- Util
    @Test
    fun videoKey_handles_common_urls() {
        assertEquals("dQw4w9WgXcQ", Util.videoKey("https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=10"))
        assertEquals("dQw4w9WgXcQ", Util.videoKey("https://youtu.be/dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", Util.videoKey("https://www.youtube.com/shorts/dQw4w9WgXcQ"))
        assertEquals("https://example.com/x", Util.videoKey("https://example.com/x"))
    }

    @Test
    fun clock_formats_time() {
        assertEquals("1:05", Util.clock(65_000))
        assertEquals("1:01:05", Util.clock(3_665_000))
        assertEquals("0:00", Util.clock(-5))
    }

    @Test
    fun sanitize_removes_forbidden_chars() {
        assertEquals("a b c", Util.sanitize("a/b:c"))
        assertEquals("video", Util.sanitize("***"))
        assertTrue(Util.sanitize("x".repeat(200)).length <= 60)
    }

    @Test
    fun ageMs_parses_indonesian_and_english() {
        assertEquals(3 * 604_800_000L, Util.ageMs("3 minggu lalu"))
        assertEquals(2 * 3_600_000L, Util.ageMs("2 hours ago"))
        assertEquals(-1L, Util.ageMs("kemarin"))
    }

    // ---------- Fmt
    @Test
    fun fmt_compact_and_duration() {
        assertEquals("950", Fmt.compact(950))
        assertEquals("1,5 jt", Fmt.compact(1_500_000))
        assertEquals("", Fmt.compact(-1))
        assertEquals("", Fmt.duration(0))
        assertEquals("3:05", Fmt.duration(185))
    }

    // ---------- pemilihan kualitas
    @Test
    fun pick_auto_prefers_best_direct_stream() {
        assertEquals(1, Repo.pick(opts(), 0))
    }

    @Test
    fun pick_auto_respects_data_saver_cap() {
        assertEquals(0, Repo.pick(opts(), 0, 360))
    }

    @Test
    fun pick_explicit_resolution_can_choose_merged() {
        assertEquals(3, Repo.pick(opts(), 1080))
        assertEquals(2, Repo.pick(opts(), 480))
    }

    @Test
    fun fallback_goes_direct_then_lowest_video_then_audio() {
        assertEquals(0, Repo.fallback(opts(), setOf(1)))
        assertEquals(2, Repo.fallback(opts(), setOf(0, 1)))
        assertEquals(4, Repo.fallback(opts(), setOf(0, 1, 2, 3)))
        assertEquals(-1, Repo.fallback(opts(), setOf(0, 1, 2, 3, 4)))
    }

    // ---------- antrean
    @Test
    fun queue_add_next_and_end_keeps_current() {
        Queue.setAll(listOf(v('a'), v('b'), v('c')), v('a').url)
        assertEquals(v('b').url, Queue.advance()?.url)
        Queue.add(v('d'), next = true)
        assertEquals(v('d').url, Queue.peekNext()?.url)
        Queue.add(v('e'), next = false)
        assertEquals(v('e').url, Queue.items.last().url)
        assertEquals(v('b').url, Queue.current()?.url)
    }

    @Test
    fun queue_remove_and_move_keep_current_pointer() {
        Queue.setAll(listOf(v('a'), v('b'), v('c'), v('d')), v('b').url)
        Queue.remove(0)
        assertEquals(v('b').url, Queue.current()?.url)
        Queue.move(0, 2)
        assertEquals(v('b').url, Queue.current()?.url)
        assertEquals(3, Queue.items.size)
    }

    @Test
    fun queue_back_and_advance_bounds() {
        Queue.setAll(listOf(v('a'), v('b')), v('a').url)
        assertNull(Queue.back())
        assertEquals(v('b').url, Queue.advance()?.url)
        assertNull(Queue.advance())
    }

    // ---------- komentar & progres
    @Test
    fun sortComments_newest_first() {
        assertEquals(listOf(3L, 2L, 1L), sortComments(listOf(1L, 3L, 2L), 1) { it })
        assertEquals(listOf(1L, 3L, 2L), sortComments(listOf(1L, 3L, 2L), 0) { it })
    }

    @Test
    fun progress_parsing() {
        assertArrayEquals(longArrayOf(1, 2, 3), Store.parseProgress("1|2|3"))
        assertNull(Store.parseProgress("x"))
        assertNull(Store.parseProgress(null))
    }

    @Test
    fun user_agent_matches_stream_client() {
        assertTrue(Repo.uaFor("https://r1.googlevideo.com/x?c=IOS&y=1").startsWith("com.google.ios"))
        assertTrue(Repo.uaFor("https://r1.googlevideo.com/x?c=ANDROID").startsWith("com.google.android"))
        assertEquals(UA, Repo.uaFor("https://r1.googlevideo.com/x?c=WEB"))
    }

    // ---------- tanggal & HTML
    @Test
    fun simpleDate_converts_iso_to_relative() {
        val now = java.time.OffsetDateTime.parse("2026-11-19T10:00:00Z")
        assertEquals("2 hari lalu", Util.simpleDate("2026-11-16T21:30:27-08:00", now))
        assertEquals("1 jam lalu", Util.simpleDate("2026-11-19T08:30:00Z", now))
        assertEquals("1 tahun lalu", Util.simpleDate("2025-01-01T00:00:00Z", now))
        assertEquals("1 Jan 2027", Util.simpleDate("2027-01-01T00:00:00Z", now))
        assertEquals("3 minggu lalu", Util.simpleDate("3 minggu lalu", now))
    }

    @Test
    fun htmlToText_cleans_raw_html() {
        assertEquals("Halo\ndunia", Util.htmlToText("Halo<br>dunia"))
        assertEquals("Tom & Jerry <3", Util.htmlToText("Tom &amp; Jerry &lt;3"))
        assertEquals("lihat tautan ini", Util.htmlToText("lihat <a href=\"https://x.id\">tautan</a> ini"))
        assertEquals("'ok' \"q\"", Util.htmlToText("&#39;ok&#39; &quot;q&quot;"))
        assertEquals("tanpa html", Util.htmlToText("tanpa html"))
        assertEquals("", Util.htmlToText(null))
    }
}
